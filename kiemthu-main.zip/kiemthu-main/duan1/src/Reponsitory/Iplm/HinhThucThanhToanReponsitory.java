/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.HinhThucThanhToan;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class HinhThucThanhToanReponsitory implements IObjectReponsitory<HinhThucThanhToan> {

    @Override
    public List<HinhThucThanhToan> selectBySQL(String sql, Object... args) {
        List<HinhThucThanhToan> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new HinhThucThanhToan(rs.getString(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getDate(5), rs.getInt(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public List<HinhThucThanhToan> selectAll() {
        //Xu ly de tra ra 1 danh sach HinhThucDoiTra
        return selectBySQL("select * from HinhThucThanhToan");
    }

    @Override
    public List<HinhThucThanhToan> selectByWhere(String where) {
        //Xu ly de tra ra 1 danh sach HinhThucDoiTra
        return selectBySQL("select * from HinhThucThanhToan where matt like ?", "%" + where + "%");
    }

    @Override
    public HinhThucThanhToan selectByIDorMa(String x) {
        //Xu ly de tra ra 1 o HinhThucDoiTra
        return selectBySQL("select * from HinhThucThanhToan where id = ? ", x).get(0);
    }

    @Override
    public int update(HinhThucThanhToan t) {
        //Xu ly de update thong tin object trong db
        return DBConnect.executeUpdate("update HinhThucThanhToan set id = ?,ngaysua = ?,trangthai=? "
                + "where matt ?" , t.getTen(), t.getNgaySua(), t.getTrangThai());
    }

    @Override
    public int insert(HinhThucThanhToan t) {
        //Xu ly de them moi thong tin object trong db
        return DBConnect.executeUpdate("insert into HinhThucThanhToan values (newID(),?,?,?,?,?", t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai());
    }

    @Override
    public int delete(String t) {
        //Xu ly de xoa thong tin object trong db
        return DBConnect.executeUpdate("Delete from HinhThucThanhToan where matt = ?", t);
    }

}
