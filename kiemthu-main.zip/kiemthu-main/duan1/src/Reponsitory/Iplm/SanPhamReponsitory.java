/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.SanPham;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class SanPhamReponsitory implements IObjectReponsitory<SanPham> {

    @Override
    public List<SanPham> selectBySQL(String sql, Object... args) {
        List<SanPham> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new SanPham(rs.getString(1), rs.getString(2), rs.getString(3), rs.getDate(5), rs.getDate(6), rs.getInt(7)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public List<SanPham> selectAll() {
        return selectBySQL("Select * from SanPham order by maSp asc");
    }

    @Override
    public List<SanPham> selectByWhere(String where) {
        return selectBySQL("select * from SanPham where maSP like ?", "%" + where + "%");
    }

    @Override
    public SanPham selectByIDorMa(String x) {
        return selectBySQL("select * from SanPham where id = ? ", x).get(0);
    }

    public SanPham selectByMa(String x) {
        return selectBySQL("select * from SanPham where tensp = ? ", x).get(0);
    }

    @Override
    public int update(SanPham t) {
        return DBConnect.executeUpdate("update SanPham set tensp = ?,ngaysua = ?,trangthai=? where maSP = ?",
                t.getTen(), t.getNgaySua(), t.getTrangThai(), t.getMa());
    }

    public int update(SanPham t, String x) {
        return DBConnect.executeUpdate("update SanPham set tensp = ?,ngaysua = ?,trangthai=? where tensp = ?",
                t.getTen(), t.getNgaySua(), t.getTrangThai(), x);
    }

    @Override
    public int insert(SanPham t) {
        return DBConnect.executeUpdate("insert into SanPham(ID,MASP,TENSP,NGAYTAO,NGAYSUA,TRANGTHAI) values (newID(),?,?,?,?,?)",
                t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete from SanPham where maSP = ?", t);
    }
}
