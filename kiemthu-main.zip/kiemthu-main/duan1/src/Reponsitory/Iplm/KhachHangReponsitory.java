/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.KhachHang;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

/**
 *
 * @author duy09
 */
public class KhachHangReponsitory implements IObjectReponsitory<KhachHang> {

    public final LoaiKhachHangReponsitory lkhr = new LoaiKhachHangReponsitory();

    @Override
    public List<KhachHang> selectBySQL(String sql, Object... args) {
        List<KhachHang> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql, args);
            while (r.next()) {
                list.add(new KhachHang(r.getString(1), r.getString(2),
                        r.getString(3), r.getDate(4), r.getString(5),
                        r.getString(6), r.getDate(7), r.getDate(7), r.getInt(9),
                        lkhr.selectByIDorMa(r.getString(10))));
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public List<KhachHang> selectAll() {
        return selectBySQL("Select*from KhachHang where TrangThai= 0");
    }

    public List<KhachHang> selectKhThuong() {
        return selectBySQL("Select*from KhachHang where TrangThai= 0 and idloaikh='B3410979-03DD-4276-B32F-682B1037BCCE' ");
    }

    public List<KhachHang> selectKhVip() {
        return selectBySQL("Select*from KhachHang where TrangThai= 0 and idloaikh='D4F3E47A-D3F1-4C3D-8F09-CD0DB1D10374' ");
    }

    @Override
    public List<KhachHang> selectByWhere(String where) {
        return selectBySQL("Select * from KhachHang where trangthai = 0 and maKh like ? "
                + "order by makh asc ", "%" + where + "%");
    }

    public List<KhachHang> selectAllAn() {
        return selectBySQL("Select * from KhachHang where trangthai = 1 "
                + "order by makh asc");
    }

    public int setAnkh(int index, String ma) {
        return DBConnect.executeUpdate("Update KhachHang set TrangThai = ? where makh = ? ", index, ma);
    }

    @Override
    public KhachHang selectByIDorMa(String x) {
        return selectBySQL("Select * from KhachHang where id = ?", x).get(0);
    }

    public KhachHang selectByMa(String x) {
        return selectBySQL("Select * from KhachHang where makh = ?", x).get(0);
    }

    @Override
    public int update(KhachHang t) {

        return DBConnect.executeUpdate("Update KhachHang set Hovaten = ? ,"
                + "ngaySinh = ? , sdt = ? , DiaChi = ? , trangthai = ?  , idloaikh =?  "
                + "where makh = ?  ", t.getHoVaTen(), t.getNgaySinh(),
                t.getSdt(), t.getDiaChi(), t.getTrangThai(), t.getLoaiKhachHang().getId(), t.getMa());
    }

    @Override
    public int insert(KhachHang t) {
        return DBConnect.executeUpdate("insert into KhachHang values"
                + "(newid(),?,?,?,?,?,?,?,?,?)", t.getMa(), t.getHoVaTen(), t.getNgaySinh(),
                t.getSdt(), t.getDiaChi(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai(),t.getLoaiKhachHang().getId());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete khachHang where Makh = ? ", t);
    }

    public List<KhachHang> selectBySDT(String x) {
        return selectBySQL("Select * from KhachHang where sdt = ?", x);
    }

    public int insertTaiQuay(KhachHang t) {
        return DBConnect.executeUpdate("insert into KhachHang(id,makh,hovaten,sdt,idloaikh,trangthai) values"
                + "(newid(),?,?,?,'B3410979-03DD-4276-B32F-682B1037BCCE',0)", t.getMa(), t.getHoVaTen(),
                t.getSdt());
    }

    public String selectID(String x) {
        return selectBySQL("Select * from KhachHang where makh = ?", x).get(0).getId();
    }

    public int insertGiaoHang(KhachHang t) {
        return DBConnect.executeUpdate("insert into KhachHang(id,makh,hovaten,sdt,idloaikh,trangthai,diachi) values"
                + "(newid(),?,?,?,'B3410979-03DD-4276-B32F-682B1037BCCE',0,?)", t.getMa(), t.getHoVaTen(),
                t.getSdt(), t.getDiaChi());
    }

    public List<KhachHang> getBanHang() {
        List<KhachHang> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select makh,hovaten,sdt from khachhang where trangthai = 0");
            while (rs.next()) {
                KhachHang x = new KhachHang();
                x.setHoVaTen(rs.getString(2));
                x.setMa(rs.getString(1));
                x.setSdt(rs.getString(3));
                list.add(x);
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<KhachHang> getBanHangMa(String ma) {
        List<KhachHang> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select makh,hovaten,sdt from khachhang where makh like ?", "%" + ma + "%");
            while (rs.next()) {
                KhachHang x = new KhachHang();
                x.setHoVaTen(rs.getString(2));
                x.setMa(rs.getString(1));
                x.setSdt(rs.getString(3));
                list.add(x);
            }
        } catch (Exception e) {
        }
        return list;
    }

    public KhachHang getBanHangKH(String ma) {
        KhachHang x = new KhachHang();
        try {
            ResultSet rs = DBConnect.executeQuery("select makh,hovaten,sdt from khachhang where makh = ?", ma);
            while (rs.next()) {
                x.setHoVaTen(rs.getString(2));
                x.setMa(rs.getString(1));
                x.setSdt(rs.getString(3));
            }
        } catch (Exception e) {
        }
        return x;
    }

    public String getIdByMa(String ma) {
        try {
            ResultSet rs = DBConnect.executeQuery("select id from khachhang where makh = ?", ma);
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (Exception e) {
        }
        return "";
    }

    public int updateLoaiKhachHang(String idLKH, String ma) {
        return DBConnect.executeUpdate("update KHACHHANG set IDLOAIKH = ? where MAKH = ?", idLKH, ma);
    }
}
