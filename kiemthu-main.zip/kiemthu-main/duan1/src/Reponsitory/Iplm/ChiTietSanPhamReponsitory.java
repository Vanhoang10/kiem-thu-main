/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.ChiTietSanPham;
import DomainModels.MauSac;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

/**
 *
 * @author duy09
 */
public class ChiTietSanPhamReponsitory implements IObjectReponsitory<ChiTietSanPham> {

    private KichCoReponsitory kcr = new KichCoReponsitory();
    private MauSacReponsitory msr = new MauSacReponsitory();
    private SanPhamReponsitory spr = new SanPhamReponsitory();
    private NSXReponsitory nsxr = new NSXReponsitory();
    private ChatLieuReponsitory clr = new ChatLieuReponsitory();
    private DongSPReponsitory dspr = new DongSPReponsitory();

    @Override
    public List<ChiTietSanPham> selectBySQL(String sql, Object... args) {
        List<ChiTietSanPham> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new ChiTietSanPham(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getBigDecimal(4),
                        rs.getBigDecimal(5),
                        rs.getString(6),
                        rs.getInt(7),
                        spr.selectByIDorMa(rs.getString(8)),
                        msr.selectByIDorMa(rs.getString(9)),
                        clr.selectByIDorMa(rs.getString(10)),
                        dspr.selectByIDorMa(rs.getString(11)),
                        nsxr.selectByIDorMa(rs.getString(12)),
                        kcr.selectByIDorMa(rs.getString(13)), rs.getBigDecimal(14)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<ChiTietSanPham> selectKM(String where) {
        List<ChiTietSanPham> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select ID,MACTSP,GIABAN,IDSP,IDMS,IDCL,IDDSP,IDNSX,IDKC"
                    + " from CHITIETSANPHAM where TRANGTHAI = 1 and IDKM like  ?", "%" + where + "%");
            while (rs.next()) {
                list.add(new ChiTietSanPham(rs.getString(1),
                        rs.getString(2), rs.getBigDecimal(3),
                        spr.selectByIDorMa(rs.getString(4)),
                        msr.selectByIDorMa(rs.getString(5)),
                        clr.selectByIDorMa(rs.getString(6)),
                        dspr.selectByIDorMa(rs.getString(7)),
                        nsxr.selectByIDorMa(rs.getString(8)),
                        kcr.selectByIDorMa(rs.getString(9))));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<ChiTietSanPham> selectAll() {
        return selectBySQL("Select * from CHITIETSANPHAM where TRANGTHAI = 1");
    }

    public List<ChiTietSanPham> selectAllAn() {
        return selectBySQL("Select * from CHITIETSANPHAM where TRANGTHAI = 0");
    }

    public List<ChiTietSanPham> selectWithKM(String where) {
        List<ChiTietSanPham> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select ID,MACTSP,GIABAN,IDSP,IDMS,IDCL,IDDSP,IDNSX,IDKC"
                    + " from CHITIETSANPHAM where TRANGTHAI = 1 and IDDSP like  ?", "%" + where + "%");
            while (rs.next()) {
                list.add(new ChiTietSanPham(rs.getString(1),
                        rs.getString(2), rs.getBigDecimal(3),
                        spr.selectByIDorMa(rs.getString(4)),
                        msr.selectByIDorMa(rs.getString(5)),
                        clr.selectByIDorMa(rs.getString(6)),
                        dspr.selectByIDorMa(rs.getString(7)),
                        nsxr.selectByIDorMa(rs.getString(8)),
                        kcr.selectByIDorMa(rs.getString(9))));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int setAn(int x, String item) {
        return DBConnect.executeUpdate("update CHITIETSANPHAM set TRANGTHAI = ? where MACTSP = ?", x, item);
    }

    @Override
    public List<ChiTietSanPham> selectByWhere(String where) {
        return selectBySQL("""
                           Select * from CHITIETSANPHAM where TRANGTHAI = 1 and MACTSP like ?
                           order by MACTSP asc
                           """, "%" + where + "%");
    }

    public List<ChiTietSanPham> loc(String where) {
        return selectBySQL("Select * from CHITIETSANPHAM where TRANGTHAI = 1 and IDDSP = ?", where);
    }

    @Override
    public ChiTietSanPham selectByIDorMa(String x) {
        return selectBySQL("Select * from CHITIETSANPHAM where ID = ?", x).get(0);
    }

    public ChiTietSanPham selectByMa(String x) {
        return selectBySQL("Select * from CHITIETSANPHAM where TRANGTHAI = 1 and MACTSP = ?", x).get(0);
    }
    public ChiTietSanPham selectByMaa(String x) {
        return selectBySQL("Select * from CHITIETSANPHAM where  MACTSP = ?", x).get(0);
    }

    @Override
    public int update(ChiTietSanPham t) {
        return DBConnect.executeUpdate("""
                                       update CHITIETSANPHAM
                                       set
                                       SOLUONGTON=?,
                                       GIANHAP=?,
                                       GIABAN=?,
                                       MOTA=?,
                                       TRANGTHAI=?,
                                       IDSP=?,
                                       IDMS=?,
                                       IDCL=?,
                                       IDDSP=?,
                                       IDNSX=?,
                                       IDKC=?,
                                       DONGIAKM =?
                                       where MACTSP=?
                                       """,
                t.getSoLuongTon(),
                t.getGiaNhap(),
                t.getGiaBan(),
                t.getMoTa(),
                t.getTrangThai(),
                t.getSanPham().getId(),
                t.getMauSac().getId(),
                t.getChatLieu().getId(),
                t.getDongSP().getId(),
                t.getNsx().getId(),
                t.getKichCo().getId(),
                t.getDonGianKhiGiam(),
                t.getMa()
        );
    }

    public int updateKM(ChiTietSanPham t) {
        return DBConnect.executeUpdate("""
                                       update CHITIETSANPHAM set
                                       DONGIAKM =?
                                       where MACTSP=?
                                       """, t.getDonGianKhiGiam(), t.getMa());
    }

    @Override
    public int insert(ChiTietSanPham t) {
        return DBConnect.executeUpdate("""
                                       insert into CHITIETSANPHAM 
                                       values 
                                       (newID(),?,?,?,?,?,?,?,?,?,?,?,?,?)
                                       """,
                t.getMa(),
                t.getSoLuongTon(),
                t.getGiaNhap(),
                t.getGiaBan(),
                t.getMoTa(),
                t.getTrangThai(),
                t.getSanPham().getId(),
                t.getMauSac().getId(),
                t.getChatLieu().getId(),
                t.getDongSP().getId(),
                t.getNsx().getId(),
                t.getKichCo().getId(),
                t.getDonGianKhiGiam());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("delete from CHITIETSANPHAM where MACTSP = ?", t);
    }

    public int updateBanHang(ChiTietSanPham x) {
        return DBConnect.executeUpdate("update chitietsanpham set soluongton = ? where mactsp = ?", x.getSoLuongTon(), x.getMa());
    }

// THỐNG KÊ 
    public List<ChiTietSanPham> sapHetHang() {
        return selectBySQL("select *from ChiTietSanPham where SoLuongTon <10 and trangthai = 1");
    }

    public List<ChiTietSanPham> HetHang() {
        return selectBySQL("select *from ChiTietSanPham where SoLuongTon =0 and trangthai = 1");
    }

    public List<ChiTietSanPham> SanPhamTable() {
        return selectBySQL("""
                           SELECT* FROM CHITIETSANPHAM 
                           ORDER BY MACTSP asc
                           """);
    }

    public String getIdByMa(String ma) {
        try {
            ResultSet rs = DBConnect.executeQuery("SELECT id FROM CHITIETSANPHAM where mactsp = ?", ma);
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (Exception e) {
        }
        return "";
    }

    public int updateBanHang(int a, String b) {
        return DBConnect.executeUpdate("update chitietsanpham set soluongton = ? where mactsp = ?", a, b);
    }
    
    public int getSL(String ma){
        try {
            ResultSet rs = DBConnect.executeQuery("select soluongton from chitietsanpham where mactsp = ?", ma);
            while (rs.next()) {                
                return rs.getInt(1);
            }
        } catch (Exception e) {
        }
        return 0;
    }

}
