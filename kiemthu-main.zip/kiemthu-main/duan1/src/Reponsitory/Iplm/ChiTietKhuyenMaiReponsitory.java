/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.ChiTietKhuyenMai;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

/**
 *
 * @author duy09
 */
public class ChiTietKhuyenMaiReponsitory implements IObjectReponsitory<ChiTietKhuyenMai> {

    private KhuyenMaiReponsitory kmr = new KhuyenMaiReponsitory();
    private ChiTietSanPhamReponsitory ctr = new ChiTietSanPhamReponsitory();

    @Override
    public List<ChiTietKhuyenMai> selectBySQL(String sql, Object... args) {
        List<ChiTietKhuyenMai> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new ChiTietKhuyenMai(
                        rs.getString(1),
                        rs.getString(2),
                        kmr.selectByIDorMa(rs.getString(3)),
                        ctr.selectByIDorMa(rs.getString(4)),
                        rs.getBigDecimal(5),
                        rs.getBoolean(6)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<ChiTietKhuyenMai> selectByKM(String x) {
        return selectBySQL("SELECT * FROM CHITIETKHUYENMAI where idkm like ? ", "%" + x + "%");
    }

    @Override
    public List<ChiTietKhuyenMai> selectAll() {
        return selectBySQL("SELECT * FROM CHITIETKHUYENMAI");
    }

    @Override
    public List<ChiTietKhuyenMai> selectByWhere(String where) {
        return selectBySQL("SELECT * FROM CHITIETKHUYENMAI WHERE IDKM like ?", "%" + where + "%");
    }

    public List<ChiTietKhuyenMai> selectBySP(String where) {
        List<ChiTietKhuyenMai> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select DISTINCT IDKM,IDCTSP from chitietkhuyenmai");
            while (rs.next()) {
                list.add(new ChiTietKhuyenMai(
                        kmr.selectByIDorMa(rs.getString(1)),
                        ctr.selectByIDorMa(rs.getString(2))));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public ChiTietKhuyenMai selectByIDorMa(String x) {
        return selectBySQL("SELECT * FROM CHITIETKHUYENMAI WHERE MACTKM = ?", x).get(0);
    }

    @Override
    public int update(ChiTietKhuyenMai t) {
        return DBConnect.executeUpdate("update CHITIETKHUYENMAI idkm=?,idctsp=?,trangthai =? where idkm = ?",
                t.getKhuyenMai().getId(), t.getChiTietSanPham().getId(), t.isTrangThai(), t.getMa());
    }

    public int updateSP(ChiTietKhuyenMai t) {
        return DBConnect.executeUpdate("update CHITIETKHUYENMAI set trangthai =? where idkm = ? and idctsp=?",
                t.isTrangThai(), t.getKhuyenMai().getId(), t.getChiTietSanPham().getId());
    }

    @Override
    public int insert(ChiTietKhuyenMai t) {
        return DBConnect.executeUpdate("insert into CHITIETKHUYENMAI values (NEWID(),?,?,?,?,?)",
                t.getMa(), t.getKhuyenMai().getId(), t.getChiTietSanPham().getId(), t.getDonGiaKhiGiam(), t.isTrangThai());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("delete from CHITIETKHUYENMAI where MACTKM = ?", t);
    }

    public int delete() {
        return DBConnect.executeUpdate("delete from CHITIETKHUYENMAI where idctsp is null");
    }

}
