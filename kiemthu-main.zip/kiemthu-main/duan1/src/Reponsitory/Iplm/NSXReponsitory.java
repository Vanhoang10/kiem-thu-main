/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.NSX;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class NSXReponsitory implements IObjectReponsitory<NSX>{
    @Override
    public List<NSX> selectBySQL(String sql, Object... args) {
        List<NSX> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new NSX(rs.getString(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getDate(5), rs.getInt(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public List<NSX> selectAll() {
        return selectBySQL("Select * from NSX order by maNSX asc");
    }

    @Override
    public List<NSX> selectByWhere(String where) {
        return selectBySQL("select * from NSX where maNSX like ?", "%" + where + "%");
    }

    @Override
    public NSX selectByIDorMa(String x) {
        return selectBySQL("select * from NSX where id = ? ", x).get(0);
    }

    @Override
    public int update(NSX t) {
        return DBConnect.executeUpdate("update NSX set tennsx = ?,ngaysua = ?,trangthai=? where mansx = ?",
                t.getTen(), t.getNgaySua(), t.getTrangThai(),t.getMa());
    }

    @Override
    public int insert(NSX t) {
        return DBConnect.executeUpdate("insert into nsx values (newID(),?,?,?,?,?)",
                t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete from nsx where id = ?", t);
    }
}
