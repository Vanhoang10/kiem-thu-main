/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.MauSac;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class MauSacReponsitory implements IObjectReponsitory<MauSac>{
     @Override
    public List<MauSac> selectBySQL(String sql, Object... args) {
        List<MauSac> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new MauSac(rs.getString(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getDate(5), rs.getInt(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public List<MauSac> selectAll() {
        return selectBySQL("Select * from MauSac order by mams asc");
    }

    @Override
    public List<MauSac> selectByWhere(String where) {
        return selectBySQL("select * from MauSac where mams like ?", "%" + where + "%");
    }

    @Override
    public MauSac selectByIDorMa(String x) {
        return selectBySQL("select * from MauSac where id = ? ", x).get(0);
    }

    @Override
    public int update(MauSac t) {
        return DBConnect.executeUpdate("update MauSac set tenms = ?,ngaysua = ?,trangthai=? where mams = ?",
                t.getTen(), t.getNgaySua(), t.getTrangThai(),t.getMa());
    }

    @Override
    public int insert(MauSac t) {
        return DBConnect.executeUpdate("insert into MauSac values (newID(),?,?,?,?,?)",
                t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete from MauSac where id = ?", t);
    }
}
