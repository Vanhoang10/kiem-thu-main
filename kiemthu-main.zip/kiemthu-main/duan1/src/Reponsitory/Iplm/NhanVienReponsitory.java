/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.NhanVien;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author duy09
 */
public class NhanVienReponsitory implements IObjectReponsitory<NhanVien> {

    ChucVuReponsitory cvr = new ChucVuReponsitory();

    @Override
    public List<NhanVien> selectBySQL(String sql, Object... args) {
        List<NhanVien> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql, args);
            while (r.next()) {
                list.add(new NhanVien(r.getString(1), r.getString(2), r.getString(3),
                        r.getBoolean(4), r.getDate(5), r.getString(6), r.getString(7),
                        r.getString(8), r.getString(9), r.getString(10), r.getInt(11),
                        cvr.selectByIDorMa(r.getString(12))));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<NhanVien> selectAll() {
        return selectBySQL("""
                           Select*From nhanvien 
                           order by MANV asc
                           """);
    }

    @Override
    public List<NhanVien> selectByWhere(String where) {
        return selectBySQL("Select*From nhanvien where MaNV like ?", "%" + where + "%");
    }

    @Override
    public NhanVien selectByIDorMa(String x) {
        return selectBySQL("Select *from NhanVien where MaNV = ?", x).get(0);
    }

    public NhanVien selectByID(String x) {
        return selectBySQL("Select * from NhanVien where id = ?", x).get(0);
    }

    @Override
    public int update(NhanVien t) {
        return DBConnect.executeUpdate("Update NhanVien set Hovaten = ? ,"
                + " GioiTinh = ? , NgaySinh = ? , cmt_cccd= ? , DiaChi = ?,"
                + "Sdt = ? , email = ? , TrangThai = ? , idCV=? "
                + " where maNV = ?", t.getHoVaTen(),
                t.isGioiTinh(), t.getNgaySinh(), t.getCmt_cccd(),
                t.getDiaChi(), t.getSdt(), t.getEmail(),
                t.getTrangThai(), t.getChucVu().getId(), t.getMa());
    }

    @Override
    public int insert(NhanVien t) {
        return DBConnect.executeUpdate("insert into nhanvien values"
                + "(newid(),?,?,?,?,?,?,?,?,'123456',?,?)", t.getMa(), t.getHoVaTen(),
                t.isGioiTinh(), t.getNgaySinh(), t.getCmt_cccd(),
                t.getDiaChi(), t.getSdt(), t.getEmail(),
                t.getTrangThai(), t.getChucVu().getId());

    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete nhanvien where ma = ?", t);
    }

    public List<NhanVien> loc(String where) {
        return selectBySQL("select * from NhanVien where idCv = ? ", where);
    }

    public String login(String email, String matKhau) {
        try {
            ResultSet rs = DBConnect.executeQuery("select MANV from NHANVIEN where EMAIL = ? and MATKHAU = ?", email, matKhau);
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (Exception e) {
        }
        return "";
    }

    public String forgin(String email) {
        try {
            ResultSet rs = DBConnect.executeQuery("select MANV from NHANVIEN where EMAIL = ? ", email);
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (Exception e) {
        }
        return "";
    }

    public int layLaiMK(String email, String mkm) {
        return DBConnect.executeUpdate("update NHANVIEN set MATKHAU = ? where EMAIL = ?", mkm, email);
    }

    public NhanVien getByMa(String ma) {
        NhanVien x = new NhanVien();
        try {
            ResultSet rs = DBConnect.executeQuery("select matkhau, email from nhanvien where manv = ?", ma);
            while (rs.next()) {
                x.setMatKhau(rs.getString(1));
                x.setEmail(rs.getString(2));
            }
        } catch (Exception e) {
        }
        return x;
    }
}
