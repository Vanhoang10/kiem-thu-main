/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.KichCo;
import DomainModels.MauSac;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class KichCoReponsitory implements IObjectReponsitory<KichCo> {

    @Override
    public List<KichCo> selectBySQL(String sql, Object... args) {
        List<KichCo> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new KichCo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getDate(5), rs.getInt(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public List<KichCo> selectAll() {
        return selectBySQL("Select * from KichCo order by makc asc");
    }

    @Override
    public List<KichCo> selectByWhere(String where) {
        return selectBySQL("select * from KichCo where makc like ?", "%" + where + "%");
    }

    @Override
    public KichCo selectByIDorMa(String x) {
        return selectBySQL("select * from KichCo where id = ? ", x).get(0);
    }

    @Override
    public int update(KichCo t) {
        return DBConnect.executeUpdate("update KichCo set tenkc = ?,ngaysua = ?,trangthai=? where makc = ?",
                t.getTen(), t.getNgaySua(), t.getTrangThai(),t.getMa());
    }

    @Override
    public int insert(KichCo t) {
        return DBConnect.executeUpdate("insert into KichCo values (newID(),?,?,?,?,?)",
                t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete from KichCo where id = ?", t);
    }
}
