/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.ChiTietSanPham;
import DomainModels.KhuyenMai;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

/**
 *
 * @author duy09
 */
public class KhuyenMaiReponsitory implements IObjectReponsitory<KhuyenMai> {

    private ChiTietSanPhamReponsitory ctr = new ChiTietSanPhamReponsitory();

    @Override
    public List<KhuyenMai> selectBySQL(String sql, Object... args) {
        List<KhuyenMai> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new KhuyenMai(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDouble(4),
                        rs.getDate(5),
                        rs.getDate(6),
                        rs.getInt(7)));
            }

        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public List<KhuyenMai> selectAll() {
        return selectBySQL("Select * from khuyenmai");
    }

    @Override
    public List<KhuyenMai> selectByWhere(String where) {

        return selectBySQL("""
                           Select * from khuyenmai where id like ?
                           order by TRANGTHAI desc
                           """, "%" + where + "%");
    }

    @Override
    public KhuyenMai selectByIDorMa(String x) {
        return selectBySQL("Select *from khuyenmai where id = ?", x).get(0);
    }

    public KhuyenMai selectByTen(String x) {
        return selectBySQL("Select *from khuyenmai where TENKM = ?", x).get(0);
    }

    public String selectIDOne(String x) {
        List<KhuyenMai> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("Select id from khuyenmai where TENKM = ?", x);
            while (rs.next()) {
                list.add(new KhuyenMai(rs.getString(1)));
            }
        } catch (Exception e) {
        }
        return list.get(0).getId();
    }

    @Override
    public int update(KhuyenMai t) {
        return DBConnect.executeUpdate("update KHUYENMAI set TENKM=?,MUCGIAMGIA=?,THOIGIANBATDAU=?,THOIGIANKETTHUC=?,TRANGTHAI=? where MAKM =?",
                t.getTen(),
                t.getMucGiaGiam(),
                t.getThoiGianBatDau(),
                t.getThoiGianKetThuc(),
                t.getTrangthai(),
                t.getMa());
    }

    public int update(KhuyenMai t, String x) {
        return DBConnect.executeUpdate("update KHUYENMAI set TENKM=?,MUCGIAMGIA=?,THOIGIANBATDAU=?,THOIGIANKETTHUC=?,TRANGTHAI=? where TENKM =?",
                t.getTen(),
                t.getMucGiaGiam(),
                t.getThoiGianBatDau(),
                t.getThoiGianKetThuc(),
                t.getTrangthai(),
                x);
    }

    @Override
    public int insert(KhuyenMai t) {
        return DBConnect.executeUpdate("insert into KHUYENMAI values( NEWID(),?,?,?,?,?,?)",
                t.getMa(),
                t.getTen(),
                t.getMucGiaGiam(),
                t.getThoiGianBatDau(),
                t.getThoiGianKetThuc(),
                t.getTrangthai());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete KHUYENMAI where ma = ?", t);
    }

}
