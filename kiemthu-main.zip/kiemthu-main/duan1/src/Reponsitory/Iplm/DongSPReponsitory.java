/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.DongSP;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author duy09
 */
public class DongSPReponsitory implements IObjectReponsitory<DongSP> {

    @Override
    public List<DongSP> selectBySQL(String sql, Object... args) {
        List<DongSP> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery(sql, args);
            while (rs.next()) {
                list.add(new DongSP(rs.getString(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getDate(5), rs.getInt(6)));
            }

        } catch (Exception e) {
        }
        return list;
    }

    //demo code form nhanh khacs
    // 1 nguoi nao do sua va day code moi len!
    @Override
    public List<DongSP> selectAll() {
        return selectBySQL("Select * from DongSP order by madsp asc");
    }

    @Override
    public List<DongSP> selectByWhere(String where) {
        return selectBySQL("select * from DongSP where madsp like ?", "%" + where + "%");
    }

    @Override
    public DongSP selectByIDorMa(String x) {
        return selectBySQL("select * from DongSP where id = ? ", x).get(0);
    }

    @Override
    public int update(DongSP t) {
        return DBConnect.executeUpdate("update DongSP set tendsp = ?,ngaysua = ?,trangthai=? where maDsp = ?",
                t.getTen(), t.getNgaySua(), t.getTrangThai(), t.getMa());
    }

    @Override
    public int insert(DongSP t) {
        return DBConnect.executeUpdate("insert into DongSP values (newID(),?,?,?,?,?)",
                t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete from DongSP where maDsp = ?", t);
    }

}
