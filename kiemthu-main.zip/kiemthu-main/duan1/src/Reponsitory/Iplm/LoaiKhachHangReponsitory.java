/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;


import DomainModels.LoaiKhachHang;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class LoaiKhachHangReponsitory implements IObjectReponsitory<LoaiKhachHang>{

    @Override
    public List<LoaiKhachHang> selectBySQL(String sql, Object... args) {
            List<LoaiKhachHang> list = new ArrayList<>();
            try {
                ResultSet r = DBConnect.executeQuery(sql, args);
                while (r.next()) {                    
                    list.add(new LoaiKhachHang(r.getString(1), r.getString(2),
                            r.getString(3), r.getFloat(4), r.getDate(5), r.getDate(6), r.getInt(7)));
                }
        } catch (Exception e) {
        }
            return list;
    }

    @Override
    public List<LoaiKhachHang> selectAll() {
        return selectBySQL("Select *from LoaiKhachHang");
    }

    @Override
    public List<LoaiKhachHang> selectByWhere(String where) {
        return selectBySQL("Selct * from LoaiKhachHang where maloaikh like","%" + where +"%");
    }

    @Override
    public LoaiKhachHang selectByIDorMa(String x) {
        return selectBySQL("Select * from loaiKhachHang where id = ?", x).get(0);
    }

    @Override
    public int update(LoaiKhachHang t) {
        return DBConnect.executeUpdate("Update LoaiKhachHang set"
                + "tenLoaiKh = ? , DacQuyen = ? , NgayTao = ? , "
                + "NgaySua = ? , TrangThai = ? "
                + "where maLoaiKh = ?  ", t.getTen(),t.getDacQuyen(),t.getNgayTao(),
                t.getNgaySua(),t.getTrangThai(),t.getMa());
    }

    @Override
    public int insert(LoaiKhachHang t) {
        return DBConnect.executeUpdate("insert into LoaiKhachHang values"
                + "(newid(),?,?,?,?,?,?) ",t.getMa(),t.getTen(),t.getDacQuyen(),
                t.getNgayTao(),t.getNgaySua(),t.getTrangThai());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete LoaiKhachHang where maLoaikh = ? ", t);
    }
   public String getIdByMa(String ma){
       try {
           ResultSet rs = DBConnect.executeQuery("select id from LOAIKHACHHANG where MALOAIKH = ?", ma);
           while (rs.next()) {               
               return rs.getString(1);
           }
       } catch (Exception e) {
       }
       return "";
   }
}
