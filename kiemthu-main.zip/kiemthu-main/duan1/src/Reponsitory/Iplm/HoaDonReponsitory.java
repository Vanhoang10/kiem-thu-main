/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.HoaDon;
import DomainModels.KhachHang;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author duy09
 */
public class HoaDonReponsitory implements IObjectReponsitory<HoaDon> {

    KhachHangReponsitory khr = new KhachHangReponsitory();
    NhanVienReponsitory nvr = new NhanVienReponsitory();
    HinhThucThanhToanReponsitory ttr = new HinhThucThanhToanReponsitory();

    @Override
    public List<HoaDon> selectBySQL(String sql, Object... args) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql, args);

            while (r.next()) {
                list.add(new HoaDon(r.getString(1), khr.selectByIDorMa(r.getString(2)), nvr.selectByID(r.getString(3)),
                        r.getString(4), r.getDate(5), r.getDate(6), r.getDate(7), r.getDate(8),
                        r.getInt(9), r.getString(10), r.getString(11), r.getString(12), ttr.selectByIDorMa(r.getString(13)), r.getBigDecimal(14)));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<HoaDon> selectAll() {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select IDNV,MAHD,NGAYTAO,TRANGTHAI from HoaDon where trangthai = 1 or trangthai = 2 order by trangthai asc");
            while (rs.next()) {
                list.add(new HoaDon(nvr.selectByID(rs.getString(1)), rs.getString(2), rs.getDate(3), rs.getInt(4)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public HoaDon selectCT(String x) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select ID, IDNV,MAHD,NGAYTAO,TRANGTHAI from HoaDon where (trangthai = 1 or trangthai = 2) and mahd  = ?", x);
            while (rs.next()) {
                list.add(new HoaDon(rs.getString(1), nvr.selectByID(rs.getString(2)), rs.getString(3), rs.getDate(4), rs.getInt(5)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list.get(0);
    }

    @Override
    public List<HoaDon> selectByWhere(String where) {
        return selectBySQL("Select*from HoaDOn where MaHD = ? ", "%" + where + "%");
    }

    @Override
    public HoaDon selectByIDorMa(String x) {
        return selectBySQL("select*from HoaDon where id = ?", x).get(0);
    }

    public HoaDon selectByIDFill(String x) {
        return selectBySQL("select*from HoaDon where id = ?", x).get(0);
    }

    @Override
    public int update(HoaDon t) {
        return DBConnect.executeUpdate("Update HoaDon set"
                + "NgayTao= ? , NgayThanhToan = ? , ngayGiao = ? , "
                + "NgayNhan = ? , TrangThai = ? TenNguoiNhan = ? , Sdt = ? , DiaChi =?, idtt = ?,tongtien =?"
                + "Where MaHD = ?  ", t.getNgayTao(), t.getNgayThanhToan(), t.getNgayGiao(),
                t.getNgayNhan(), t.getTrangThai(), t.getTenNguoiNhan(),
                t.getSdt(), t.getDiaChi(), t.getThanhToan().getId(), t.getTongTien(), t.getMa());
    }

    @Override
    public int insert(HoaDon t) {
        return DBConnect.executeUpdate("insert into HoaDon Values"
                + "(newid(),?,?,?,?,?,?,?,?,?,?,?,?,?", t.getKhachHang().getId(), t.getNhanVien().getId(), t.getMa(),
                t.getNgayTao(), t.getNgayThanhToan(), t.getNgayGiao(), t.getNgayNhan(), t.getTrangThai(),
                t.getTenNguoiNhan(), t.getSdt(), t.getDiaChi(), t.getThanhToan().getId(), t.getTongTien());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete HoaDon Where MaHD=?", t);
    }

    public int insertNew(HoaDon t) {
        return DBConnect.executeUpdate("insert into HOADON(ID,IDNV,MAHD,TRANGTHAI) values (NEWID(),?,?,?)",
                t.getNhanVien().getId(), t.getMa(), t.getTrangThai());
    }

    public int updateTT(HoaDon t) {
        return DBConnect.executeUpdate("Update HoaDon set"
                + "NgayTao= ? , NgayThanhToan = ? , ngayGiao = ? , "
                + "NgayNhan = ? , TrangThai = ? TenNguoiNhan = ? , Sdt = ? , DiaChi =?, idtt = ?"
                + "Where MaHD = ?  ", t.getNgayTao(), t.getNgayThanhToan(), t.getNgayGiao(),
                t.getNgayNhan(), t.getTrangThai(), t.getTenNguoiNhan(),
                t.getSdt(), t.getDiaChi(), t.getThanhToan().getId(), t.getMa());
    }

    public int delete(String a, String b) {
        return DBConnect.executeUpdate("Delete HoaDon Where MaHD=? and masp = ?", a, b);
    }

    public int updateHuy(String ma) {
        return DBConnect.executeUpdate("update hoadon set trangthai = 0 where mahd = ?", ma);
    }

    public int updateHoanThanh(HoaDon ma) {
        return DBConnect.executeUpdate("update hoadon set idkh = ?, idnv=?, tongtien = ? where mahd=?", ma.getKhachHang().getId(), ma.getNhanVien().getId(),
                ma.getTongTien(), ma.getMa());
    }

    public int updateThanhToan(HoaDon ma) {
        return DBConnect.executeUpdate("update hoadon set tongtien = ?, NGAYTHANHTOAN = getDate(), trangthai = 3, idtt = ? where mahd=?",
                ma.getKhachHang().getId(),
                ma.getThanhToan().getId(),
                ma.getTongTien(), ma.getMa());
    }

    public List<HoaDon> selectByKH(String id) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select id,mahd,ngaytao,tongtien from hoadon where idkh = ?", id);
            while (rs.next()) {
                list.add(new HoaDon(rs.getString(1), rs.getString(2), rs.getDate(3), rs.getBigDecimal(4)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public BigDecimal selectTongTien(String id) {
        BigDecimal tt = new BigDecimal(0);
        try {
            ResultSet rs = DBConnect.executeQuery("select id,mahd,ngaytao,tongtien from hoadon where trangthai = 3 and idkh = ?", id);
            while (rs.next()) {
                tt = tt.add(rs.getBigDecimal(4));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tt;
    }

    public String selectIDOne(String x) {
        try {
            ResultSet rs = DBConnect.executeQuery("select ID from HoaDon where mahd = ?", x);
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int updateTToan(HoaDon x) {
        return DBConnect.executeUpdate("update hoadon set idkh = ?,ngayTao=GETDATE(),NGAYTHANHTOAN=GETDATE(), idtt=?,trangthai =3,tongtien=?,tennguoinhan=?,sdt=? where mahd=?",
                x.getKhachHang().getId(), x.getThanhToan().getId(), x.getTongTien(), x.getTenNguoiNhan(), x.getSdt(), x.getMa());
    }

    public int updateGHang(HoaDon x) {
        System.out.println(x.getTongTien());
        return DBConnect.executeUpdate("update hoadon set idkh = ?,ngaygiao=GETDATE(),idtt=?,trangthai =2,tongtien=?,diachi =?,tennguoinhan=?,sdt=? where mahd=?",
                x.getKhachHang().getId(), x.getThanhToan().getId(), x.getTongTien(), x.getDiaChi(), x.getTenNguoiNhan(), x.getSdt(), x.getMa());
    }

    public HoaDon selectID(String x) {
        try {
            ResultSet rs = DBConnect.executeQuery("select idKH,mahd,tennguoinhan,sdt,diachi,idtt,tongtien from HoaDon where id  = ?", x);
            while (rs.next()) {
                return new HoaDon(khr.selectByIDorMa(rs.getString(1)),
                        rs.getString(2), rs.getString(3), rs.getString(4),
                        rs.getString(5), ttr.selectByIDorMa(rs.getString(6)), rs.getBigDecimal(7));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public HoaDon selectByID(String x) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select ID,IDNV,MAHD,NGAYTAO,TRANGTHAI from HoaDon where id  = ?", x);
            while (rs.next()) {
                list.add(new HoaDon(rs.getString(1), nvr.selectByID(rs.getString(2)), rs.getString(3), rs.getDate(4), rs.getInt(5)));
            }
        } catch (Exception e) {
        }
        return list.get(0);
    }

    // thống kê hóa đơn
    public List<HoaDon> HoaDonThongKe(String sql) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql);

            while (r.next()) {
                list.add(new HoaDon(r.getInt(1)));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<HoaDon> HoaDonDangCho() {
        return HoaDonThongKe("SELECT TRANGTHAI FROM HOADON WHERE TRANGTHAI=1");
    }

    public List<HoaDon> HoaDonHuy() {
        return HoaDonThongKe("SELECT TRANGTHAI FROM HOADON WHERE TRANGTHAI=0");
    }

    public List<HoaDon> HoaDonDangGiao() {
        return HoaDonThongKe("SELECT TRANGTHAI FROM HOADON WHERE TRANGTHAI=2");
    }

    public List<HoaDon> HoaDonDaNhan() {
        return HoaDonThongKe("SELECT TRANGTHAI FROM HOADON WHERE TRANGTHAI=3");
    }

    public List<HoaDon> HoaDonTong() {
        return HoaDonThongKe("SELECT TRANGTHAI FROM HOADON ");
    }

    public int updateNhanHang(String x) {
        return DBConnect.executeUpdate("update hoadon set trangthai = 3,ngaytao=GETDATE(),NGAYNHAN=GETDATE(),NGAYTHANHTOAN=GETDATE() WHERE MAHD =?", x);
    }

    public List<HoaDon> hoaDon(String sql, Object... args) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql, args);
            while (r.next()) {
                list.add(new HoaDon(r.getString(1), r.getDate(2), r.getInt(3),
                        r.getString(4), r.getString(5), r.getBigDecimal(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<HoaDon> HoaDonThongKeTable() {
        return hoaDon("Select   mahd  ,ngaytao,  trangthai,TENNGUOINHAN,SDT , tongtien from hoadon "
                + "order by ngaytao desc");
    }

    public List<HoaDon> hoaDonTimKiem(String where) {
        return hoaDon("""
                            Select   mahd  ,ngaytao,  trangthai,TENNGUOINHAN,SDT , tongtien from hoadon
                            where mahd like ?""", "%" + where + "%");
    }

    public List<HoaDon> selectLichSu() {
        List<HoaDon> list = new ArrayList<>();
        try {

            ResultSet rs = DBConnect.executeQuery("select IDNV,MAHD,TENNGUOINHAN,TRANGTHAI from HoaDon order by NGAYTAO desc");
            while (rs.next()) {
                list.add(new HoaDon(nvr.selectByID(rs.getString(1)), rs.getString(2), rs.getInt(4), rs.getString(3)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<HoaDon> selectHDCho(int a) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select IDNV,MAHD,TENNGUOINHAN,TRANGTHAI from HoaDon where trangthai = ? order by NGAYTAO asc", a);

            while (rs.next()) {
                list.add(new HoaDon(nvr.selectByID(rs.getString(1)), rs.getString(2), rs.getInt(4), rs.getString(3)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<HoaDon> selectLichSuTK(String ma) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnect.executeQuery("select IDNV,MAHD,TENNGUOINHAN,TRANGTHAI from HoaDon where mahd like ?", "%" + ma + "%");
            while (rs.next()) {
                list.add(new HoaDon(nvr.selectByID(rs.getString(1)), rs.getString(2), rs.getInt(4), rs.getString(3)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public HoaDon selectByMaLS(String x) {
        try {
            ResultSet rs = DBConnect.executeQuery("select id,idnv,mahd,ngaythanhtoan,trangthai,tennguoinhan,sdt,diachi,tongtien from hoadon where mahd = ?", x);
            while (rs.next()) {
                return new HoaDon(rs.getString(1), nvr.selectByID(rs.getString(2)), rs.getString(3), rs.getDate(4),
                        rs.getInt(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getBigDecimal(9));
            }
        } catch (Exception e) {
        }
        return null;
    }
    // Thống kê doanh thu 

    public List<HoaDon> selectByDoanhThuNgay() {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery("SELECT SUM(TONGTIEN) FROM HOADON "
                    + "WHERE DAY(NGAYTAO)=DAY(GETDATE()) AND MONTH(NGAYTAO)=MONTH(GETDATE())"
                    + "AND YEAR(NGAYTAO)=YEAR(GETDATE()) and trangthai = 3");

            while (r.next()) {
                list.add(new HoaDon(r.getBigDecimal(1)));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<HoaDon> DoanhThu(String sql) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql);

            while (r.next()) {
                list.add(new HoaDon(r.getBigDecimal(1)));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<HoaDon> SelectDoanhThuThang() {
        return DoanhThu("SELECT SUM(TONGTIEN) FROM HOADON "
                + "WHERE  MONTH(NGAYTAO)=MONTH(GETDATE())"
                + "AND YEAR(NGAYTAO)=YEAR(GETDATE()) and trangthai = 3");
    }

    public List<HoaDon> selectDoanhThuNam() {
        return DoanhThu("SELECT SUM(TONGTIEN) FROM HOADON "
                + "WHERE YEAR(NGAYTAO)=YEAR(GETDATE()) and trangthai = 3 ");
    }

    public List<HoaDon> selectDoanhThuAll() {
        return DoanhThu("SELECT SUM(TONGTIEN) FROM HOADON where trangthai = 3");
    }

    // Doanh thu Table 
    public List<HoaDon> SelectThongKeDoanhThu(String sql, Object... args) {
        List<HoaDon> List = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql, args);
            while (r.next()) {
                List.add(new HoaDon(r.getString(1), r.getDate(2),
                        r.getBigDecimal(3)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return List;
    }

    public List<HoaDon> SelectThongKeDoanhThuTable() {
        return SelectThongKeDoanhThu("""
                                      SELECT  COUNT(ID), NGAYTAO ,SUM(TONGTIEN) FROM HOADON
                                      WHERE trangthai = 3
                                      group by ngaytao 
                                     order by ngaytao desc
                                     """);
    }

    public List<HoaDon> Loc1SelectThongKeDoanhThuTable() {
        return SelectThongKeDoanhThu("""
                                       SELECT  COUNT(ID), NGAYTAO ,SUM(TONGTIEN) FROM HOADON
                                        WHERE trangthai = 3 and year(ngaytao) = year('2022')
                                        group by ngaytao  
                                     order by ngaytao desc
                                      """);
    }

    public List<HoaDon> Loc2SelectThongKeDoanhThuTable() {
        return SelectThongKeDoanhThu("""
                                      SELECT  COUNT(ID), NGAYTAO ,SUM(TONGTIEN) FROM HOADON
                                       WHERE trangthai = 3 and year(ngaytao) = year('2023')
                                       group by ngaytao  
                                     order by ngaytao desc
                                      """);
    }

    public List<HoaDon> KhoangNgayThongKeDoanhThuTable(Date ngay1, Date ngay2) {
        return SelectThongKeDoanhThu("""
                                     SELECT  COUNT(ID), NGAYTAO ,SUM(TONGTIEN) FROM HOADON
                                     where ngaytao between ? and ?
                                     group by ngaytao 
                                     order by ngaytao desc
                                     """, ngay1, ngay2);
    }

    public String getIdByMa(String x) {
        try {
            ResultSet rs = DBConnect.executeQuery("select id from hoadon where mahd = ?", x);
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (Exception e) {
        }
        return "";
    }
}
