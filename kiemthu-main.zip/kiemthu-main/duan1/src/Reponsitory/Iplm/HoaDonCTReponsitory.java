/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.HoaDon;
import DomainModels.HoaDonCT;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import ViewModel.QLHoaDonCT;
import static java.lang.reflect.Array.set;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author duy09
 */
public class HoaDonCTReponsitory implements IObjectReponsitory<HoaDonCT> {

    ChiTietSanPhamReponsitory ctspr = new ChiTietSanPhamReponsitory();
    HoaDonReponsitory hdr = new HoaDonReponsitory();

    @Override
    public List<HoaDonCT> selectBySQL(String sql, Object... args) {
        List<HoaDonCT> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql, args);
            while (r.next()) {
                list.add(new HoaDonCT(r.getString(1), hdr.selectByID(r.getString(2)),
                        ctspr.selectByIDorMa(r.getString(3)), r.getString(4),
                        r.getInt(5), r.getBigDecimal(6), r.getBigDecimal(7)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<HoaDonCT> selectAll() {
        return selectBySQL("Select*from HoadonCt");
    }

    public List<HoaDonCT> selectByHDandSP(String hd, String sp) {
        return selectBySQL("Select*from HoadonCt where idhd = ? and idctsp = ?", hd, sp);
    }

    public List<HoaDonCT> selectAllGH(String idgh) {
        return selectBySQL("Select*from HoadonCt where idhd = ?", idgh);
    }

    @Override
    public List<HoaDonCT> selectByWhere(String where) {
        return selectBySQL("Select*from HoaDonCT where MaHDCT  like ?", "%" + where + "%");
    }

    @Override
    public HoaDonCT selectByIDorMa(String x) {
        return selectBySQL("Select*From hoadonCT where MaHDCT = ?", x).get(0);
    }

    @Override
    public int update(HoaDonCT t) {
        return DBConnect.executeUpdate("Update HoaDonCT set soLuong=?"
                + " where idhd = ? and idctsp = ?", t.getSoLuong(), t.getHoaDon().getId(), t.getChiTietSanPham().getId());
    }

    @Override
    public int insert(HoaDonCT t) {
        return DBConnect.executeUpdate("Insert into HoaDonCT values(newid(),?,?,?,?,?,?)", t.getHoaDon().getId(),
                t.getChiTietSanPham().getId(), t.getMaHDCT(), t.getSoLuong(), t.getDonGia(), t.getDonGiaSauKhiGiam());
    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete HoaDonCT where idhd = ?", t);
    }

    public int delete(String a, String b) {
        return DBConnect.executeUpdate("Delete from HoaDonCT Where idhd = ? and idctsp = ?", a, b);
    }

    public int update(String a, String b, int c) {
        return DBConnect.executeUpdate("update hoadonct set soluong = ? where idhd = ? and idctsp = ?", c, a, b);
    }

    //duy
    public List<HoaDonCT> SelectThongKeSp(String sql, Object... args) {
        List<HoaDonCT> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql, args);
            while (r.next()) {
                list.add(new HoaDonCT(ctspr.selectByIDorMa(r.getString(1)), r.getInt(2)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<HoaDonCT> selectAllThongKeSp() {
        return SelectThongKeSp("select idctsp , SOLUONG From hoadonct");
    }

    public List<HoaDonCT> ThongKeSp() {
        List<HoaDonCT> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery("""
                                                 select  MACTSP , sum(SOLUONG) From hoadonct
                                                 join CHITIETSANPHAM on CHITIETSANPHAM.ID =  HOADONCT.IDCTSP
                                                 group by IDCTSP  , MACTSP
                                                 having COUNT(mactsp) >=1
                                                 order by MACTSP asc 
                                                 """);
            while (r.next()) {
                list.add(new HoaDonCT(ctspr.selectByMa(r.getString(1)), r.getInt(2)));
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Set<HoaDonCT> sll() {
        Set<HoaDonCT> list = new HashSet<>();
        try {
            ResultSet r = DBConnect.executeQuery("select  idctsp , SOLUONG From hoadonct");
            while (r.next()) {
                list.add(new HoaDonCT(ctspr.selectByIDorMa(r.getString(1)), r.getInt(2)));
            }
        } catch (Exception e) {
        }
        return list;
    }
    // than 
}
