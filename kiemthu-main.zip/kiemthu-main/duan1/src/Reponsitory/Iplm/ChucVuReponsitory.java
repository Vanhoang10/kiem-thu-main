/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory.Iplm;

import DomainModels.ChucVu;
import Reponsitory.IObjectReponsitory;
import Utility.DBConnect;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class ChucVuReponsitory implements IObjectReponsitory<ChucVu> {

    @Override
    public List<ChucVu> selectBySQL(String sql, Object... args) {
        List<ChucVu> list = new ArrayList<>();
        try {
            ResultSet r = DBConnect.executeQuery(sql, args);
            while (r.next()) {
                list.add(new ChucVu(r.getString(1), r.getString(2), r.getString(3), r.getDate(4), r.getDate(5), r.getInt(6)));
            }

        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public List<ChucVu> selectAll() {
        return selectBySQL("select*From CHUCVU ");
    }   
    @Override
    public List<ChucVu> selectByWhere(String where) {
        return selectBySQL("select *from CHUCVU where MACV like", "%" + where + "%");
    }

    @Override
    public ChucVu selectByIDorMa(String x) {
        return selectBySQL(" select *from CHUCVU where id = ?", x).get(0);
    }

    @Override
    public int update(ChucVu t) {
        return DBConnect.executeUpdate("Update ChucVu set TenCV=?  , NgaySua= getDate() where MaCV=?  ",
                t.getTen(), t.getMa());
    }

    @Override
    public int insert(ChucVu t) {
        return DBConnect.executeUpdate("insert into ChucVu(id,MACV,TENCV,NGAYTAO) values"
                + "(newid(),?,?,getDate())",  t.getMa(), t.getTen());

    }

    @Override
    public int delete(String t) {
        return DBConnect.executeUpdate("Delete ChucVu where MaCV=? ", t);
    }

}
