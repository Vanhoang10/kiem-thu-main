/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DomainModels;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author duy09
 */
public class HoaDon {

    private String id;
    private KhachHang khachHang;
    private NhanVien nhanVien;
    private String ma;
    private Date ngayTao, ngayThanhToan, ngayGiao, ngayNhan;
    private int trangThai;
    private String tenNguoiNhan, sdt, diaChi;
    private HinhThucThanhToan thanhToan;
    private BigDecimal tongTien;

    public HoaDon(String string, Date parse, Date parse1, BigDecimal bigDecimal) {
    }

    public HoaDon(String id, String ma, Date ngayTao, BigDecimal tongTien) {
        this.id = id;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.tongTien = tongTien;
    }

    public HoaDon(String ma) {
        this.ma = ma;
    }

    public HoaDon(String id, NhanVien nhanVien, String ma, Date ngayThanhToan, int trangThai, String tenNguoiNhan, String sdt, String diaChi, BigDecimal tongTien) {
        this.id = id;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayThanhToan = ngayThanhToan;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.tongTien = tongTien;
    }

    public HoaDon(KhachHang khachHang, String ma, String tenNguoiNhan, String sdt, HinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public HoaDon(NhanVien nhanVien, String ma, int trangThai) {
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.trangThai = trangThai;
    }

    public HoaDon(KhachHang khachHang, String ma, String tenNguoiNhan, String sdt, String diaChi, HinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public HoaDon(KhachHang khachHang, String ma, Date ngayThanhToan, HinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.ngayThanhToan = ngayThanhToan;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public HoaDon(KhachHang khachHang, String ma, HinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public HoaDon(String id, KhachHang khachHang, NhanVien nhanVien, String ma, Date ngayTao, Date ngayThanhToan, Date ngayGiao, Date ngayNhan, int trangThai, String tenNguoiNhan, String sdt, String diaChi, HinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.id = id;
        this.khachHang = khachHang;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.ngayThanhToan = ngayThanhToan;
        this.ngayGiao = ngayGiao;
        this.ngayNhan = ngayNhan;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public HoaDon(String ma, BigDecimal tongTien) {
        this.ma = ma;
        this.tongTien = tongTien;
    }

    public HoaDon(KhachHang khachHang, NhanVien nhanVien, String ma, int trangThai, HinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.trangThai = trangThai;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public HoaDon(String id, NhanVien nhanVien, String ma, Date ngayTao, int trangThai) {
        this.id = id;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.trangThai = trangThai;
    }

    public HoaDon(String id, KhachHang khachHang, NhanVien nhanVien, String ma, Date ngayTao, BigDecimal tongTien) {
        this.id = id;
        this.khachHang = khachHang;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.tongTien = tongTien;
    }

    public HoaDon(String id, KhachHang khachHang, NhanVien nhanVien, Date ngayTao, int trangThai, BigDecimal tongTien) {
        this.id = id;
        this.khachHang = khachHang;
        this.nhanVien = nhanVien;
        this.ngayTao = ngayTao;
        this.trangThai = trangThai;
        this.tongTien = tongTien;
    }

    public HoaDon(NhanVien nhanVien, String ma, int trangThai, String tenNguoiNhan) {
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
    }

    public HoaDon(NhanVien nhanVien, String ma, Date ngayTao, int trangThai) {
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.trangThai = trangThai;
    }

    public HoaDon(String id, KhachHang khachHang, NhanVien nhanVien, String ma,
            Date ngayTao, Date ngayThanhToan, Date ngayGiao, Date ngayNhan,
            int trangThai, String tenNguoiNhan, String sdt, String diaChi, HinhThucThanhToan thanhToan) {
        this.id = id;
        this.khachHang = khachHang;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.ngayThanhToan = ngayThanhToan;
        this.ngayGiao = ngayGiao;
        this.ngayNhan = ngayNhan;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.thanhToan = thanhToan;
    }

    public String getId() {
        return id;
    }

    public BigDecimal getTongTien() {
        return tongTien;
    }

    public void setTongTien(BigDecimal tongTien) {
        this.tongTien = tongTien;
    }

    public void setId(String id) {
        this.id = id;
    }

    public KhachHang getKhachHang() {
        return khachHang;
    }

    public void setKhachHang(KhachHang khachHang) {
        this.khachHang = khachHang;
    }

    public NhanVien getNhanVien() {
        return nhanVien;
    }

    public void setNhanVien(NhanVien nhanVien) {
        this.nhanVien = nhanVien;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgayThanhToan() {
        return ngayThanhToan;
    }

    public void setNgayThanhToan(Date ngayThanhToan) {
        this.ngayThanhToan = ngayThanhToan;
    }

    public Date getNgayGiao() {
        return ngayGiao;
    }

    public void setNgayGiao(Date ngayGiao) {
        this.ngayGiao = ngayGiao;
    }

    public Date getNgayNhan() {
        return ngayNhan;
    }

    public void setNgayNhan(Date ngayNhan) {
        this.ngayNhan = ngayNhan;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public String getTenNguoiNhan() {
        return tenNguoiNhan;
    }

    public void setTenNguoiNhan(String tenNguoiNhan) {
        this.tenNguoiNhan = tenNguoiNhan;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public HinhThucThanhToan getThanhToan() {
        return thanhToan;
    }

    public void setThanhToan(HinhThucThanhToan thanhToan) {
        this.thanhToan = thanhToan;
    }

    @Override
    public String toString() {
        return ma;
    }
    // Thống kê 

    public HoaDon(BigDecimal tongTien) {
        this.tongTien = tongTien;
    }

    public HoaDon(String id, Date ngayTao, BigDecimal tongTien) {
        this.id = id;
        this.ngayTao = ngayTao;
        this.tongTien = tongTien;
    }

    public HoaDon(Date ngayTao) {
        this.ngayTao = ngayTao;

    }

// thống kê hóa đơn
    public HoaDon(String id, NhanVien nhanVien, String ma, Date ngayTao, int trangThai, String tenNguoiNhan, String sdt, BigDecimal tongTien) {
        this.id = id;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.tongTien = tongTien;
    }

    public HoaDon(String ma, Date ngayTao, int trangThai, String tenNguoiNhan, String sdt, BigDecimal tongTien) {
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.tongTien = tongTien;
    }

    public HoaDon(int trangThai) {
        this.trangThai = trangThai;
    }
}
