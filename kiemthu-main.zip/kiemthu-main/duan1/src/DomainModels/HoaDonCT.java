/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DomainModels;

import java.math.BigDecimal;

/**
 *
 * @author duy09
 */
public class HoaDonCT {

    private String id;
    private HoaDon hoaDon;
    private ChiTietSanPham chiTietSanPham;
    private String MaHDCT;
    private int soLuong;
    private BigDecimal donGia, donGiaSauKhiGiam;

    public HoaDonCT() {
    }

    public HoaDonCT(String id, HoaDon hoaDon, ChiTietSanPham chiTietSanPham, String MaHDCT, int soLuong, BigDecimal donGia, BigDecimal donGiaSauKhiGiam) {
        this.id = id;
        this.hoaDon = hoaDon;
        this.chiTietSanPham = chiTietSanPham;
        this.MaHDCT = MaHDCT;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.donGiaSauKhiGiam = donGiaSauKhiGiam;
    }

    public HoaDonCT(String id, HoaDon hoaDon, ChiTietSanPham chiTietSanPham, int soLuong, BigDecimal donGia, BigDecimal donGiaSauKhiGiam) {
        this.id = id;
        this.hoaDon = hoaDon;
        this.chiTietSanPham = chiTietSanPham;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.donGiaSauKhiGiam = donGiaSauKhiGiam;
    }

    public String getMaHDCT() {
        return MaHDCT;
    }

    public void setMaHDCT(String MaHDCT) {
        this.MaHDCT = MaHDCT;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public HoaDon getHoaDon() {
        return hoaDon;
    }

    public void setHoaDon(HoaDon hoaDon) {
        this.hoaDon = hoaDon;
    }

    public ChiTietSanPham getChiTietSanPham() {
        return chiTietSanPham;
    }

    public void setChiTietSanPham(ChiTietSanPham chiTietSanPham) {
        this.chiTietSanPham = chiTietSanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public BigDecimal getDonGia() {
        return donGia;
    }

    public void setDonGia(BigDecimal donGia) {
        this.donGia = donGia;
    }

    public BigDecimal getDonGiaSauKhiGiam() {
        return donGiaSauKhiGiam;
    }

    public void setDonGiaSauKhiGiam(BigDecimal donGiaSauKhiGiam) {
        this.donGiaSauKhiGiam = donGiaSauKhiGiam;
    }

    @Override
    public String toString() {
        return id;
    }

    // thong ke

    public HoaDonCT(ChiTietSanPham chiTietSanPham, int soLuong) {
        this.chiTietSanPham = chiTietSanPham;
        this.soLuong = soLuong;
    }
    
}
