/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DomainModels;

import java.util.Date;

/**
 *
 * @author duy09
 */
public class KhachHang {

    private String id, ma, hoVaTen;
    private Date ngaySinh;
    private String sdt, diaChi;
    private Date ngayTao, ngaySua;
    private int trangThai;
    private LoaiKhachHang loaiKhachHang;

    public KhachHang() {
    }

    public KhachHang(String id, String ma, String hoVaTen, Date ngaySinh, String sdt, String diaChi, Date ngayTao, Date ngaySua, int trangThai) {
        this.id = id;
        this.ma = ma;   
        this.hoVaTen = hoVaTen;
        this.ngaySinh = ngaySinh;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.ngayTao = ngayTao;
        this.ngaySua = ngaySua;
        this.trangThai = trangThai;
    }

    public KhachHang(String id, String ma, String hoVaTen, Date ngaySinh, String sdt, String diaChi) {
        this.id = id;
        this.ma = ma;
        this.hoVaTen = hoVaTen;
        this.ngaySinh = ngaySinh;
        this.sdt = sdt;
        this.diaChi = diaChi;
    }

    public KhachHang(String ma, String hoVaTen, String sdt, String diaChi) {
        this.ma = ma;
        this.hoVaTen = hoVaTen;
        this.sdt = sdt;
        this.diaChi = diaChi;
    }


    public KhachHang(String ma, String hoVaTen, String sdt) {
        this.ma = ma;
        this.hoVaTen = hoVaTen;
        this.sdt = sdt;
    }

    public KhachHang(String id, String ma, String hoVaTen, Date ngaySinh, String sdt, String diaChi, Date ngayTao, Date ngaySua, int trangThai, LoaiKhachHang loaiKhachHang) {
        this.id = id;
        this.ma = ma;
        this.hoVaTen = hoVaTen;
        this.ngaySinh = ngaySinh;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.ngayTao = ngayTao;
        this.ngaySua = ngaySua;
        this.trangThai = trangThai;
        this.loaiKhachHang = loaiKhachHang;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getHoVaTen() {
        return hoVaTen;
    }

    public void setHoVaTen(String hoVaTen) {
        this.hoVaTen = hoVaTen;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgaySua() {
        return ngaySua;
    }

    public void setNgaySua(Date ngaySua) {
        this.ngaySua = ngaySua;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public LoaiKhachHang getLoaiKhachHang() {
        return loaiKhachHang;
    }

    public void setLoaiKhachHang(LoaiKhachHang loaiKhachHang) {
        this.loaiKhachHang = loaiKhachHang;
    }

    @Override
    public String toString() {
        return ma;
    }

}
