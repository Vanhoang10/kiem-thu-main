/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DomainModels;

import java.math.BigDecimal;

/**
 *
 * @author duy09
 */
public class ChiTietKhuyenMai {
    private String id,ma;
    private KhuyenMai khuyenMai;
    private ChiTietSanPham chiTietSanPham;
    private BigDecimal donGiaKhiGiam;
    private boolean trangThai;
    public ChiTietKhuyenMai() {
    }

    public ChiTietKhuyenMai(KhuyenMai khuyenMai, ChiTietSanPham chiTietSanPham) {
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
    }

    public ChiTietKhuyenMai(String id, String ma, KhuyenMai khuyenMai, ChiTietSanPham chiTietSanPham, BigDecimal donGiaKhiGiam, boolean trangThai) {
        this.id = id;
        this.ma = ma;
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.donGiaKhiGiam = donGiaKhiGiam;
        this.trangThai = trangThai;
    }

    public ChiTietKhuyenMai(String ma, KhuyenMai khuyenMai, ChiTietSanPham chiTietSanPham, BigDecimal donGiaKhiGiam) {
        this.ma = ma;
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.donGiaKhiGiam = donGiaKhiGiam;
    }

    public ChiTietKhuyenMai(String id, String ma, KhuyenMai khuyenMai, ChiTietSanPham chiTietSanPham, BigDecimal donGiaKhiGiam) {
        this.id = id;
        this.ma = ma;
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.donGiaKhiGiam = donGiaKhiGiam;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public KhuyenMai getKhuyenMai() {
        return khuyenMai;
    }

    public void setKhuyenMai(KhuyenMai khuyenMai) {
        this.khuyenMai = khuyenMai;
    }

    public ChiTietSanPham getChiTietSanPham() {
        return chiTietSanPham;
    }

    public void setChiTietSanPham(ChiTietSanPham chiTietSanPham) {
        this.chiTietSanPham = chiTietSanPham;
    }

    public BigDecimal getDonGiaKhiGiam() {
        return donGiaKhiGiam;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    public void setDonGiaKhiGiam(BigDecimal donGiaKhiGiam) {
        this.donGiaKhiGiam = donGiaKhiGiam;
    }
    
}
