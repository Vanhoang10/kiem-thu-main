/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DomainModels;

import java.math.BigDecimal;

/**
 *
 * @author duy09
 */
public class ChiTietSanPham {

    private String id, ma;
    private int soLuongTon;
    private BigDecimal giaNhap, giaBan;
    private String moTa;
    private int trangThai;
    private SanPham sanPham;
    private MauSac mauSac;
    private ChatLieu chatLieu;
    private DongSP dongSP;
    private NSX nsx;
    private KichCo kichCo;
    private  BigDecimal donGianKhiGiam;
    public ChiTietSanPham() {
    }

    public ChiTietSanPham(String ma, BigDecimal giaBan, BigDecimal donGianKhiGiam) {
        this.ma = ma;
        this.giaBan = giaBan;
        this.donGianKhiGiam = donGianKhiGiam;
    }

    public ChiTietSanPham(String id, String ma, int soLuongTon) {
        this.id = id;
        this.ma = ma;
        this.soLuongTon = soLuongTon;
    }

   
    public ChiTietSanPham(String id, String ma, BigDecimal giaBan, SanPham sanPham, MauSac mauSac, ChatLieu chatLieu, DongSP dongSP, NSX nsx, KichCo kichCo) {
        this.id = id;
        this.ma = ma;
        this.giaBan = giaBan;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
    }

    public ChiTietSanPham(String ma, int soLuongTon, BigDecimal giaNhap, BigDecimal giaBan, String moTa, int trangThai, SanPham sanPham, MauSac mauSac, ChatLieu chatLieu, DongSP dongSP, NSX nsx, KichCo kichCo, BigDecimal donGianKhiGiam) {
        this.ma = ma;
        this.soLuongTon = soLuongTon;
        this.giaNhap = giaNhap;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
        this.donGianKhiGiam = donGianKhiGiam;
    }

    public ChiTietSanPham(String id, String ma, int soLuongTon, BigDecimal giaNhap, BigDecimal giaBan, String moTa, int trangThai, SanPham sanPham, MauSac mauSac, ChatLieu chatLieu, DongSP dongSP, NSX nsx, KichCo kichCo, BigDecimal donGianKhiGiam) {
        this.id = id;
        this.ma = ma;
        this.soLuongTon = soLuongTon;
        this.giaNhap = giaNhap;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
        this.donGianKhiGiam = donGianKhiGiam;
    }

    public ChiTietSanPham(String ma, int soLuongTon, BigDecimal giaNhap, BigDecimal giaBan, String moTa, int trangThai, SanPham sanPham, MauSac mauSac, ChatLieu chatLieu, DongSP dongSP, NSX nsx, KichCo kichCo) {
        this.ma = ma;
        this.soLuongTon = soLuongTon;
        this.giaNhap = giaNhap;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
    }

    public ChiTietSanPham(String id, String ma, int soLuongTon, BigDecimal giaNhap, BigDecimal giaBan, String moTa, int trangThai, SanPham sanPham, MauSac mauSac, ChatLieu chatLieu, DongSP dongSP, NSX nsx, KichCo kichCo) {
        this.id = id;
        this.ma = ma;
        this.soLuongTon = soLuongTon;
        this.giaNhap = giaNhap;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public int getSoLuongTon() {
        return soLuongTon;
    }

    public void setSoLuongTon(int soLuongTon) {
        this.soLuongTon = soLuongTon;
    }

    public BigDecimal getGiaNhap() {
        return giaNhap;
    }

    public void setGiaNhap(BigDecimal giaNhap) {
        this.giaNhap = giaNhap;
    }

    public BigDecimal getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(BigDecimal giaBan) {
        this.giaBan = giaBan;
    }

    public BigDecimal getDonGianKhiGiam() {
        return donGianKhiGiam;
    }

    public void setDonGianKhiGiam(BigDecimal donGianKhiGiam) {
        this.donGianKhiGiam = donGianKhiGiam;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public SanPham getSanPham() {
        return sanPham;
    }

    public void setSanPham(SanPham sanPham) {
        this.sanPham = sanPham;
    }

    public MauSac getMauSac() {
        return mauSac;
    }

    public void setMauSac(MauSac mauSac) {
        this.mauSac = mauSac;
    }

    public ChatLieu getChatLieu() {
        return chatLieu;
    }

    public void setChatLieu(ChatLieu chatLieu) {
        this.chatLieu = chatLieu;
    }

    public DongSP getDongSP() {
        return dongSP;
    }

    public void setDongSP(DongSP dongSP) {
        this.dongSP = dongSP;
    }

    public NSX getNsx() {
        return nsx;
    }

    public void setNsx(NSX nsx) {
        this.nsx = nsx;
    }

    public KichCo getKichCo() {
        return kichCo;
    }

    public void setKichCo(KichCo kichCo) {
        this.kichCo = kichCo;
    }


    @Override
    public String toString() {
        return ma;
    }

// Thoosng kee

    public ChiTietSanPham(String ma) {
        this.ma = ma;
    }
    

}
