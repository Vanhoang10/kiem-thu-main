/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.ChiTietSanPham;
import Reponsitory.Iplm.ChatLieuReponsitory;
import Reponsitory.Iplm.ChiTietSanPhamReponsitory;
import Reponsitory.Iplm.DongSPReponsitory;
import Reponsitory.Iplm.KichCoReponsitory;
import Reponsitory.Iplm.MauSacReponsitory;
import Reponsitory.Iplm.NSXReponsitory;
import Reponsitory.Iplm.SanPhamReponsitory;
import Services.IObjectService;
import ViewModel.QLChiTietSanPham;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class ChiTietSanPhamService implements IObjectService<QLChiTietSanPham> {

    private final ChiTietSanPhamReponsitory ctr;
    private final SanPhamService sps;
    private final MauSacService mss;
    private final ChatLieuService cls;
    private final NSXService nsxs;
    private final KichCoService kcs;
    private final DongSPService dsps;
    private final SanPhamReponsitory spr;
    private final MauSacReponsitory msr;
    private final ChatLieuReponsitory clr;
    private final NSXReponsitory nsxr;
    private final KichCoReponsitory kcr;
    private final DongSPReponsitory dspr;

    public ChiTietSanPhamService() {
        this.ctr = new ChiTietSanPhamReponsitory();
        this.sps = new SanPhamService();
        this.mss = new MauSacService();
        this.cls = new ChatLieuService();
        this.nsxs = new NSXService();
        this.kcs = new KichCoService();
        this.dsps = new DongSPService();
        this.spr = new SanPhamReponsitory();
        this.msr = new MauSacReponsitory();
        this.clr = new ChatLieuReponsitory();
        this.nsxr = new NSXReponsitory();
        this.kcr = new KichCoReponsitory();
        this.dspr = new DongSPReponsitory();
    }

    @Override
    public List<QLChiTietSanPham> selectAll() {
        return select(ctr.selectAll());
    }

    public List<QLChiTietSanPham> selectKM(String where) {
        List<QLChiTietSanPham> list = new ArrayList<>();
        for (ChiTietSanPham x : ctr.selectKM(where)) {
            list.add(new QLChiTietSanPham(x.getId(), x.getMa(), x.getGiaBan(),
                    sps.selectByIDorMa(x.getSanPham().getId()),
                    mss.selectByIDorMa(x.getMauSac().getId()),
                    cls.selectByIDorMa(x.getChatLieu().getId()),
                    dsps.selectByIDorMa(x.getDongSP().getId()),
                    nsxs.selectByIDorMa(x.getNsx().getId()),
                    kcs.selectByIDorMa(x.getKichCo().getId())));
        }
        return list;
    }

    @Override
    public List<QLChiTietSanPham> selectByWhere(String where) {
        return select(ctr.selectByWhere(where));
    }

    public List<QLChiTietSanPham> selectWithKM(String where) {
        List<QLChiTietSanPham> list = new ArrayList<>();
        for (ChiTietSanPham x : ctr.selectWithKM(where)) {
            list.add(new QLChiTietSanPham(x.getId(), x.getMa(), x.getGiaBan(),
                    sps.selectByIDorMa(x.getSanPham().getId()),
                    mss.selectByIDorMa(x.getMauSac().getId()),
                    cls.selectByIDorMa(x.getChatLieu().getId()),
                    dsps.selectByIDorMa(x.getDongSP().getId()),
                    nsxs.selectByIDorMa(x.getNsx().getId()),
                    kcs.selectByIDorMa(x.getKichCo().getId())));
        }
        return list;
    }

    @Override
    public QLChiTietSanPham selectByIDorMa(String a) {
        ChiTietSanPham x = ctr.selectByIDorMa(a);
        return new QLChiTietSanPham(
                x.getId(),
                x.getMa(),
                x.getSoLuongTon(),
                x.getGiaNhap(),
                x.getGiaBan(),
                x.getMoTa(),
                x.getTrangThai(),
                sps.selectByIDorMa(x.getSanPham().getId()),
                mss.selectByIDorMa(x.getMauSac().getId()),
                cls.selectByIDorMa(x.getChatLieu().getId()),
                dsps.selectByIDorMa(x.getDongSP().getId()),
                nsxs.selectByIDorMa(x.getNsx().getId()),
                kcs.selectByIDorMa(x.getKichCo().getId()), x.getDonGianKhiGiam());
    }

    public QLChiTietSanPham selectByMa(String a) {
        ChiTietSanPham x = ctr.selectByMa(a);
        return new QLChiTietSanPham(
                x.getId(),
                x.getMa(),
                x.getSoLuongTon(),
                x.getGiaNhap(),
                x.getGiaBan(),
                x.getMoTa(),
                x.getTrangThai(),
                sps.selectByIDorMa(x.getSanPham().getId()),
                mss.selectByIDorMa(x.getMauSac().getId()),
                cls.selectByIDorMa(x.getChatLieu().getId()),
                dsps.selectByIDorMa(x.getDongSP().getId()),
                nsxs.selectByIDorMa(x.getNsx().getId()),
                kcs.selectByIDorMa(x.getKichCo().getId()), x.getDonGianKhiGiam());
    }
    public QLChiTietSanPham selectByMaa(String a) {
        ChiTietSanPham x = ctr.selectByMaa(a);
        return new QLChiTietSanPham(
                x.getId(),
                x.getMa(),
                x.getSoLuongTon(),
                x.getGiaNhap(),
                x.getGiaBan(),
                x.getMoTa(),
                x.getTrangThai(),
                sps.selectByIDorMa(x.getSanPham().getId()),
                mss.selectByIDorMa(x.getMauSac().getId()),
                cls.selectByIDorMa(x.getChatLieu().getId()),
                dsps.selectByIDorMa(x.getDongSP().getId()),
                nsxs.selectByIDorMa(x.getNsx().getId()),
                kcs.selectByIDorMa(x.getKichCo().getId()), x.getDonGianKhiGiam());
    }

    @Override
    public int update(QLChiTietSanPham x) {
        return ctr.update(new ChiTietSanPham(
                x.getId(),
                x.getMa(),
                x.getSoLuongTon(),
                x.getGiaNhap(),
                x.getGiaBan(),
                x.getMoTa(),
                x.getTrangThai(),
                spr.selectByIDorMa(x.getSanPham().getId()),
                msr.selectByIDorMa(x.getMauSac().getId()),
                clr.selectByIDorMa(x.getChatLieu().getId()),
                dspr.selectByIDorMa(x.getDongSP().getId()),
                nsxr.selectByIDorMa(x.getNsx().getId()),
                kcr.selectByIDorMa(x.getKichCo().getId()), x.getGiaKhiKM()));
    }

    public int updateKM(QLChiTietSanPham t) {
        return ctr.updateKM(new ChiTietSanPham(t.getMa(), t.getGiaBan(), t.getGiaKhiKM()));
    }

    @Override
    public int insert(QLChiTietSanPham x) {
        return ctr.insert(new ChiTietSanPham(
                x.getMa(),
                x.getSoLuongTon(),
                x.getGiaNhap(),
                x.getGiaBan(),
                x.getMoTa(),
                x.getTrangThai(),
                spr.selectByIDorMa(x.getSanPham().getId()),
                msr.selectByIDorMa(x.getMauSac().getId()),
                clr.selectByIDorMa(x.getChatLieu().getId()),
                dspr.selectByIDorMa(x.getDongSP().getId()),
                nsxr.selectByIDorMa(x.getNsx().getId()),
                kcr.selectByIDorMa(x.getKichCo().getId()),
                x.getGiaKhiKM()));
    }

    @Override
    public int delete(String t) {
        return ctr.delete(t);
    }

    public List<QLChiTietSanPham> select(List<ChiTietSanPham> lists) {
        List<QLChiTietSanPham> list = new ArrayList<>();
        for (ChiTietSanPham x : lists) {
            list.add(new QLChiTietSanPham(
                    x.getMa(),
                    x.getSoLuongTon(),
                    x.getGiaNhap(),
                    x.getGiaBan(),
                    x.getMoTa(),
                    x.getTrangThai(),
                    sps.selectByIDorMa(x.getSanPham().getId()),
                    mss.selectByIDorMa(x.getMauSac().getId()),
                    cls.selectByIDorMa(x.getChatLieu().getId()),
                    dsps.selectByIDorMa(x.getDongSP().getId()),
                    nsxs.selectByIDorMa(x.getNsx().getId()),
                    kcs.selectByIDorMa(x.getKichCo().getId()),
                    x.getDonGianKhiGiam()));
        }
        return list;
    }

    public List<QLChiTietSanPham> selectAllAn() {
        return select(ctr.selectAllAn());
    }

    public int setAn(int x, String item) {
        return ctr.setAn(x, item);
    }

    public List<QLChiTietSanPham> loc(String where) {
        return select(ctr.loc(where));
    }

    public int updateBanHang(QLChiTietSanPham x) {
        return ctr.updateBanHang(new ChiTietSanPham(x.getId(), x.getMa(), x.getSoLuongTon()));
    }
// Thống kê 

    public List<QLChiTietSanPham> SapHetHang() {
        return select(ctr.sapHetHang());
    }

    public List<QLChiTietSanPham> HetHang() {
        return select(ctr.HetHang());
    }

    public List<QLChiTietSanPham> SanPhamTable() {
        return select(ctr.SanPhamTable());
    }

    public String getIdByMa(String ma) {
        return ctr.getIdByMa(ma);
    }

    public int updateBanHang(int a, String b) {
        return ctr.updateBanHang(a, b);
    }

    public int getSL(String ma) {
        return ctr.getSL(ma);
    }
}
