/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.HoaDonCT;
import Reponsitory.Iplm.ChiTietSanPhamReponsitory;
import Reponsitory.Iplm.HoaDonCTReponsitory;
import Reponsitory.Iplm.HoaDonReponsitory;
import Services.IObjectService;
import ViewModel.QLHoaDonCT;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author duy09
 */
public class HoaDonCTService implements IObjectService<QLHoaDonCT> {

    private final HoaDonCTReponsitory hdctr;
    private final HoaDonReponsitory hdr = new HoaDonReponsitory();
    private final HoaDonService hds = new HoaDonService();
    private final ChiTietSanPhamService cts = new ChiTietSanPhamService();
    private final ChiTietSanPhamReponsitory ctr = new ChiTietSanPhamReponsitory();

    public HoaDonCTService() {
        this.hdctr = new HoaDonCTReponsitory();
    }

    public List<QLHoaDonCT> select(List<HoaDonCT> listx) {
        List<QLHoaDonCT> list = new ArrayList<>();
        for (HoaDonCT x : listx) {
            list.add(new QLHoaDonCT(x.getId(), hds.selectByID(x.getHoaDon().getId()), cts.selectByIDorMa(x.getChiTietSanPham().getId()), x.getMaHDCT(), x.getSoLuong(), x.getDonGia(), x.getDonGiaSauKhiGiam()));
        }
        return list;
    }

    @Override
    public List<QLHoaDonCT> selectAll() {
        return select(hdctr.selectAll());
    }

    public List<QLHoaDonCT> selectAllGH(String idgh) {
        return select(hdctr.selectAllGH(idgh));
    }

    public List<QLHoaDonCT> selectByHDandSP(String hd, String sp) {
        return select(hdctr.selectByHDandSP(hd, sp));
    }

    @Override
    public List<QLHoaDonCT> selectByWhere(String where) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public QLHoaDonCT selectByIDorMa(String x) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int update(QLHoaDonCT t) {
        return hdctr.update(new HoaDonCT(t.getId(), hdr.selectByID(t.getHoaDon().getId()), ctr.selectByIDorMa(t.getChiTietSanPham().getId()),
                t.getSoLuong(), t.getDonGia(), t.getDonGiaSauKhiGiam()));
    }

    @Override
    public int insert(QLHoaDonCT t) {
        return hdctr.insert(new HoaDonCT(t.getId(), hdr.selectByID(t.getHoaDon().getId()), ctr.selectByIDorMa(t.getChiTietSanPham().getId()),
                t.getSoLuong(), t.getDonGia(), t.getDonGiaSauKhiGiam()));
    }

    @Override
    public int delete(String t) {
        return hdctr.delete(t);
    }

    public int delete(String a, String b) {
        return hdctr.delete(a, b);
    }

    public List<QLHoaDonCT> selectAllThongKeSp() {
        List<QLHoaDonCT> list = new ArrayList<>();
        for (HoaDonCT q : hdctr.selectAllThongKeSp()) {
            list.add(new QLHoaDonCT(cts.selectByIDorMa(q.getChiTietSanPham().getId()), q.getSoLuong()));
        }
        return list;
    }
    public List<QLHoaDonCT> ThongKeSp() {
         List<QLHoaDonCT> list = new ArrayList<>();
        for (HoaDonCT q : hdctr.ThongKeSp()) {
            list.add(new QLHoaDonCT(cts.selectByMa(q.getChiTietSanPham().getMa()), q.getSoLuong()));
        }
        return list;
    }

    public Set<QLHoaDonCT> sll() {
        Set<QLHoaDonCT> list = new HashSet<>();
        for (HoaDonCT q : hdctr.selectAllThongKeSp()) {
            list.add(new QLHoaDonCT(cts.selectByIDorMa(q.getChiTietSanPham().getId()), q.getSoLuong()));
        }
        return list;
    }

    public int update(String a, String b, int c) {
        return hdctr.update(a, b, c);

    }
}
