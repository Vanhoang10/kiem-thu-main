/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.SanPham;
import Reponsitory.Iplm.SanPhamReponsitory;
import Services.IObjectService;
import ViewModel.QLSanPham;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class SanPhamService implements IObjectService<QLSanPham> {

    private final SanPhamReponsitory spr;

    public SanPhamService() {
        this.spr = new SanPhamReponsitory();
    }

    @Override
    public List<QLSanPham> selectAll() {
        List<QLSanPham> list = new ArrayList<>();
        for (SanPham x : spr.selectAll()) {
            list.add(new QLSanPham(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLSanPham> selectByWhere(String where) {
        List<QLSanPham> list = new ArrayList<>();
        for (SanPham x : spr.selectByWhere(where)) {
            list.add(new QLSanPham(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public QLSanPham selectByIDorMa(String x) {
        SanPham cl = spr.selectByIDorMa(x);
        return new QLSanPham(cl.getId(), cl.getMa(), cl.getTen(), cl.getNgayTao(), cl.getNgaySua(), cl.getTrangThai());
    }

    public QLSanPham selectByMa(String x) {
        SanPham cl = spr.selectByMa(x);
        return new QLSanPham(cl.getId(), cl.getMa(), cl.getTen(), cl.getNgayTao(), cl.getNgaySua(), cl.getTrangThai());
    }

    @Override
    public int update(QLSanPham t) {
        return spr.update(new SanPham(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLSanPham t) {
        return spr.insert(new SanPham(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return spr.delete(t);
    }

    public int update(QLSanPham t, String x) {
        return spr.update(new SanPham(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()), x);
    }
}
