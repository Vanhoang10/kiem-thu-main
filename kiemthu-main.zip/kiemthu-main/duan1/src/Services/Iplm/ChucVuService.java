/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.ChucVu;
import Reponsitory.Iplm.ChucVuReponsitory;
import Services.IObjectService;
import ViewModel.QLChucVu;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class ChucVuService implements IObjectService<QLChucVu> {

    public final ChucVuReponsitory cvr;
    List<QLChucVu> listCv;

    public ChucVuService() {
        this.cvr = new ChucVuReponsitory();

    }

    @Override
    public List<QLChucVu> selectAll() {
        listCv = new ArrayList<>();
        List<ChucVu> cv = cvr.selectAll();
        for (ChucVu c : cv) {
            listCv.add(new QLChucVu(c.getId(), c.getMa(), c.getTen(),
                    c.getNgayTao(), c.getNgaySua(), c.getTrangThai()));
        }
        return listCv;
    }

    @Override
    public List<QLChucVu> selectByWhere(String where) {
        List<ChucVu> cv = cvr.selectByWhere(where);
        for (ChucVu c : cv) {
            listCv.add(new QLChucVu(c.getId(), c.getMa(), c.getTen(),
                    c.getNgayTao(), c.getNgaySua(), c.getTrangThai()));
        }
        return listCv;
    }

    @Override
    public QLChucVu selectByIDorMa(String x) {
        ChucVu c = cvr.selectByIDorMa(x);
        return new QLChucVu(c.getId(), c.getMa(), c.getTen(),
                c.getNgayTao(), c.getNgaySua(), c.getTrangThai());
    }

    @Override
    public int update(QLChucVu t) {
        return cvr.update(new ChucVu(t.getId(), t.getMa(),
                t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLChucVu t) {
        return cvr.insert(new ChucVu(t.getId(), t.getMa(),
                t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return cvr.delete(t);
    }

}
