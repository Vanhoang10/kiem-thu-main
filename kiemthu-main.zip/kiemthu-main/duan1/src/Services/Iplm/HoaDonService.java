/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.HoaDon;
import Reponsitory.Iplm.HinhThucThanhToanReponsitory;
import Reponsitory.Iplm.HoaDonReponsitory;
import Reponsitory.Iplm.KhachHangReponsitory;
import Reponsitory.Iplm.NhanVienReponsitory;
import Services.IObjectService;
import Utility.DBConnect;
import ViewModel.QLHoaDon;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 *
 * @author duy09
 */
public class HoaDonService implements IObjectService<QLHoaDon> {

    private final HoaDonReponsitory hdr;
    private HinhThucThanhToanService hts = new HinhThucThanhToanService();
    private KhachHangService khs = new KhachHangService();
    private NhanVienService nvs = new NhanVienService();
    private HinhThucThanhToanReponsitory htttr = new HinhThucThanhToanReponsitory();
    private HinhThucThanhToanService httts = new HinhThucThanhToanService();
    private HinhThucThanhToanReponsitory htr = new HinhThucThanhToanReponsitory();
    private NhanVienReponsitory nvr = new NhanVienReponsitory();
    private KhachHangReponsitory khr = new KhachHangReponsitory();

    public HoaDonService() {
        this.hdr = new HoaDonReponsitory();
    }

    public List<QLHoaDon> select(List<HoaDon> listx) {
        List<QLHoaDon> list = new ArrayList<>();
        for (HoaDon x : listx) {
            list.add(new QLHoaDon(x.getId(), khs.selectByIDorMa(x.getKhachHang().getId()),
                    nvs.selectByIDorMa(
                            x.getNhanVien().getId()),
                    x.getMa(),
                    x.getNgayTao(),
                    x.getNgayThanhToan(),
                    x.getNgayGiao(),
                    x.getNgayNhan(),
                    x.getTrangThai(),
                    x.getTenNguoiNhan(),
                    x.getSdt(),
                    x.getDiaChi(),
                    hts.selectByIDorMa(x.getThanhToan().getId())));
        }
        return list;
    }

    @Override
    public List<QLHoaDon> selectAll() {
        List<QLHoaDon> list = new ArrayList<>();
        for (HoaDon x : hdr.selectAll()) {
            list.add(new QLHoaDon(
                    nvs.selectByIDorMa(x.getNhanVien().getMa()),
                    x.getMa(),
                    x.getNgayTao(),
                    x.getTrangThai()
            ));
        }
        return list;
    }

    public QLHoaDon selectCT(String a) {
        HoaDon hd = hdr.selectCT(a);
        return new QLHoaDon(hd.getId(), nvs.selectByID(hd.getNhanVien().getId()), hd.getMa(), hd.getNgayTao(), hd.getTrangThai());
    }

    @Override
    public List<QLHoaDon> selectByWhere(String where) {
        return select(hdr.selectByWhere(where));
    }

    @Override
    public QLHoaDon selectByIDorMa(String a) {
        HoaDon x = hdr.selectByIDorMa(a);

        return new QLHoaDon(x.getId(), khs.selectByIDorMa(x.getKhachHang().getId()),
                nvs.selectByID(
                        x.getNhanVien().getId()),
                x.getMa(),
                x.getNgayTao(),
                x.getNgayThanhToan(),
                x.getNgayGiao(),
                x.getNgayNhan(),
                x.getTrangThai(),
                x.getTenNguoiNhan(),
                x.getSdt(),
                x.getDiaChi(),
                hts.selectByIDorMa(x.getThanhToan().getId()),
                x.getTongTien());
    }

    @Override
    public int update(QLHoaDon x) {
        return hdr.update(new HoaDon(x.getId(), khr.selectByIDorMa(x.getKhachHang().getId()),
                nvr.selectByIDorMa(x.getNhanVien().getId()),
                x.getMa(),
                x.getNgayTao(),
                x.getNgayThanhToan(),
                x.getNgayGiao(),
                x.getNgayNhan(),
                x.getTrangThai(),
                x.getTenNguoiNhan(),
                x.getSdt(),
                x.getDiaChi(),
                htr.selectByIDorMa(x.getThanhToan().getId())));
    }

    @Override
    public int insert(QLHoaDon x) {
        return hdr.insert(new HoaDon(x.getId(), khr.selectByIDorMa(x.getKhachHang().getId()),
                nvr.selectByIDorMa(x.getNhanVien().getId()),
                x.getMa(),
                x.getNgayTao(),
                x.getNgayThanhToan(),
                x.getNgayGiao(),
                x.getNgayNhan(),
                x.getTrangThai(),
                x.getTenNguoiNhan(),
                x.getSdt(),
                x.getDiaChi(),
                htr.selectByIDorMa(x.getThanhToan().getId())));
    }

    @Override
    public int delete(String t) {
        return hdr.delete(t);
    }

    public int insertNew(QLHoaDon x) {
        return hdr.insertNew(new HoaDon(
                nvr.selectByIDorMa(x.getNhanVien().getMa()),
                x.getMa(),
                x.getTrangThai()));
    }

    public int updateHuy(String ma) {
        return hdr.updateHuy(ma);
    }

    public int updateHoanThanh(QLHoaDon x) {
        return hdr.updateHoanThanh(new HoaDon(x.getId(), khr.selectByIDorMa(x.getKhachHang().getId()),
                nvr.selectByIDorMa(x.getNhanVien().getId()),
                x.getMa(),
                x.getNgayTao(),
                x.getNgayThanhToan(),
                x.getNgayGiao(),
                x.getNgayNhan(),
                x.getTrangThai(),
                x.getTenNguoiNhan(),
                x.getSdt(),
                x.getDiaChi(),
                htr.selectByIDorMa(x.getThanhToan().getId())));
    }

    public int updateThanhToan(QLHoaDon ma) {
        return hdr.updateThanhToan(new HoaDon(khr.selectByIDorMa(ma.getKhachHang().getId()),
                ma.getMa(), htttr.selectByIDorMa(ma.getThanhToan().getId()), ma.getTongTien()));
    }

    public List<QLHoaDon> selectByKH(String id) {
        List<QLHoaDon> list = new ArrayList<>();
        for (HoaDon x : hdr.selectByKH(id)) {
            list.add(new QLHoaDon(x.getId(), x.getMa(), x.getNgayTao(), x.getTongTien()));
        }
        return list;
    }

    public BigDecimal selectTongTien(String id) {
        return hdr.selectTongTien(id);
    }

    // Thống kê doanh thu
    public List<QLHoaDon> selectThongKe(List<HoaDon> listx) {
        List<QLHoaDon> list = new ArrayList<>();
        for (HoaDon x : listx) {
            list.add(new QLHoaDon(x.getTongTien()));
        }
        return list;
    }

    public List<QLHoaDon> DoanhThuTheoNgay() {
        return selectThongKe(hdr.selectByDoanhThuNgay());
    }

    public List<QLHoaDon> DoanhThuTheoThang() {
        return selectThongKe(hdr.SelectDoanhThuThang());
    }

    public List<QLHoaDon> DoanhThuTheoNam() {
        return selectThongKe(hdr.selectDoanhThuNam());
    }

    public List<QLHoaDon> DoanhThuTheoAll() {
        return selectThongKe(hdr.selectDoanhThuAll());
    }

    public List<QLHoaDon> SelectThongKeDoanhThu(List<HoaDon> hd) {
        List<QLHoaDon> list = new ArrayList<>();
        for (HoaDon q : hd) {
            list.add(new QLHoaDon(q.getId(), q.getNgayTao(), q.getTongTien()));
        }
        return list;
    }

    public List<QLHoaDon> SelectThongKeDoanhThuTable() {
        return SelectThongKeDoanhThu(hdr.SelectThongKeDoanhThuTable());
    }

    public List<QLHoaDon> Loc1SelectThongKeDoanhThuTable() {
        return SelectThongKeDoanhThu(hdr.Loc1SelectThongKeDoanhThuTable());
    }

    public List<QLHoaDon> Loc2SelectThongKeDoanhThuTable() {
        return SelectThongKeDoanhThu(hdr.Loc2SelectThongKeDoanhThuTable());
    }

    public List<QLHoaDon> KhoangNgayThongKeDoanhThuTable(Date ngay1, Date ngay2) {
        return SelectThongKeDoanhThu(hdr.KhoangNgayThongKeDoanhThuTable(ngay1, ngay2));
    }

////////////////////////////////
    public String selectIDOne(String x) {
        return hdr.selectIDOne(x);
    }

    public int updateTToan(QLHoaDon x) {
        return hdr.updateTToan(new HoaDon(khr.selectByIDorMa(x.getKhachHang().getId()), x.getMa(), x.getTenNguoiNhan(), x.getSdt(), htttr.selectByIDorMa(x.getThanhToan().getId()), x.getTongTien()));
    }

    public int updateGHang(QLHoaDon x) {
        return hdr.updateGHang(new HoaDon(khr.selectByIDorMa(x.getKhachHang().getId()),
                x.getMa(), x.getTenNguoiNhan(), x.getSdt(), x.getDiaChi(),
                htttr.selectByIDorMa(x.getThanhToan().getId()), x.getTongTien()));
    }

    public QLHoaDon selectID(String a) {
        HoaDon x = hdr.selectID(a);
        return new QLHoaDon(khs.selectByIDorMa(x.getKhachHang().getId()), x.getMa(), x.getTenNguoiNhan(), x.getSdt(), x.getDiaChi(), hts.selectByIDorMa(x.getThanhToan().getId()),
                x.getTongTien());
    }

    public QLHoaDon selectByID(String x) {
        HoaDon hd = hdr.selectByID(x);
        return new QLHoaDon(hd.getId(), nvs.selectByID(hd.getNhanVien().getId()), hd.getMa(), hd.getNgayTao(), hd.getTrangThai());
    }

    public int updateNhanHang(String x) {
        return hdr.updateNhanHang(x);
    }

    // Thống kê hóa đơn 
    public List<QLHoaDon> HoaDon(List<HoaDon> list) {
        List<QLHoaDon> ql = new ArrayList<>();
        for (HoaDon q : list) {
            ql.add(new QLHoaDon(q.getTrangThai()));
        }
        return ql;
    }

    public List<QLHoaDon> HoaDonNhan() {
        return HoaDon(hdr.HoaDonDaNhan());
    }

    public List<QLHoaDon> HoaDonDangGiao() {
        return HoaDon(hdr.HoaDonDangGiao());
    }

    public List<QLHoaDon> HoaDonDangCho() {
        return HoaDon(hdr.HoaDonDangCho());
    }

    public List<QLHoaDon> HoaDonHuy() {
        return HoaDon(hdr.HoaDonHuy());
    }

    public List<QLHoaDon> HoaDonTong() {
        return HoaDon(hdr.HoaDonTong());
    }

    public List<QLHoaDon> HoaDonThongKe(List<HoaDon> list) {
        List<QLHoaDon> ql = new ArrayList<>();

        for (HoaDon h : list) {
            ql.add(new QLHoaDon(h.getMa(), h.getNgayTao(),
                    h.getTrangThai(), h.getTenNguoiNhan(), h.getSdt(), h.getTongTien()));

        }
        return ql;
    }

    public List<QLHoaDon> HoaDonTable() {
        return HoaDonThongKe(hdr.HoaDonThongKeTable());
    }

    public List<QLHoaDon> HoaDonTimKiem(String where) {
        return HoaDonThongKe(hdr.hoaDonTimKiem(where));
    }

    public List<QLHoaDon> selectLichSu() {
        List<QLHoaDon> list = new ArrayList<>();
        for (HoaDon x : hdr.selectLichSu()) {
            list.add(new QLHoaDon(
                    nvs.selectByIDorMa(x.getNhanVien().getMa()),
                    x.getMa(),
                    x.getTrangThai(),
                    x.getTenNguoiNhan()
            ));
        }
        return list;
    }

    public List<QLHoaDon> selectHDCho(int a) {
        List<QLHoaDon> list = new ArrayList<>();
        for (HoaDon x : hdr.selectHDCho(a)) {
            list.add(new QLHoaDon(
                    nvs.selectByIDorMa(x.getNhanVien().getMa()),
                    x.getMa(),
                    x.getTrangThai(),
                    x.getTenNguoiNhan()
            ));
        }
        return list;
    }

    public List<QLHoaDon> selectLichSuTK(String ma) {
        List<QLHoaDon> list = new ArrayList<>();
        for (HoaDon x : hdr.selectLichSuTK(ma)) {
            list.add(new QLHoaDon(
                    nvs.selectByIDorMa(x.getNhanVien().getMa()),
                    x.getMa(),
                    x.getTrangThai(),
                    x.getTenNguoiNhan()
            ));
        }
        return list;
    }

    public QLHoaDon selectByMaLS(String a) {
        HoaDon x = hdr.selectByMaLS(a);
        return new QLHoaDon(x.getId(), nvs.selectByID(x.getNhanVien().getId()),
                x.getMa(), x.getNgayThanhToan(), x.getTrangThai(), x.getTenNguoiNhan(), x.getSdt(), x.getDiaChi(), x.getTongTien());
    }

    public String getIdByMa(String x) {
        return hdr.getIdByMa(x);
    }
}
