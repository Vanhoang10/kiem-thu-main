/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.KhachHang;
import DomainModels.LoaiKhachHang;
import Reponsitory.Iplm.LoaiKhachHangReponsitory;
import Services.IObjectService;
import ViewModel.QLLoaiKhachHang;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class LoaiKhachHangService implements IObjectService<QLLoaiKhachHang> {

    private final LoaiKhachHangReponsitory lkhr;
    List<QLLoaiKhachHang> list = new ArrayList<>();

    public LoaiKhachHangService() {
        this.lkhr = new LoaiKhachHangReponsitory();
    }

    @Override
    public List<QLLoaiKhachHang> selectAll() {

        List<LoaiKhachHang> kh = lkhr.selectAll();
        for (LoaiKhachHang l : kh) {
            list.add(new QLLoaiKhachHang(l.getId(), l.getMa(), l.getTen(),
                    l.getDacQuyen(), l.getNgayTao(), l.getNgaySua(), l.getTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLLoaiKhachHang> selectByWhere(String where) {
        for (LoaiKhachHang l : lkhr.selectByWhere(where)) {
            list.add(new QLLoaiKhachHang(l.getId(), l.getMa(), l.getTen(),
                    l.getDacQuyen(), l.getNgayTao(), l.getNgaySua(), l.getTrangThai()));
        }
        return list;
    }

    @Override
    public QLLoaiKhachHang selectByIDorMa(String x) {
        LoaiKhachHang l = lkhr.selectByIDorMa(x);
        return new QLLoaiKhachHang(l.getId(), l.getMa(), l.getTen(),
                l.getDacQuyen(), l.getNgayTao(), l.getNgaySua(), l.getTrangThai());
    }

    @Override
    public int update(QLLoaiKhachHang t) {
        return lkhr.update(new LoaiKhachHang(t.getId(), t.getMa(), t.getTen(),
                t.getDacQuyen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLLoaiKhachHang t) {
        return lkhr.insert(new LoaiKhachHang(t.getId(), t.getMa(), t.getTen(),
                t.getDacQuyen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return lkhr.delete(t);
    }

    public String getIdByMa(String ma) {
        return lkhr.getIdByMa(ma);
    }
}
