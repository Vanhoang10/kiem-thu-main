/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.NSX;
import Reponsitory.Iplm.NSXReponsitory;
import Services.IObjectService;
import ViewModel.QLNSX;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class NSXService implements IObjectService<QLNSX>{
    private final NSXReponsitory nsxr;

    public NSXService() {
        this.nsxr = new NSXReponsitory();
    }

    @Override
    public List<QLNSX> selectAll() {
        List<QLNSX> list = new ArrayList<>();
        for (NSX x : nsxr.selectAll()) {
            list.add(new QLNSX(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLNSX> selectByWhere(String where) {
        List<QLNSX> list = new ArrayList<>();
        for (NSX x : nsxr.selectByWhere(where)) {
            list.add(new QLNSX(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public QLNSX selectByIDorMa(String x) {
        NSX cl = nsxr.selectByIDorMa(x);
        return new QLNSX(cl.getId(), cl.getMa(), cl.getTen(), cl.getNgayTao(), cl.getNgaySua(), cl.getTrangThai());
    }

    @Override
    public int update(QLNSX t) {
        return nsxr.update(new NSX(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLNSX t) {
        return nsxr.insert(new NSX(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return nsxr.delete(t);
    }
}
