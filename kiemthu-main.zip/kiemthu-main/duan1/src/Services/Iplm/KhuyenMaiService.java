/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.KhuyenMai;

import Reponsitory.Iplm.KhuyenMaiReponsitory;
import Services.IObjectService;
import ViewModel.QLKhuyenMai;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class KhuyenMaiService implements IObjectService<QLKhuyenMai> {

    private final KhuyenMaiReponsitory kmr;

    public KhuyenMaiService() {
        this.kmr = new KhuyenMaiReponsitory();
    }

    public List<QLKhuyenMai> select(List<KhuyenMai> lists) {
        List<QLKhuyenMai> list = new ArrayList<>();
        for (KhuyenMai x : lists) {
            list.add(new QLKhuyenMai(x.getId(), x.getMa(), x.getTen(),
                    x.getMucGiaGiam(), x.getThoiGianBatDau(), x.getThoiGianKetThuc(),
                    x.getTrangthai()));
        }
        return list;
    }

    @Override
    public List<QLKhuyenMai> selectAll() {
        return select(kmr.selectAll());
    }

    @Override
    public List<QLKhuyenMai> selectByWhere(String where) {
        return select(kmr.selectByWhere(where));
    }

    @Override
    public QLKhuyenMai selectByIDorMa(String ma) {
        KhuyenMai x = kmr.selectByIDorMa(ma);
        return new QLKhuyenMai(x.getId(), x.getMa(), x.getTen(),
                x.getMucGiaGiam(), x.getThoiGianBatDau(), x.getThoiGianKetThuc(),
                x.getTrangthai());
    }

    public QLKhuyenMai selectByTen(String ma) {
        KhuyenMai x = kmr.selectByTen(ma);
        return new QLKhuyenMai(x.getId(), x.getMa(), x.getTen(),
                x.getMucGiaGiam(), x.getThoiGianBatDau(), x.getThoiGianKetThuc(),
                x.getTrangthai());
    }

    public String selectIDOne(String x) {
        return kmr.selectIDOne(x);
    }

    @Override
    public int update(QLKhuyenMai x) {
        return kmr.update(new KhuyenMai(x.getId(), x.getMa(), x.getTen(),
                x.getMucGiaGiam(), x.getThoiGianBatDau(), x.getThoiGianKetThuc(),
                x.getTrangthai()));
    }

    @Override
    public int insert(QLKhuyenMai x) {
        return kmr.insert(new KhuyenMai(x.getId(), x.getMa(), x.getTen(),
                x.getMucGiaGiam(), x.getThoiGianBatDau(), x.getThoiGianKetThuc(),
                x.getTrangthai()));
    }

    @Override
    public int delete(String t) {
        return kmr.delete(t);
    }

    public int update(QLKhuyenMai x, String t) {
        return kmr.update(new KhuyenMai(x.getId(), x.getMa(), x.getTen(),
                x.getMucGiaGiam(), x.getThoiGianBatDau(), x.getThoiGianKetThuc(),
                x.getTrangthai()), t);
    }

}
