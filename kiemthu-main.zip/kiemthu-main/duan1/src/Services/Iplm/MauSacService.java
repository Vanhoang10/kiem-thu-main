/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.MauSac;
import Reponsitory.Iplm.MauSacReponsitory;
import Services.IObjectService;
import ViewModel.QLMauSac;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class MauSacService implements IObjectService<QLMauSac>{
    private final MauSacReponsitory msr;

    public MauSacService() {
        this.msr = new MauSacReponsitory();
    }

    @Override
    public List<QLMauSac> selectAll() {
        List<QLMauSac> list = new ArrayList<>();
        for (MauSac x : msr.selectAll()) {
            list.add(new QLMauSac(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLMauSac> selectByWhere(String where) {
        List<QLMauSac> list = new ArrayList<>();
        for (MauSac x : msr.selectByWhere(where)) {
            list.add(new QLMauSac(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public QLMauSac selectByIDorMa(String x) {
        MauSac cl = msr.selectByIDorMa(x);
        return new QLMauSac(cl.getId(), cl.getMa(), cl.getTen(), cl.getNgayTao(), cl.getNgaySua(), cl.getTrangThai());
    }

    @Override
    public int update(QLMauSac t) {
        return msr.update(new MauSac(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLMauSac t) {
        return msr.insert(new MauSac(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return msr.delete(t);
    }
}
