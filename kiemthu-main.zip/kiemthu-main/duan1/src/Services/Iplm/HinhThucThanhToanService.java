/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.HinhThucThanhToan;

import Reponsitory.Iplm.HinhThucThanhToanReponsitory;
import Services.IObjectService;
import ViewModel.QLHinhThucThanhToan;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class HinhThucThanhToanService implements IObjectService<QLHinhThucThanhToan>{
    private final HinhThucThanhToanReponsitory httt;
    
    public HinhThucThanhToanService(){
        this.httt = new HinhThucThanhToanReponsitory();
        
    }

    @Override
    public List<QLHinhThucThanhToan> selectAll() {
        List<QLHinhThucThanhToan> list = new ArrayList<>();
        for (HinhThucThanhToan x : httt.selectAll()) {
            list.add(new QLHinhThucThanhToan(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLHinhThucThanhToan> selectByWhere(String where) {
        List<QLHinhThucThanhToan> list = new ArrayList<>();
        for (HinhThucThanhToan x : httt.selectByWhere(where)) {
            list.add(new QLHinhThucThanhToan(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public QLHinhThucThanhToan selectByIDorMa(String x) {
       HinhThucThanhToan cl = httt.selectByIDorMa(x);
        return new QLHinhThucThanhToan(cl.getId(),
                cl.getMa(), cl.getTen(), cl.getNgayTao(), cl.getNgaySua(), cl.getTrangThai());
    }

    @Override
    public int update(QLHinhThucThanhToan t) {
         return httt.update(new HinhThucThanhToan(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLHinhThucThanhToan t) {
        return httt.insert(new HinhThucThanhToan(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return httt.delete(t);
    }
    
}
