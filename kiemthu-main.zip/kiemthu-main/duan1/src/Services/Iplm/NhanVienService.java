/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.ChucVu;
import DomainModels.NhanVien;
import Reponsitory.Iplm.ChucVuReponsitory;
import Reponsitory.Iplm.NhanVienReponsitory;
import Services.IObjectService;
import ViewModel.QLNhanVien;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class NhanVienService implements IObjectService<QLNhanVien> {

    public final NhanVienReponsitory nvr;
    public final ChucVuService cvs = new ChucVuService();
    public final ChucVuReponsitory cvr = new ChucVuReponsitory();
    List<QLNhanVien> listnv;

    public NhanVienService() {
        this.nvr = new NhanVienReponsitory();
    }

    @Override
    public List<QLNhanVien> selectAll() {
        List<NhanVien> nv = nvr.selectAll();
        listnv = new ArrayList<>();
        for (NhanVien n : nv) {
            listnv.add(new QLNhanVien(n.getId(), n.getMa(), n.getHoVaTen(),
                    n.isGioiTinh(), n.getNgaySinh(), n.getCmt_cccd(), n.getDiaChi(),
                    n.getSdt(), n.getEmail(), n.getMatKhau(), n.getTrangThai(),
                    cvs.selectByIDorMa(n.getChucVu().getId())));
        }
        return listnv;
    }

    @Override
    public List<QLNhanVien> selectByWhere(String where) {
        return select(nvr.selectByWhere(where));

    }

    @Override
    public QLNhanVien selectByIDorMa(String x) {
        NhanVien nv = nvr.selectByIDorMa(x);
        return new QLNhanVien(nv.getId(), nv.getMa(), nv.getHoVaTen(), nv.isGioiTinh(),
                nv.getNgaySinh(), nv.getCmt_cccd(), nv.getDiaChi(), nv.getSdt(),
                nv.getEmail(), nv.getMatKhau(), nv.getTrangThai(), cvs.selectByIDorMa(nv.getChucVu().getId()));
    }

    public QLNhanVien selectByID(String x) {
        NhanVien nv = nvr.selectByID(x);
        return new QLNhanVien(nv.getId(), nv.getMa(), nv.getHoVaTen(), nv.isGioiTinh(),
                nv.getNgaySinh(), nv.getCmt_cccd(), nv.getDiaChi(), nv.getSdt(),
                nv.getEmail(), nv.getMatKhau(), nv.getTrangThai(), cvs.selectByIDorMa(nv.getChucVu().getId()));
    }

    @Override
    public int update(QLNhanVien t) {
        return nvr.update(new NhanVien(t.getId(), t.getMa(), t.getHoVaTen(), t.isGioiTinh(),
                t.getNgaySinh(), t.getCmt_cccd(), t.getDiaChi(), t.getSdt(), t.getEmail(),
                t.getMatKhau(), t.getTrangThai(), cvr.selectByIDorMa(t.getChucVu().getId())));
    }

    @Override
    public int insert(QLNhanVien t) {
        return nvr.insert(new NhanVien(t.getId(), t.getMa(), t.getHoVaTen(), t.isGioiTinh(),
                t.getNgaySinh(), t.getCmt_cccd(), t.getDiaChi(), t.getSdt(), t.getEmail(),
                t.getMatKhau(), t.getTrangThai(), cvr.selectByIDorMa(t.getChucVu().getId())));
    }

    @Override
    public int delete(String t) {
        return nvr.delete(t);
    }

    public List<QLNhanVien> select(List<NhanVien> nv) {
        List<QLNhanVien> list = new ArrayList<>();
        for (NhanVien n : nv) {
            list.add(new QLNhanVien(n.getId(), n.getMa(), n.getHoVaTen(),
                    n.isGioiTinh(), n.getNgaySinh(), n.getCmt_cccd(), n.getDiaChi(),
                    n.getSdt(), n.getEmail(), n.getMatKhau(), n.getTrangThai(),
                    cvs.selectByIDorMa(n.getChucVu().getId())));
        }
        return list;
    }

    public List<QLNhanVien> setLoc(String where) {
        return select(nvr.loc(where));
    }

    public String login(String email, String matKhau) {
        return nvr.login(email, matKhau);
    }

    public String forgin(String email) {
        return nvr.forgin(email);
    }

    public int layLaiMK(String email, String mkm) {
        return nvr.layLaiMK(email, mkm);
    }

    public QLNhanVien getByMa(String ma) {
        NhanVien a = nvr.getByMa(ma);
        QLNhanVien x = new QLNhanVien();
        x.setMatKhau(a.getMatKhau());
        x.setEmail(a.getEmail());
        return x;
    }
}
