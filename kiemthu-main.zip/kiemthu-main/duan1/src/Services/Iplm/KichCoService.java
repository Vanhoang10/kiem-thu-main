/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.KichCo;
import Reponsitory.Iplm.KichCoReponsitory;
import Services.IObjectService;
import ViewModel.QLKichCo;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class KichCoService  implements IObjectService<QLKichCo>{
    private final KichCoReponsitory kcr;

    public KichCoService() {
        this.kcr = new KichCoReponsitory();
    }

    @Override
    public List<QLKichCo> selectAll() {
        List<QLKichCo> list = new ArrayList<>();
        for (KichCo x : kcr.selectAll()) {
            list.add(new QLKichCo(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLKichCo> selectByWhere(String where) {
        List<QLKichCo> list = new ArrayList<>();
        for (KichCo x : kcr.selectByWhere(where)) {
            list.add(new QLKichCo(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public QLKichCo selectByIDorMa(String x) {
        KichCo cl = kcr.selectByIDorMa(x);
        return new QLKichCo(cl.getId(), cl.getMa(), cl.getTen(), cl.getNgayTao(), cl.getNgaySua(), cl.getTrangThai());
    }

    @Override
    public int update(QLKichCo t) {
        return kcr.update(new KichCo(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLKichCo t) {
        return kcr.insert(new KichCo(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return kcr.delete(t);
    }
}
