/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.KhachHang;
import Reponsitory.Iplm.KhachHangReponsitory;
import Reponsitory.Iplm.LoaiKhachHangReponsitory;
import Services.IObjectService;
import ViewModel.QLKhachHang;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class KhachHangService implements IObjectService<QLKhachHang> {

    private final KhachHangReponsitory khr;

    private final LoaiKhachHangReponsitory lkhr = new LoaiKhachHangReponsitory();
    private final LoaiKhachHangService lkhs = new LoaiKhachHangService();

    public KhachHangService() {
        this.khr = new KhachHangReponsitory();
    }

    public List<QLKhachHang> select(List<KhachHang> kh) {
        List<QLKhachHang> list = new ArrayList<>();
        for (KhachHang k : kh) {
            list.add(new QLKhachHang(k.getId(), k.getMa(), k.getHoVaTen(),
                    k.getNgaySinh(), k.getSdt(), k.getDiaChi(), k.getNgayTao(),
                    k.getNgaySua(), k.getTrangThai(), lkhs.selectByIDorMa(k.getLoaiKhachHang().getId())));
        }
        return list;
    }

    @Override
    public List<QLKhachHang> selectAll() {
        return select(khr.selectAll());
    }

    public List<QLKhachHang> selectKhThuong() {
        return select(khr.selectKhThuong());
    }

    public List<QLKhachHang> selectKhVip() {
        return select(khr.selectKhVip());
    }

    @Override
    public List<QLKhachHang> selectByWhere(String where) {
        return select(khr.selectByWhere(where));
    }

    @Override
    public QLKhachHang selectByIDorMa(String x) {
        KhachHang q = khr.selectByIDorMa(x);
        return new QLKhachHang(q.getId(), q.getMa(), q.getHoVaTen(),
                q.getNgaySinh(), q.getSdt(), q.getDiaChi(), q.getNgayTao(),
                q.getNgaySua(), q.getTrangThai(), lkhs.selectByIDorMa(q.getLoaiKhachHang().getId()));
    }

    public QLKhachHang selectByMa(String x) {
        KhachHang q = khr.selectByMa(x);
        return new QLKhachHang(q.getId(), q.getMa(), q.getHoVaTen(),
                q.getNgaySinh(), q.getSdt(), q.getDiaChi(), q.getNgayTao(),
                q.getNgaySua(), q.getTrangThai(), lkhs.selectByIDorMa(q.getLoaiKhachHang().getId()));
    }

    @Override
    public int update(QLKhachHang t) {
        return khr.update(new KhachHang(t.getId(), t.getMa(), t.getHoVaTen(), t.getNgaySinh(),
                t.getSdt(), t.getDiaChi(), t.getNgayTao(), t.getNgaySua(),
                t.getTrangThai(), lkhr.selectByIDorMa(t.getQlloaiKhachHang().getId())));
    }

    @Override
    public int insert(QLKhachHang t) {
        return khr.insert(new KhachHang(t.getId(), t.getMa(), t.getHoVaTen(), t.getNgaySinh(),
                t.getSdt(), t.getDiaChi(), t.getNgayTao(), t.getNgaySua(),
                t.getTrangThai(),lkhr.selectByIDorMa(t.getQlloaiKhachHang().getId())));
    }

    @Override
    public int delete(String t) {
        return khr.delete(t);
    }

    public List<QLKhachHang> selectAllAn() {
        return select(khr.selectAllAn());
    }

    public int selectbyAn(int i, String where) {
        return khr.setAnkh(i, where);
    }

    public List<QLKhachHang> selectBySDT(String x) {
        return select(khr.selectBySDT(x));
    }

    public int insertTaiQuay(QLKhachHang t) {
        return khr.insertTaiQuay(new KhachHang(t.getMa(), t.getHoVaTen(), t.getSdt()));
    }

    public String selectID(String x) {
        return khr.selectID(x);
    }

    public int insertGiaoHang(QLKhachHang t) {
        return khr.insertTaiQuay(new KhachHang(t.getMa(), t.getHoVaTen(), t.getSdt(), t.getDiaChi()));
    }

    public List<QLKhachHang> getBanHang() {
        List<QLKhachHang> list = new ArrayList<>();
        for (KhachHang x : khr.getBanHang()) {
            QLKhachHang kh = new QLKhachHang();
            kh.setMa(x.getMa());
            kh.setSdt(x.getSdt());
            kh.setHoVaTen(x.getHoVaTen());
            list.add(kh);
        }
        return list;
    }

    public List<QLKhachHang> getBanHangMa(String ma) {
        List<QLKhachHang> list = new ArrayList<>();
        for (KhachHang x : khr.getBanHangMa(ma)) {
            QLKhachHang kh = new QLKhachHang();
            kh.setMa(x.getMa());
            kh.setSdt(x.getSdt());
            kh.setHoVaTen(x.getHoVaTen());
            list.add(kh);
        }
        return list;
    }

    public QLKhachHang getBanHangKH(String ma) {
        KhachHang x = khr.getBanHangKH(ma);
        QLKhachHang kh = new QLKhachHang();
        kh.setMa(x.getMa());
        kh.setSdt(x.getSdt());
        kh.setHoVaTen(x.getHoVaTen());
        return kh;
    }

    public String getIdByMa(String ma) {
        return khr.getIdByMa(ma);
    }

    public int updateLoaiKhachHang(String idLKH, String ma) {
        return khr.updateLoaiKhachHang(idLKH, ma);
    }
}
