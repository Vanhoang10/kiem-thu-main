/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.DongSP;
import Reponsitory.Iplm.DongSPReponsitory;
import Services.IObjectService;
import ViewModel.QLDongSP;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class DongSPService  implements IObjectService<QLDongSP>{
    private final DongSPReponsitory dspr;

    public DongSPService() {
        this.dspr = new DongSPReponsitory();
    }

    @Override
    public List<QLDongSP> selectAll() {
        List<QLDongSP> list = new ArrayList<>();
        for (DongSP x : dspr.selectAll()) {
            list.add(new QLDongSP(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLDongSP> selectByWhere(String where) {
        List<QLDongSP> list = new ArrayList<>();
        for (DongSP x : dspr.selectByWhere(where)) {
            list.add(new QLDongSP(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public QLDongSP selectByIDorMa(String x) {
        DongSP cl = dspr.selectByIDorMa(x);
        return new QLDongSP(cl.getId(), cl.getMa(), cl.getTen(), cl.getNgayTao(), cl.getNgaySua(), cl.getTrangThai());
    }

    @Override
    public int update(QLDongSP t) {
        return dspr.update(new DongSP(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLDongSP t) {
        return dspr.insert(new DongSP(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return dspr.delete(t);
    }
}
