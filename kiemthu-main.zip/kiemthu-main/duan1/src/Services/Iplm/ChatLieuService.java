/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.ChatLieu;
import Reponsitory.Iplm.ChatLieuReponsitory;
import Services.IObjectService;
import ViewModel.QLChatLieu;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class ChatLieuService implements IObjectService<QLChatLieu> {

    private final ChatLieuReponsitory clr;

    public ChatLieuService() {
        this.clr = new ChatLieuReponsitory();
    }

    @Override
    public List<QLChatLieu> selectAll() {
        List<QLChatLieu> list = new ArrayList<>();
        for (ChatLieu x : clr.selectAll()) {
            list.add(new QLChatLieu(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLChatLieu> selectByWhere(String where) {
        List<QLChatLieu> list = new ArrayList<>();
        for (ChatLieu x : clr.selectByWhere(where)) {
            list.add(new QLChatLieu(
                    x.getId(),
                    x.getMa(),
                    x.getTen(),
                    x.getNgayTao(),
                    x.getNgaySua(),
                    x.getTrangThai()));
        }
        return list;
    }

    @Override
    public QLChatLieu selectByIDorMa(String x) {
        ChatLieu cl = clr.selectByIDorMa(x);
        return new QLChatLieu(cl.getId(), cl.getMa(), cl.getTen(), cl.getNgayTao(), cl.getNgaySua(), cl.getTrangThai());
    }

    @Override
    public int update(QLChatLieu t) {
        return clr.update(new ChatLieu(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int insert(QLChatLieu t) {
        return clr.insert(new ChatLieu(t.getId(), t.getMa(), t.getTen(), t.getNgayTao(), t.getNgaySua(), t.getTrangThai()));
    }

    @Override
    public int delete(String t) {
        return clr.delete(t);
    }

}
