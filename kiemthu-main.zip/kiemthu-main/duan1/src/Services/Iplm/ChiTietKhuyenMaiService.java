/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services.Iplm;

import DomainModels.ChiTietKhuyenMai;
import Reponsitory.Iplm.ChiTietKhuyenMaiReponsitory;
import Reponsitory.Iplm.ChiTietSanPhamReponsitory;
import Reponsitory.Iplm.KhuyenMaiReponsitory;
import Services.IObjectService;
import ViewModel.QLChiTietKhuyenMai;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author duy09
 */
public class ChiTietKhuyenMaiService implements IObjectService<QLChiTietKhuyenMai> {

    private final ChiTietKhuyenMaiReponsitory ctr;
    private final KhuyenMaiService kms = new KhuyenMaiService();
    private final KhuyenMaiReponsitory kmr = new KhuyenMaiReponsitory();
    private final ChiTietSanPhamService ctsps = new ChiTietSanPhamService();
    private final ChiTietSanPhamReponsitory ctspr = new ChiTietSanPhamReponsitory();

    public ChiTietKhuyenMaiService() {
        this.ctr = new ChiTietKhuyenMaiReponsitory();
    }

    @Override
    public List<QLChiTietKhuyenMai> selectAll() {
        return select(ctr.selectAll());
    }

    public List<QLChiTietKhuyenMai> select(List<ChiTietKhuyenMai> lists) {
        List<QLChiTietKhuyenMai> list = new ArrayList<>();
        for (ChiTietKhuyenMai x : lists) {
            list.add(new QLChiTietKhuyenMai(x.getId(),
                    x.getMa(),
                    kms.selectByIDorMa(x.getKhuyenMai().getId()),
                    ctsps.selectByIDorMa(x.getChiTietSanPham().getId()),
                    x.getDonGiaKhiGiam(), x.isTrangThai()));
        }
        return list;
    }

    @Override
    public List<QLChiTietKhuyenMai> selectByWhere(String where) {
        return select(ctr.selectByWhere(where));
    }

    public List<QLChiTietKhuyenMai> selectBySP(String where) {
        List<QLChiTietKhuyenMai> list = new ArrayList<>();
        for (ChiTietKhuyenMai x : ctr.selectBySP(where)) {
            list.add(new QLChiTietKhuyenMai(
                    kms.selectByIDorMa(x.getKhuyenMai().getId()),
                    ctsps.selectByIDorMa(x.getChiTietSanPham().getId())));
        }
        return list;
    }

    @Override
    public QLChiTietKhuyenMai selectByIDorMa(String x) {
        ChiTietKhuyenMai ct = ctr.selectByIDorMa(x);
        return new QLChiTietKhuyenMai(ct.getId(), ct.getMa(), kms.selectByIDorMa(ct.getKhuyenMai().getId()),
                ctsps.selectByIDorMa(ct.getChiTietSanPham().getId()), ct.getDonGiaKhiGiam(), ct.isTrangThai());
    }

    @Override
    public int update(QLChiTietKhuyenMai ct) {
        return ctr.update(new ChiTietKhuyenMai(ct.getId(), ct.getMa(), kmr.selectByIDorMa(ct.getKhuyenMai().getId()),
                ctspr.selectByIDorMa(ct.getChiTietSanPham().getId()), ct.getDonGiaKhiGiam(), ct.isTrangThai()));
    }

    @Override
    public int insert(QLChiTietKhuyenMai ct) {
        return ctr.insert(new ChiTietKhuyenMai(ct.getId(), ct.getMa(), kmr.selectByIDorMa(ct.getKhuyenMai().getId()),
                ctspr.selectByIDorMa(ct.getChiTietSanPham().getId()), ct.getDonGiaKhiGiam(), ct.isTrangThai()));
    }

    @Override
    public int delete(String t) {
        return ctr.delete(t);
    }

    public int delete() {
        return ctr.delete();
    }

    public int updateSP(QLChiTietKhuyenMai ct) {
        return ctr.updateSP(new ChiTietKhuyenMai(ct.getId(), ct.getMa(), kmr.selectByIDorMa(ct.getKhuyenMai().getId()),
                ctspr.selectByIDorMa(ct.getChiTietSanPham().getId()), ct.getDonGiaKhiGiam(), ct.isTrangThai()));
    }

    public List<QLChiTietKhuyenMai> selectByKM(String x) {
        return select(ctr.selectByKM(x));
    }

}
