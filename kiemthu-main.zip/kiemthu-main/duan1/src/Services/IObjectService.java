/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Services;

import java.util.List;

/**
 *
 * @author duy09
 */
public interface IObjectService<T> {

    List<T> selectAll();

    List<T> selectByWhere(String where);

    T selectByIDorMa(String x);

    int update(T t);

    int insert(T t);

    int delete(String t);
}
