/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Views;

import Services.Iplm.NhanVienService;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.StringWriter;
import javax.mail.PasswordAuthentication;
import java.util.Properties;
import java.util.Random;
import java.util.prefs.Preferences;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author duy09
 */
public class SignIn extends javax.swing.JFrame {
    private NhanVienService nvs = new NhanVienService();
    Timer time;

    public SignIn() {
        initComponents();
        setLocationRelativeTo(null);
        pnlCards.removeAll();
        pnlCards.add(pnlDangNhap);
        pnlCards.repaint();
        pnlCards.revalidate();
        txtUserName.setText("congcong@gmail.com");
        txtPassword.setText("fhjanf");
    }
    //nhớ pass
    public String randomCaptcha() {
        String chuoi = "qwertyuioplkjhgfdsazxcvbnm1234567890";
        Random random = new Random();
        StringBuilder capcha = new StringBuilder();
        int length = 6;
        for (int i = 0; i < length; i++) {
            capcha.append(chuoi.charAt(random.nextInt(chuoi.length())));
        }
        return capcha.toString();
    }

    public boolean checkForget() {
        StringBuilder err = new StringBuilder();

        String pass = new String(txtPasswordForget.getPassword()).trim();
        String passCon = new String(txtPasswordForgetConfirm.getPassword()).trim();
        if (!txtMaXacNhan.getText().equals(maXacNhan)) {
            err.append("Mã xác nhận không chính xác");
        } else if (pass.isEmpty()) {
            err.append("Vui lòng nhập mật khẩu");
        } else if (!pass.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&:])[A-Za-z\\d@$!%*?&:]{8,}$")) {
            err.append("Mật khẩu chưa đủ mạnh");
        } else if (passCon.isEmpty()) {
            err.append("Vui lòng xác nhận lại mật khẩu");
        } else if (!passCon.equals(pass)) {
            err.append("Mật khẩu không giống nhau");
        } else if (!txtCaptcha.getText().equalsIgnoreCase(btnCaptcha.getText())) {
            err.append("Mã captcha không đúng");
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Quên mật khẩu", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        pnlCards = new javax.swing.JPanel();
        pnlDangNhap = new javax.swing.JPanel();
        txtUserName = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        txtPassword = new javax.swing.JPasswordField();
        btnShowPass = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pnlQuenMatKhau = new javax.swing.JPanel();
        txtPasswordForgetConfirm = new javax.swing.JPasswordField();
        jButton4 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnShowpassForget = new javax.swing.JLabel();
        sptPassCon = new javax.swing.JSeparator();
        txtPasswordForget = new javax.swing.JPasswordField();
        btnShowPassForgetConfirm = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtMaXacNhan = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        txtCaptcha = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel11 = new javax.swing.JLabel();
        sptPass = new javax.swing.JSeparator();
        jButton2 = new javax.swing.JButton();
        jSeparator7 = new javax.swing.JSeparator();
        btnNhanMa = new javax.swing.JButton();
        btnCaptcha = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        jPanel5.setBackground(new java.awt.Color(66, 99, 132));
        jPanel5.setMaximumSize(new java.awt.Dimension(350, 400));
        jPanel5.setMinimumSize(new java.awt.Dimension(350, 400));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 350, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );

        pnlCards.setBackground(new java.awt.Color(255, 255, 255));
        pnlCards.setMaximumSize(new java.awt.Dimension(350, 400));
        pnlCards.setMinimumSize(new java.awt.Dimension(350, 400));
        pnlCards.setPreferredSize(new java.awt.Dimension(350, 400));
        pnlCards.setLayout(new java.awt.CardLayout());

        pnlDangNhap.setBackground(new java.awt.Color(255, 255, 255));

        txtUserName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtUserName.setBorder(null);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("Mật khẩu");

        txtPassword.setBorder(null);
        txtPassword.setFocusAccelerator('\u2022');

        btnShowPass.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnShowPass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/showpass.png"))); // NOI18N
        btnShowPass.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnShowPassMouseClicked(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(39, 72, 159));
        jLabel4.setText("Quên mật khẩu?");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(48, 194, 254));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Đăng nhập");
        jButton1.setPreferredSize(new java.awt.Dimension(280, 50));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Đăng nhập");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("Email");

        javax.swing.GroupLayout pnlDangNhapLayout = new javax.swing.GroupLayout(pnlDangNhap);
        pnlDangNhap.setLayout(pnlDangNhapLayout);
        pnlDangNhapLayout.setHorizontalGroup(
            pnlDangNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDangNhapLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(pnlDangNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel4)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtUserName, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlDangNhapLayout.createSequentialGroup()
                        .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnShowPass, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        pnlDangNhapLayout.setVerticalGroup(
            pnlDangNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDangNhapLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel1)
                .addGap(77, 77, 77)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtUserName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlDangNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnShowPass)
                    .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(202, Short.MAX_VALUE))
        );

        pnlCards.add(pnlDangNhap, "card2");

        pnlQuenMatKhau.setBackground(new java.awt.Color(255, 255, 255));

        txtPasswordForgetConfirm.setBorder(null);
        txtPasswordForgetConfirm.setFocusAccelerator('\u2022');
        txtPasswordForgetConfirm.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPasswordForgetConfirmKeyReleased(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(254, 254, 254));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/update.png"))); // NOI18N
        jButton4.setBorder(null);
        jButton4.setBorderPainted(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 204, 204));
        jLabel5.setText("Nhập lại mật khẩu");

        btnShowpassForget.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnShowpassForget.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/showpass.png"))); // NOI18N
        btnShowpassForget.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnShowpassForgetMouseClicked(evt);
            }
        });

        txtPasswordForget.setBorder(null);
        txtPasswordForget.setFocusAccelerator('\u2022');
        txtPasswordForget.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPasswordForgetKeyReleased(evt);
            }
        });

        btnShowPassForgetConfirm.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnShowPassForgetConfirm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/showpass.png"))); // NOI18N
        btnShowPassForgetConfirm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnShowPassForgetConfirmMouseClicked(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(39, 72, 159));
        jLabel7.setText("Quay lại đăng nhập");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("Mã xác nhận");

        txtMaXacNhan.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtMaXacNhan.setBorder(null);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 204, 204));
        jLabel8.setText("Captcha");

        txtCaptcha.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCaptcha.setBorder(null);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setText("Quên mật khẩu");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 204, 204));
        jLabel10.setText("Email");

        txtEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtEmail.setBorder(null);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(204, 204, 204));
        jLabel11.setText("Mật khẩu");

        jButton2.setBackground(new java.awt.Color(48, 194, 254));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Hoàn tất");
        jButton2.setPreferredSize(new java.awt.Dimension(280, 50));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnNhanMa.setBackground(new java.awt.Color(254, 254, 254));
        btnNhanMa.setText("Nhận mã");
        btnNhanMa.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnNhanMa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNhanMaActionPerformed(evt);
            }
        });

        btnCaptcha.setBackground(new java.awt.Color(255, 153, 153));
        btnCaptcha.setText(randomCaptcha());
        btnCaptcha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCaptchaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlQuenMatKhauLayout = new javax.swing.GroupLayout(pnlQuenMatKhau);
        pnlQuenMatKhau.setLayout(pnlQuenMatKhauLayout);
        pnlQuenMatKhauLayout.setHorizontalGroup(
            pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuenMatKhauLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQuenMatKhauLayout.createSequentialGroup()
                        .addComponent(txtPasswordForget, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnShowpassForget))
                    .addComponent(jLabel8)
                    .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator4)
                            .addComponent(txtMaXacNhan, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel11)
                            .addComponent(sptPass)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10)
                            .addComponent(jSeparator5)
                            .addGroup(pnlQuenMatKhauLayout.createSequentialGroup()
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(btnNhanMa, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE))))
                    .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(sptPassCon, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlQuenMatKhauLayout.createSequentialGroup()
                            .addComponent(txtPasswordForgetConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(btnShowPassForgetConfirm)))
                    .addGroup(pnlQuenMatKhauLayout.createSequentialGroup()
                        .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtCaptcha, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                            .addComponent(jSeparator7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCaptcha, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQuenMatKhauLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(122, 122, 122))
        );
        pnlQuenMatKhauLayout.setVerticalGroup(
            pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuenMatKhauLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel9)
                .addGap(49, 49, 49)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQuenMatKhauLayout.createSequentialGroup()
                        .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnNhanMa, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtMaXacNhan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jLabel11)
                .addGap(7, 7, 7)
                .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnShowpassForget)
                    .addComponent(txtPasswordForget, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(sptPass, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnShowPassForgetConfirm)
                    .addComponent(txtPasswordForgetConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3)
                .addComponent(sptPassCon, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlQuenMatKhauLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtCaptcha, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnCaptcha, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(2, 2, 2)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        pnlCards.add(pnlQuenMatKhau, "card3");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlCards, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlCards, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);

        pack();
    }// </editor-fold>//GEN-END:initComponents
int index = 0;
    private void btnShowPassMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnShowPassMouseClicked
        // TODO add your handling code here:
        try {
            String[] arrShow = {"src//icons//showpass.png", "src//icons//notshowpass.png"};
            index = index + 1 < 2 ? 1 : 0;
            ImageIcon imgIcon = new ImageIcon(arrShow[index]);
            Image img = imgIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            ImageIcon imgIconFinal = new ImageIcon(img);
            btnShowPass.setIcon(imgIconFinal);
            if (index == 1) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('*');
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnShowPassMouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        // TODO add your handling code here:
        pnlCards.removeAll();
        pnlCards.add(pnlQuenMatKhau);
        pnlCards.repaint();
        pnlCards.revalidate();
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String email = txtUserName.getText();
        String passWord = new String(txtPassword.getPassword());
        String maNV = nvs.login(email, passWord);
        if(maNV.isEmpty()){
            JOptionPane.showMessageDialog(this, "Tên tài khoản hoặc mật khẩu không đúng !", "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
            return;
        }
        new Index(maNV).setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        btnCaptcha.setText(randomCaptcha());
    }//GEN-LAST:event_jButton4ActionPerformed
    int index1 = 0;
    private void btnShowpassForgetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnShowpassForgetMouseClicked
        // TODO add your handling code here:
        try {
            String[] arrShow = {"src//icons//showpass.png", "src//icons//notshowpass.png"};
            index1 = index1 + 1 < 2 ? 1 : 0;
            ImageIcon imgIcon = new ImageIcon(arrShow[index1]);
            Image img = imgIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            ImageIcon imgIconFinal = new ImageIcon(img);
            btnShowpassForget.setIcon(imgIconFinal);
            if (index1 == 1) {
                txtPasswordForget.setEchoChar((char) 0);
            } else {
                txtPasswordForget.setEchoChar('\u2022');
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnShowpassForgetMouseClicked
    int index2 = 0;
    private void btnShowPassForgetConfirmMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnShowPassForgetConfirmMouseClicked
        // TODO add your handling code here:
        try {
            String[] arrShow = {"src//icons//showpass.png", "src//icons//notshowpass.png"};
            index2 = index2 + 1 < 2 ? 1 : 0;
            ImageIcon imgIcon = new ImageIcon(arrShow[index2]);
            Image img = imgIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            ImageIcon imgIconFinal = new ImageIcon(img);
            btnShowPassForgetConfirm.setIcon(imgIconFinal);
            if (index2 == 1) {
                txtPasswordForgetConfirm.setEchoChar((char) 0);
            } else {
                txtPasswordForgetConfirm.setEchoChar('\u2022');
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnShowPassForgetConfirmMouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        pnlCards.removeAll();
        pnlCards.add(pnlDangNhap);
        pnlCards.repaint();
        pnlCards.revalidate();
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if (checkForget()) {
            nvs.layLaiMK(txtEmail.getText(), new String(txtPasswordForget.getPassword()));
            pnlCards.removeAll();
            pnlCards.add(pnlDangNhap);
            pnlCards.repaint();
            pnlCards.revalidate();
        }
    }//GEN-LAST:event_jButton2ActionPerformed
    int i = 60;
    String maXacNhan = "";
    private void btnNhanMaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNhanMaActionPerformed
        String email = txtEmail.getText();
        String maNV = nvs.forgin(email);
        if(maNV.isEmpty()){
            JOptionPane.showMessageDialog(this, "Email không tồn tại!", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        time = new Timer(1000, (e) -> {
            btnNhanMa.setText((i -= 1) + "");
            if (i == 0) {
                btnNhanMa.setText("Nhận mã");
                i = 0;
                time.stop();
            }
        });
        time.start();

        maXacNhan = randomCaptcha();
        final String username = "shopbanquanao.nhom4@gmail.com";
        final String password = "yvsejejkdkqqtfbb";

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", true);
        prop.put("mail.smtp.starttls.enable", true); //TLS

        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("shopbanquanao.nhom4@gmail.com"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(txtEmail.getText())
            );
            message.setSubject("Khôi phục tài khoản phần mềm bán quần áo");
            message.setText("Mã xác nhận của bạn là: " + maXacNhan);

            Transport.send(message);
            JOptionPane.showMessageDialog(this, "Mã xác nhận đã được gửi về email bạn!");
            System.out.println("Done");

        } catch (MessagingException e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnNhanMaActionPerformed

    private void btnCaptchaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCaptchaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCaptchaActionPerformed

    private void txtPasswordForgetKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPasswordForgetKeyReleased
        // TODO add your handling code here:
        String pass = new String(txtPasswordForget.getPassword());
        if (!pass.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&:])[A-Za-z\\d@$!%*?&:]{8,}$")) {
            sptPass.setForeground(Color.red);
        } else {
            sptPass.setForeground(new Color(39, 72, 159));
        }
    }//GEN-LAST:event_txtPasswordForgetKeyReleased

    private void txtPasswordForgetConfirmKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPasswordForgetConfirmKeyReleased
        String pass = new String(txtPasswordForget.getPassword());
        String passCon = new String(txtPasswordForgetConfirm.getPassword());
        if (!passCon.equals(pass)) {
            sptPassCon.setForeground(Color.red);
        } else {
            sptPassCon.setForeground(new Color(39, 72, 159));
        }
    }//GEN-LAST:event_txtPasswordForgetConfirmKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignIn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignIn().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCaptcha;
    private javax.swing.JButton btnNhanMa;
    private javax.swing.JLabel btnShowPass;
    private javax.swing.JLabel btnShowPassForgetConfirm;
    private javax.swing.JLabel btnShowpassForget;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JPanel pnlCards;
    private javax.swing.JPanel pnlDangNhap;
    private javax.swing.JPanel pnlQuenMatKhau;
    private javax.swing.JSeparator sptPass;
    private javax.swing.JSeparator sptPassCon;
    private javax.swing.JTextField txtCaptcha;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtMaXacNhan;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JPasswordField txtPasswordForget;
    private javax.swing.JPasswordField txtPasswordForgetConfirm;
    private javax.swing.JTextField txtUserName;
    // End of variables declaration//GEN-END:variables
}
