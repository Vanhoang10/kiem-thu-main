/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Views;

import Services.Iplm.ChucVuService;
import Services.Iplm.NhanVienService;
import ViewModel.QLChucVu;
import ViewModel.QLNhanVien;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author duy09
 */
public class pnlNhanVien extends javax.swing.JPanel {

    private final NhanVienService nvs = new NhanVienService();
    private final ChucVuService cvs = new ChucVuService();
    DefaultTableModel dtm = new DefaultTableModel();
    DefaultComboBoxModel ccb;
    DefaultComboBoxModel ccbloc;

    public pnlNhanVien() {
        initComponents();

        LoadTable(nvs.selectAll());
        loadTableChucVu();
        ccb = (DefaultComboBoxModel) cbbChucVu.getModel();
        ccbloc = (DefaultComboBoxModel) cbbLocTheoChucVu.getModel();
        ccb.removeAllElements();
        ccbloc.removeAllElements();
        ccb.addElement("- Chức vụ -");
        ccbloc.addElement("- Chức vụ -");
        for (QLChucVu q : cvs.selectAll()) {
            ccb.addElement(q);
            ccbloc.addElement(q);
        }

//        List<QLChucVu> Listcv = cvs.selectAll();
//        cbbChucVu.setModel(new DefaultComboBoxModel(Listcv.toArray()));
//        List<QLChucVu> Listcv = cvs.selectAll();
//        cbbLocTheoChucVu.setModel(new DefaultComboBoxModel(Listcv.toArray()));
    }

    public void LoadTable(List<QLNhanVien> list) {
        dtm = (DefaultTableModel) tbHienThi.getModel();
        dtm.setRowCount(0);
        for (QLNhanVien q : list) {
            dtm.addRow(q.toRow());
        }
    }

    public void fillData(int i) {
        QLNhanVien q = nvs.selectAll().get(i);
        txtMa.setText(q.getMa());
        txtHoTen.setText(q.getHoVaTen());
        txtCccd.setText(q.getCmt_cccd());
        txtDiaChi.setText(q.getDiaChi());
        txtEmail.setText(q.getEmail());
        txtSdt.setText(q.getSdt());
        ccb.setSelectedItem(q.getChucVu());
        dateNgaySinh.setDate(q.getNgaySinh());
        if (q.isGioiTinh() == true) {
            rNam.setSelected(true);
        } else {
            rNu.setSelected(true);
        }
        if (q.getTrangThai() == 0) {
            rDanghd.setSelected(true);
        } else {
            rChuahd.setSelected(true);
        }
    }

    public QLNhanVien getInput() {
        QLNhanVien q = new QLNhanVien();
        q.setMa(txtMa.getText());
        q.setChucVu((QLChucVu) cbbChucVu.getSelectedItem());
        q.setNgaySinh(dateNgaySinh.getDate());
        q.setHoVaTen(txtHoTen.getText());
        q.setCmt_cccd(txtCccd.getText());
        q.setDiaChi(txtDiaChi.getText());
        q.setEmail(txtEmail.getText());
        q.setSdt(txtSdt.getText());
        if (rDanghd.isSelected()) {
            q.setTrangThai(0);
        } else {
            q.setTrangThai(1);
        }
        if (rNam.isSelected()) {
            q.setGioiTinh(true);
        } else {
            q.setGioiTinh(false);
        }
        return q;
    }

    public boolean check() {

        StringBuilder err = new StringBuilder();
        if (cbbChucVu.getSelectedIndex() == 0) {
            err.append("Vui lòng chọn chức vụ");
        } else if (txtMa.getText().trim().isEmpty()) {
            err.append("Mã không được trống");
        } else if (txtHoTen.getText().trim().isEmpty()) {
            err.append("Tên không được trống");
        } else if (txtDiaChi.getText().trim().isEmpty()) {
            err.append("Địa chỉ không được trống");
        } else if (txtSdt.getText().trim().isEmpty()) {
            err.append("Số điện thoại không được trống");
        } else if (txtEmail.getText().trim().isEmpty()) {
            err.append("Email không được trống");
        } else if (txtCccd.getText().trim().isEmpty()) {
            err.append("cmt/cccd không được trống");
        } else if (rNam.isSelected() == false && rNu.isSelected() == false) {
            err.append("Giới tính không được để trống");
        } else if (!txtMa.getText().trim().matches("^NV\\d+$")) {
            err.append("Mã sai ");
        } else if (!(txtCccd.getText().trim().matches("^\\d{9}+$")
                || txtCccd.getText().trim().matches("^\\d{12}+$"))) {
            err.append("Số cmt/cccd không đúng định dạng");
        } else if (!txtSdt.getText().trim().matches("^0\\d{9}+$")) {
            err.append("Số điện thoại không đúng định dạng");
        } //        else if (!txtEmail.getText().trim().matches("^[a-zA-Z0-9_+&*-]+(?:\\\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\\\.)+[a-zA-Z]{2,7}$")) {
        //            err.append("email không đúng định dạng");
        //        } 
        else if (rDanghd.isSelected() == false && rChuahd.isSelected() == false) {
            err.append("Trạng thái không được để trống");
        } else if (txtMa.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append("Mã không được là các kí tự");
        } else if (txtHoTen.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append("Họ và tên không được là các kí tự");
        } else if (txtDiaChi.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append("Họ và tên không được là các kí tự");
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    public boolean checkTrung() {
        StringBuilder err = new StringBuilder();
        for (QLNhanVien q : nvs.selectAll()) {
            if (txtMa.getText().equalsIgnoreCase(q.getMa())) {
                err.append("Mã không được trùng");
            } else if (txtCccd.getText().equalsIgnoreCase(q.getCmt_cccd())) {
                err.append("cmt/cccd không được trùng");
            }
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        diaChucVu = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbChucVu = new javax.swing.JTable();
        txtMaChucVu = new javax.swing.JTextField();
        txtTenCV = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        cbbLocTheoChucVu = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbHienThi = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtMa = new javax.swing.JTextField();
        txtHoTen = new javax.swing.JTextField();
        dateNgaySinh = new com.toedter.calendar.JDateChooser();
        txtSdt = new javax.swing.JTextField();
        txtDiaChi = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        rDanghd = new javax.swing.JRadioButton();
        rChuahd = new javax.swing.JRadioButton();
        jPanel4 = new javax.swing.JPanel();
        txtTimkiem = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cbbChucVu = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        txtCccd = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        rNam = new javax.swing.JRadioButton();
        rNu = new javax.swing.JRadioButton();

        diaChucVu.setMinimumSize(new java.awt.Dimension(500, 400));

        jPanel2.setMinimumSize(new java.awt.Dimension(500, 300));

        tbChucVu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Mã", "Tên chức vụ "
            }
        ));
        tbChucVu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbChucVuMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbChucVu);
        if (tbChucVu.getColumnModel().getColumnCount() > 0) {
            tbChucVu.getColumnModel().getColumn(0).setPreferredWidth(30);
            tbChucVu.getColumnModel().getColumn(1).setPreferredWidth(80);
        }

        jLabel11.setText("Mã :");

        jLabel12.setText("Tên chức vụ :");

        jButton2.setText("Thêm ");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton7.setText("Sửa ");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton9.setText("Làm mới ");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel11))
                        .addGap(3, 3, 3)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMaChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTenCV, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(79, 79, 79)
                                .addComponent(jButton9)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMaChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(jButton2)
                    .addComponent(jButton7))
                .addGap(35, 35, 35)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtTenCV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout diaChucVuLayout = new javax.swing.GroupLayout(diaChucVu.getContentPane());
        diaChucVu.getContentPane().setLayout(diaChucVuLayout);
        diaChucVuLayout.setHorizontalGroup(
            diaChucVuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        diaChucVuLayout.setVerticalGroup(
            diaChucVuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setMaximumSize(new java.awt.Dimension(825, 520));
        setMinimumSize(new java.awt.Dimension(825, 520));
        setPreferredSize(new java.awt.Dimension(825, 520));

        jPanel1.setBackground(new java.awt.Color(222, 231, 227));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Danh sách nhân viên ", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 18))); // NOI18N

        jPanel3.setBackground(new java.awt.Color(222, 231, 227));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Lọc theo chức vụ "));

        jButton1.setText("Lọc");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        cbbLocTheoChucVu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cbbLocTheoChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbbLocTheoChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        tbHienThi.setBackground(new java.awt.Color(222, 231, 227));
        tbHienThi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã ", "Họ tên ", "Giới tính", "Ngày sinh ", "Số cmt/cccd", "Địa chỉ ", "Số điện thoại ", "Email", "Chức Vụ ", "Trạng thái"
            }
        ));
        tbHienThi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbHienThiMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbHienThi);

        jLabel1.setText("Mã :");

        jLabel2.setText("Họ tên :");

        jLabel3.setText("Ngày sinh :");

        jLabel4.setText("Địa chỉ : ");

        jLabel5.setText(" Số điện thoại :");

        jLabel6.setText("Email :");

        jLabel7.setText("Trạng thái :");

        buttonGroup1.add(rDanghd);
        rDanghd.setText("Đang hoạt động");

        buttonGroup1.add(rChuahd);
        rChuahd.setText("Chưa hoạt động");

        jPanel4.setBackground(new java.awt.Color(222, 231, 227));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Tìm kiếm nhân viên theo mã"));

        txtTimkiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimkiemKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtTimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtTimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jButton3.setText("Thêm");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Làm mới ");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Sửa");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel8.setText("Chức Vụ");

        cbbChucVu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel9.setText("cmt/cccd :");

        jButton6.setText(" Chức vụ ");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jLabel10.setText("Giới Tính :");

        buttonGroup2.add(rNam);
        rNam.setText("Nam");

        buttonGroup2.add(rNu);
        rNu.setText("Nữ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtMa, javax.swing.GroupLayout.DEFAULT_SIZE, 209, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtHoTen))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3))
                                .addGap(18, 18, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtDiaChi, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(dateNgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(txtSdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(rNam)
                                        .addGap(48, 48, 48)
                                        .addComponent(rNu))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtEmail)
                                        .addComponent(txtCccd)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jButton3)
                                    .addGap(38, 38, 38)
                                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jButton5)
                                    .addGap(28, 28, 28))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(cbbChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(rChuahd)
                                            .addContainerGap())
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGap(11, 11, 11)))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(20, 20, 20))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(rDanghd)
                                .addGap(186, 186, 186))))))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtDiaChi, txtEmail, txtHoTen, txtMa, txtSdt});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton3, jButton4, jButton5});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cbbChucVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton6))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jLabel2)
                                .addGap(24, 24, 24))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtHoTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(dateNgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtSdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtCccd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rDanghd)
                            .addComponent(jLabel7)
                            .addComponent(rChuahd))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(rNu)
                    .addComponent(rNam)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton3)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton3, jButton4, jButton5});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        getAccessibleContext().setAccessibleName("pnlNhanVien");
    }// </editor-fold>//GEN-END:initComponents

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        diaChucVu.setLocationRelativeTo(this);
        diaChucVu.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void tbHienThiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbHienThiMouseClicked
        int i = tbHienThi.getSelectedRow();
        fillData(i);
        // TODO add your handling code here:
    }//GEN-LAST:event_tbHienThiMouseClicked
    public boolean checkz() {
        if (!(txtCccd.getText().trim().matches("^\\d{9}+$") || txtCccd.getText().trim().matches("^\\d{12}+$"))) {
            JOptionPane.showMessageDialog(null, "Số cmt/cccd không đúng định dạng");
            return false;
        } else {
            return true;
        }

//        || !txtCccd.getText().trim().matches("^\\d{12}+$")
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn không ?",
                "Có chắc chắn thêm không ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (check() && checkTrung()) {
                QLNhanVien nv = getInput();
                if (nvs.insert(nv) != 0) {
                    JOptionPane.showMessageDialog(null, "Thêm thành công");
                    LoadTable(nvs.selectAll());
                } else {
                    JOptionPane.showMessageDialog(null, "Thêm thất bại ");
                }
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        int i = tbHienThi.getSelectedRow();
        if (i == -1) {
            JOptionPane.showMessageDialog(null, "Bạn chưa chọn dòng");
        } else {
            QLNhanVien nv = getInput();
            if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn ?",
                    "Bạn có chắc chắn muốn sửa không ?", JOptionPane.YES_NO_OPTION)
                    == JOptionPane.YES_OPTION) {
                if (check() == true) {
                    if (nvs.update(nv) != 0) {
                        JOptionPane.showMessageDialog(null, "Cập nhật thành công");
                        LoadTable(nvs.selectAll());
                    } else {

                        JOptionPane.showMessageDialog(null, "Cập nhật thất bại ");
                    }
                }
            }
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn ?",
                "Bạn có muốn làm mới không ?", JOptionPane.YES_NO_OPTION)
                == JOptionPane.YES_OPTION) {
            txtCccd.setText("");
            txtDiaChi.setText("");
            txtEmail.setText("");
            txtHoTen.setText("");
            txtMa.setText("");
            txtSdt.setText("");
            dateNgaySinh.setCalendar(null);
            buttonGroup1.clearSelection();
            buttonGroup2.clearSelection();
            LoadTable(nvs.selectAll());
            JOptionPane.showMessageDialog(null, "Làm mới thành công");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn ?",
                "Bạn có muốn làm mới không ?", JOptionPane.YES_NO_OPTION)
                == JOptionPane.YES_OPTION) {
            if (cbbLocTheoChucVu.getSelectedIndex() == 0) {
                LoadTable(nvs.selectAll());
            } else {
                QLChucVu qlcv = (QLChucVu) cbbLocTheoChucVu.getSelectedItem();
                LoadTable(nvs.setLoc(qlcv.getId()));
            }

        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtTimkiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimkiemKeyReleased
        LoadTable(nvs.selectByWhere(txtTimkiem.getText()));
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimkiemKeyReleased

    private void tbChucVuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbChucVuMouseClicked
        int i = tbChucVu.getSelectedRow();
        fillChucVu(i);
        // TODO add your handling code here:
    }//GEN-LAST:event_tbChucVuMouseClicked

    public QLChucVu getInputChucVu() {
        QLChucVu q = new QLChucVu();
        q.setMa(txtMaChucVu.getText());
        q.setTen(txtTenCV.getText());
        return q;
    }

    public boolean checkTrungChucVu() {
        StringBuilder err = new StringBuilder();
        for (QLChucVu q : cvs.selectAll()) {
            if (txtMaChucVu.getText().equalsIgnoreCase(q.getMa())) {
                err.append("Mã chức vụ không được trùng");
            } else if (txtTenCV.getText().equalsIgnoreCase(q.getTen())) {
                err.append("Tên chức vụ không được trùng");
            }
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    public boolean checkChucVu() {
        StringBuilder err = new StringBuilder();
        if (txtMaChucVu.getText().trim().isEmpty()) {
            err.append("Mã không được trống");
        } else if (txtTenCV.getText().trim().isEmpty()) {
            err.append("Tên chức vụ  không được trống");
        } else if (txtMaChucVu.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append("Mã chức vụ không được là các kí tự");
        } else if (txtTenCV.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append("Tên chức vụ không được là các kí tự");
        } else if (!txtMaChucVu.getText().matches("^CV\\w+$")) {
            err.append("Mã chức vụ không đúng định dạng");
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    public void loadTableChucVu() {
        dtm = (DefaultTableModel) tbChucVu.getModel();
        dtm.setRowCount(0);
        List<QLChucVu> chs = cvs.selectAll();
        for (QLChucVu ch : chs) {
            dtm.addRow(ch.toRow());
        }
    }

    public void fillChucVu(int i) {
        QLChucVu q = cvs.selectAll().get(i);
        txtMaChucVu.setText(q.getMa());
        txtTenCV.setText(q.getTen());
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        QLChucVu ql = getInputChucVu();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn thêm ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkChucVu() && checkTrungChucVu() && cvs.insert(ql) != 0) {
                JOptionPane.showMessageDialog(null, "Thêm thành công");
                loadTableChucVu();

            } else {
                JOptionPane.showMessageDialog(null, "Sửa thất bại ");
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        QLChucVu ql = getInputChucVu();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn sửa không  ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkChucVu() && cvs.update(ql) != 0) {
                JOptionPane.showMessageDialog(null, "Sửa thành công");
                loadTableChucVu();
            } else {
                JOptionPane.showMessageDialog(null, "sửa thất bại");
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        if (JOptionPane.showConfirmDialog(null, "Bạn có muốn làm mới không ?",
                "Làm mới bảng", JOptionPane.YES_NO_OPTION)
                == JOptionPane.YES_OPTION) {
            txtMaChucVu.setText("");
            txtTenCV.setText("");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cbbChucVu;
    private javax.swing.JComboBox<String> cbbLocTheoChucVu;
    private com.toedter.calendar.JDateChooser dateNgaySinh;
    private javax.swing.JDialog diaChucVu;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton rChuahd;
    private javax.swing.JRadioButton rDanghd;
    private javax.swing.JRadioButton rNam;
    private javax.swing.JRadioButton rNu;
    private javax.swing.JTable tbChucVu;
    private javax.swing.JTable tbHienThi;
    private javax.swing.JTextField txtCccd;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtHoTen;
    private javax.swing.JTextField txtMa;
    private javax.swing.JTextField txtMaChucVu;
    private javax.swing.JTextField txtSdt;
    private javax.swing.JTextField txtTenCV;
    private javax.swing.JTextField txtTimkiem;
    // End of variables declaration//GEN-END:variables

}
