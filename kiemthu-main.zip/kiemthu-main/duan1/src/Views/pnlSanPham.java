/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Views;

import DomainModels.ChatLieu;
import DomainModels.ChiTietSanPham;
import DomainModels.KichCo;
import DomainModels.SanPham;
import Services.Iplm.ChatLieuService;
import Services.Iplm.ChiTietSanPhamService;
import Services.Iplm.DongSPService;
import Services.Iplm.KichCoService;
import Services.Iplm.MauSacService;
import Services.Iplm.NSXService;
import Services.Iplm.SanPhamService;
import ViewModel.QLChatLieu;
import ViewModel.QLChiTietSanPham;
import ViewModel.QLDongSP;
import ViewModel.QLKichCo;
import ViewModel.QLMauSac;
import ViewModel.QLNSX;
import ViewModel.QLSanPham;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.awt.TextField;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author duy09
 */
public class pnlSanPham extends javax.swing.JPanel {

    private final SanPhamService sps;
    private final ChiTietSanPhamService ctsps;
    private final ChatLieuService cls;
    private final MauSacService mss;
    private final DongSPService dsps;
    private final KichCoService kcs;
    private final NSXService nsxs;

    //validate 
    String ma = "Mã không được trống";
    String ten = "Tên không được trống";
    String tens = "Tên không đúng định dạng";

    private DefaultTableModel dtmSP, dtmTT, dtmAn;
    private DefaultComboBoxModel dcbCl, dcbMs, dcbDsp, dcbNsx, dcbKc, dcbLoc;

    private DefaultTableModel dtmLoaiSp, dtmMauSac, dtmKichCo, dtmChatLieu, dtmNsx;

    public pnlSanPham(SanPhamService spService, ChiTietSanPhamService ctspService,
            ChatLieuService clService, MauSacService msService, DongSPService dspService,
            KichCoService kcService, NSXService nsxService) {
        sps = spService;
        ctsps = ctspService;
        cls = clService;
        mss = msService;
        dsps = dspService;
        kcs = kcService;
        nsxs = nsxService;
        initComponents();
        viewCombobox();
        viewSanPham(ctsps.selectByWhere(""));
        viewAn();
        viewLoaiSP();
        viewLoaiSP();
        viewMauSac();
        viewKichCo();
        viewChatLieu();
        viewNhaSanXuat();

    }
// Load Table

    public void viewSanPham(List<QLChiTietSanPham> list) {
        dtmSP = (DefaultTableModel) tblSanPham.getModel();
        dtmSP.setRowCount(0);
        for (QLChiTietSanPham x : list) {
            dtmSP.addRow(x.getObject());
        }
    }

    public void viewLoaiSP() {
        dtmLoaiSp = (DefaultTableModel) tbLoaiSp.getModel();
        dtmLoaiSp.setRowCount(0);
        for (QLDongSP q : dsps.selectAll()) {
            dtmLoaiSp.addRow(q.getObject());
        }
    }

    public void viewMauSac() {
        dtmMauSac = (DefaultTableModel) tbMauSac.getModel();
        dtmMauSac.setRowCount(0);
        for (QLMauSac q : mss.selectAll()) {
            dtmMauSac.addRow(q.getObject());
        }
    }

    public void viewKichCo() {
        dtmKichCo = (DefaultTableModel) tbKichCo.getModel();
        dtmKichCo.setRowCount(0);
        for (QLKichCo q : kcs.selectAll()) {
            dtmKichCo.addRow(q.getObject());
        }
    }

    public void viewChatLieu() {
        dtmChatLieu = (DefaultTableModel) tbChatLieu.getModel();
        dtmChatLieu.setRowCount(0);
        for (QLChatLieu q : cls.selectAll()) {
            dtmChatLieu.addRow(q.getObject());
        }
    }

    public void viewNhaSanXuat() {
        dtmNsx = (DefaultTableModel) tbNsx.getModel();
        dtmNsx.setRowCount(0);
        for (QLNSX q : nsxs.selectAll()) {
            dtmNsx.addRow(q.getObject());
        }
    }

    public QLChiTietSanPham getForm() {
        return new QLChiTietSanPham(
                txtMa.getText(),
                Integer.parseInt(txtSoLuong.getText()),
                new BigDecimal(txtGiaNhap.getText()),
                new BigDecimal(txtGiaBan.getText()),
                "", 1,
                sps.selectByMa(txtTen.getText()),
                (QLMauSac) cboMauSac.getSelectedItem(),
                (QLChatLieu) cboChatLieu.getSelectedItem(),
                (QLDongSP) cboLoaiSanPham.getSelectedItem(),
                (QLNSX) cboNSX.getSelectedItem(),
                (QLKichCo) cboKichCo.getSelectedItem(),
                new BigDecimal(txtGiaBan.getText()));
    }

    public QLSanPham getSP() {
        return new QLSanPham(txtMa.getText(), txtTen.getText(), new Date(), new Date());
    }

    public void viewCombobox() {
        dcbCl = (DefaultComboBoxModel) cboChatLieu.getModel();
        dcbMs = (DefaultComboBoxModel) cboMauSac.getModel();
        dcbDsp = (DefaultComboBoxModel) cboLoaiSanPham.getModel();
        dcbNsx = (DefaultComboBoxModel) cboNSX.getModel();
        dcbKc = (DefaultComboBoxModel) cboKichCo.getModel();
        dcbLoc = (DefaultComboBoxModel) cboLoc.getModel();

        dcbLoc.removeAllElements();
        dcbCl.removeAllElements();
        dcbMs.removeAllElements();
        dcbDsp.removeAllElements();
        dcbNsx.removeAllElements();
        dcbKc.removeAllElements();

        for (QLChatLieu x : cls.selectAll()) {
            dcbCl.addElement(x);
        }
        for (QLMauSac x : mss.selectAll()) {
            dcbMs.addElement(x);
        }
        dcbLoc.addElement("-Dòng sản phẩm-");
        for (QLDongSP x : dsps.selectAll()) {
            dcbDsp.addElement(x);
            dcbLoc.addElement(x);
        }
        for (QLKichCo x : kcs.selectAll()) {
            dcbKc.addElement(x);
        }
        for (QLNSX x : nsxs.selectAll()) {
            dcbNsx.addElement(x);
        }

    }

    private QLKichCo kc = null;
    private QLDongSP dsp = null;
    private QLMauSac ms = null;
    private QLChatLieu cl = null;
    private QLNSX nsx = null;

    public void fillFormSanPham(int index) {
        QLChiTietSanPham sp = ctsps.selectByWhere("").get(index);
        txtGiaBan.setText(sp.getGiaBan() + "");
        txtGiaNhap.setText(sp.getGiaNhap() + "");
        txtMa.setText(sp.getMa());
        txtTen.setText(sp.getSanPham().getTen());
        txtSoLuong.setText(sp.getSoLuongTon() + "");
        dcbCl.setSelectedItem(sp.getChatLieu());
        dcbDsp.setSelectedItem(sp.getDongSP());
        dcbKc.setSelectedItem(sp.getKichCo());
        dcbMs.setSelectedItem(sp.getMauSac());
        dcbNsx.setSelectedItem(sp.getNsx());
    }

    public void resetFormSP() {
        txtGiaBan.setText("0");
        txtGiaNhap.setText("0");
        txtMa.setText("");
        txtTen.setText("");
        txtSoLuong.setText("0");
        cboChatLieu.setSelectedIndex(0);
        cboKichCo.setSelectedIndex(0);
        cboLoaiSanPham.setSelectedIndex(0);
        cboMauSac.setSelectedIndex(0);
        cboNSX.setSelectedIndex(0);
    }

    // check 
    public boolean checklsp() {
        StringBuilder err = new StringBuilder();

// loai san pham
        if (txtMaLsp.getText().trim().isEmpty()) {
            err.append(ma);
        } else if (txtTenLsp.getText().trim().isEmpty()) {
            err.append(ten);
        } else if (!txtMaLsp.getText().matches("^LSP\\d+$")) {
            err.append("Mã sai ");
        } else if (txtTenLsp.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append(tens);
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    public boolean checkMs() {
        StringBuilder err = new StringBuilder();
        if (txtMaMs.getText().trim().isEmpty()) {
            err.append(ma);
        } else if (txtTenMs.getText().trim().isEmpty()) {
            err.append(ten);
        } else if (!txtMaMs.getText().matches("^MS\\d+$")) {
            err.append("Mã sai ");
        } else if (txtTenMs.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append(tens);
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    public boolean checkKc() {
        StringBuilder err = new StringBuilder();
        if (txtmaKc.getText().trim().isEmpty()) {
            err.append(ma);
        } else if (txtTenKc.getText().trim().isEmpty()) {
            err.append(ten);
        } else if (!txtmaKc.getText().matches("^KC\\d+$")) {
            err.append("Mã sai ");
        } else if (txtTenKc.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append(tens);
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    public boolean checkCl() {
        StringBuilder err = new StringBuilder();
        if (txtMaCl.getText().trim().isEmpty()) {
            err.append(ma);
        } else if (txtTenCl.getText().trim().isEmpty()) {
            err.append(ten);
        } else if (!txtMaCl.getText().matches("^CL\\d+$")) {
            err.append("Mã sai ");
        } else if (txtTenCl.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append(tens);
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    public boolean checkNsx() {
        StringBuilder err = new StringBuilder();
        if (txtMaNsx.getText().trim().isEmpty()) {
            err.append(ma);
        } else if (txtTenNsx.getText().trim().isEmpty()) {
            err.append(ten);
        } else if (!txtMaNsx.getText().matches("^NSX\\d+$")) {
            err.append("Mã sai ");
        } else if (txtTenNsx.getText().trim().matches("[!@#$%&*()_+=|<>?{}\\[\\]~-]")) {
            err.append(tens);
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(null, err);
            return false;
        } else {
            return true;
        }
    }

    public void generateQRcode(String data, String path, String charset, Map map, int h, int w) throws WriterException, IOException {
        BitMatrix matrix = new MultiFormatWriter().encode(new String(data.getBytes(charset), charset),
                BarcodeFormat.QR_CODE, w, h);
        MatrixToImageWriter.writeToFile(matrix, path.substring(path.lastIndexOf('.') + 1), new File(path));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        diaTableAn = new javax.swing.JDialog();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblSanPhamAn = new javax.swing.JTable();
        btnHienThiLai = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        diaLoaiSanPham = new javax.swing.JDialog();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbLoaiSp = new javax.swing.JTable();
        txtMaLsp = new javax.swing.JTextField();
        txtTenLsp = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        diaKichCo = new javax.swing.JDialog();
        txtTenKc = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        tbKichCo = new javax.swing.JTable();
        txtmaKc = new javax.swing.JTextField();
        diaChatLieu = new javax.swing.JDialog();
        txtTenCl = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        tbChatLieu = new javax.swing.JTable();
        txtMaCl = new javax.swing.JTextField();
        diaMauSac = new javax.swing.JDialog();
        txtTenMs = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        tbMauSac = new javax.swing.JTable();
        txtMaMs = new javax.swing.JTextField();
        diaNSX = new javax.swing.JDialog();
        txtTenNsx = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        tbNsx = new javax.swing.JTable();
        txtMaNsx = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtMa = new javax.swing.JTextField();
        txtTen = new javax.swing.JTextField();
        txtSoLuong = new javax.swing.JTextField();
        txtGiaBan = new javax.swing.JTextField();
        txtGiaNhap = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        cboChatLieu = new javax.swing.JComboBox<>();
        cboKichCo = new javax.swing.JComboBox<>();
        cboMauSac = new javax.swing.JComboBox<>();
        cboLoaiSanPham = new javax.swing.JComboBox<>();
        cboNSX = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        cboLoc = new javax.swing.JComboBox<>();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnAn = new javax.swing.JButton();
        btnMoi = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        diaTableAn.setBackground(new java.awt.Color(222, 231, 227));
        diaTableAn.setMinimumSize(new java.awt.Dimension(800, 500));
        diaTableAn.setModal(true);

        tblSanPhamAn.setBackground(new java.awt.Color(222, 231, 227));
        tblSanPhamAn.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã SP", "Tên SP", "Loại SP", "Số lượng", "Chất liệu", "Kích cỡ", "Màu sắc", "NSX", "Giá nhập", "Giá bán"
            }
        ));
        jScrollPane3.setViewportView(tblSanPhamAn);
        if (tblSanPhamAn.getColumnModel().getColumnCount() > 0) {
            tblSanPhamAn.getColumnModel().getColumn(0).setPreferredWidth(30);
            tblSanPhamAn.getColumnModel().getColumn(2).setPreferredWidth(30);
            tblSanPhamAn.getColumnModel().getColumn(3).setPreferredWidth(30);
            tblSanPhamAn.getColumnModel().getColumn(4).setPreferredWidth(30);
            tblSanPhamAn.getColumnModel().getColumn(5).setPreferredWidth(30);
            tblSanPhamAn.getColumnModel().getColumn(6).setPreferredWidth(30);
        }

        btnHienThiLai.setText("Hiển thị lại");
        btnHienThiLai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHienThiLaiActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("Danh sách sản phẩm ẩn");

        javax.swing.GroupLayout diaTableAnLayout = new javax.swing.GroupLayout(diaTableAn.getContentPane());
        diaTableAn.getContentPane().setLayout(diaTableAnLayout);
        diaTableAnLayout.setHorizontalGroup(
            diaTableAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(diaTableAnLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(diaTableAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, diaTableAnLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnHienThiLai, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 756, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(diaTableAnLayout.createSequentialGroup()
                .addGap(288, 288, 288)
                .addComponent(jLabel14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        diaTableAnLayout.setVerticalGroup(
            diaTableAnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(diaTableAnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addGap(15, 15, 15)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHienThiLai)
                .addContainerGap())
        );

        diaLoaiSanPham.setMinimumSize(new java.awt.Dimension(525, 400));

        tbLoaiSp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Mã thuộc tính", "Tên thuộc tính"
            }
        ));
        tbLoaiSp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbLoaiSpMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbLoaiSp);

        jLabel15.setText("Tên thuộc tính :");

        jLabel16.setText("Mã thuộc tính :");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel17.setText("Loại sản phẩm ");

        jButton10.setText("Thêm ");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setText("Sửa");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setText("Làm mới");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout diaLoaiSanPhamLayout = new javax.swing.GroupLayout(diaLoaiSanPham.getContentPane());
        diaLoaiSanPham.getContentPane().setLayout(diaLoaiSanPhamLayout);
        diaLoaiSanPhamLayout.setHorizontalGroup(
            diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(diaLoaiSanPhamLayout.createSequentialGroup()
                .addGroup(diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(diaLoaiSanPhamLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16)))
                    .addGroup(diaLoaiSanPhamLayout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addGroup(diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(diaLoaiSanPhamLayout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(diaLoaiSanPhamLayout.createSequentialGroup()
                                .addGroup(diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtMaLsp, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                                    .addComponent(txtTenLsp, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGroup(diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(diaLoaiSanPhamLayout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton10)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton11))
                                    .addGroup(diaLoaiSanPhamLayout.createSequentialGroup()
                                        .addGap(57, 57, 57)
                                        .addComponent(jButton12))))))
                    .addGroup(diaLoaiSanPhamLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        diaLoaiSanPhamLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton10, jButton11, jButton12});

        diaLoaiSanPhamLayout.setVerticalGroup(
            diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, diaLoaiSanPhamLayout.createSequentialGroup()
                .addComponent(jLabel17)
                .addGap(2, 2, 2)
                .addGroup(diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtMaLsp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton11))
                .addGap(14, 14, 14)
                .addGroup(diaLoaiSanPhamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txtTenLsp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton12))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        diaLoaiSanPhamLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton10, jButton11, jButton12});

        diaKichCo.setMinimumSize(new java.awt.Dimension(525, 400));
        diaKichCo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                diaKichCoMouseClicked(evt);
            }
        });

        jLabel18.setText("Tên thuộc tính :");

        jLabel19.setText("Mã thuộc tính :");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel20.setText("Kích cỡ");

        jButton13.setText("Thêm ");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setText("Sửa");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setText("Làm mới");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        tbKichCo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Mã thuộc tính", "Tên thuộc tính"
            }
        ));
        tbKichCo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbKichCoMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tbKichCo);

        javax.swing.GroupLayout diaKichCoLayout = new javax.swing.GroupLayout(diaKichCo.getContentPane());
        diaKichCo.getContentPane().setLayout(diaKichCoLayout);
        diaKichCoLayout.setHorizontalGroup(
            diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(diaKichCoLayout.createSequentialGroup()
                .addGroup(diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(diaKichCoLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addComponent(jLabel19)))
                    .addGroup(diaKichCoLayout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addGroup(diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(diaKichCoLayout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(diaKichCoLayout.createSequentialGroup()
                                .addGroup(diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtmaKc, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                                    .addComponent(txtTenKc, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGroup(diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(diaKichCoLayout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton13)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton14))
                                    .addGroup(diaKichCoLayout.createSequentialGroup()
                                        .addGap(57, 57, 57)
                                        .addComponent(jButton15))))))
                    .addGroup(diaKichCoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        diaKichCoLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton13, jButton14, jButton15});

        diaKichCoLayout.setVerticalGroup(
            diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, diaKichCoLayout.createSequentialGroup()
                .addComponent(jLabel20)
                .addGap(2, 2, 2)
                .addGroup(diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(txtmaKc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton14))
                .addGap(14, 14, 14)
                .addGroup(diaKichCoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(txtTenKc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton15))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(121, Short.MAX_VALUE))
        );

        diaKichCoLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton13, jButton14, jButton15});

        diaChatLieu.setMinimumSize(new java.awt.Dimension(525, 400));
        diaChatLieu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                diaChatLieuMouseClicked(evt);
            }
        });

        jLabel21.setText("Tên thuộc tính :");

        jLabel22.setText("Mã thuộc tính :");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel23.setText("Chất liệu");

        jButton16.setText("Thêm ");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.setText("Sửa");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.setText("Làm mới");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        tbChatLieu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Mã thuộc tính", "Tên thuộc tính"
            }
        ));
        tbChatLieu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbChatLieuMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tbChatLieu);

        javax.swing.GroupLayout diaChatLieuLayout = new javax.swing.GroupLayout(diaChatLieu.getContentPane());
        diaChatLieu.getContentPane().setLayout(diaChatLieuLayout);
        diaChatLieuLayout.setHorizontalGroup(
            diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(diaChatLieuLayout.createSequentialGroup()
                .addGroup(diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(diaChatLieuLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22)))
                    .addGroup(diaChatLieuLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(diaChatLieuLayout.createSequentialGroup()
                        .addGroup(diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(diaChatLieuLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, diaChatLieuLayout.createSequentialGroup()
                                .addGap(130, 130, 130)
                                .addGroup(diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtMaCl, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                                    .addComponent(txtTenCl, javax.swing.GroupLayout.Alignment.LEADING))))
                        .addGroup(diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(diaChatLieuLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jButton16)
                                .addGap(18, 18, 18)
                                .addComponent(jButton17))
                            .addGroup(diaChatLieuLayout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(jButton18)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        diaChatLieuLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton16, jButton17, jButton18});

        diaChatLieuLayout.setVerticalGroup(
            diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, diaChatLieuLayout.createSequentialGroup()
                .addComponent(jLabel23)
                .addGap(2, 2, 2)
                .addGroup(diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(txtMaCl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton17))
                .addGap(14, 14, 14)
                .addGroup(diaChatLieuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(txtTenCl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton18))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        diaChatLieuLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton16, jButton17, jButton18});

        diaMauSac.setMinimumSize(new java.awt.Dimension(525, 400));
        diaMauSac.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                diaMauSacMouseClicked(evt);
            }
        });

        jLabel24.setText("Tên thuộc tính :");

        jLabel25.setText("Mã thuộc tính :");

        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel26.setText("Màu sắc ");

        jButton19.setText("Thêm ");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jButton20.setText("Sửa");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jButton21.setText("Làm mới");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        tbMauSac.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Mã thuộc tính", "Tên thuộc tính"
            }
        ));
        tbMauSac.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbMauSacMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tbMauSac);

        javax.swing.GroupLayout diaMauSacLayout = new javax.swing.GroupLayout(diaMauSac.getContentPane());
        diaMauSac.getContentPane().setLayout(diaMauSacLayout);
        diaMauSacLayout.setHorizontalGroup(
            diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(diaMauSacLayout.createSequentialGroup()
                .addGroup(diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(diaMauSacLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addComponent(jLabel25)))
                    .addGroup(diaMauSacLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(diaMauSacLayout.createSequentialGroup()
                        .addGroup(diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(diaMauSacLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, diaMauSacLayout.createSequentialGroup()
                                .addGap(130, 130, 130)
                                .addGroup(diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtMaMs, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                                    .addComponent(txtTenMs, javax.swing.GroupLayout.Alignment.LEADING))))
                        .addGroup(diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(diaMauSacLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jButton19)
                                .addGap(18, 18, 18)
                                .addComponent(jButton20))
                            .addGroup(diaMauSacLayout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(jButton21)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        diaMauSacLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton19, jButton20, jButton21});

        diaMauSacLayout.setVerticalGroup(
            diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, diaMauSacLayout.createSequentialGroup()
                .addComponent(jLabel26)
                .addGap(2, 2, 2)
                .addGroup(diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(txtMaMs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton20))
                .addGap(14, 14, 14)
                .addGroup(diaMauSacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(txtTenMs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton21))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        diaMauSacLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton19, jButton20, jButton21});

        diaNSX.setMinimumSize(new java.awt.Dimension(525, 400));
        diaNSX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                diaNSXMouseClicked(evt);
            }
        });

        jLabel27.setText("Tên thuộc tính :");

        jLabel28.setText("Mã thuộc tính :");

        jLabel29.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel29.setText("Nhà sản xuất ");

        jButton22.setText("Thêm ");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jButton23.setText("Sửa");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jButton24.setText("Làm mới");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        tbNsx.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Mã thuộc tính", "Tên thuộc tính"
            }
        ));
        tbNsx.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbNsxMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(tbNsx);

        javax.swing.GroupLayout diaNSXLayout = new javax.swing.GroupLayout(diaNSX.getContentPane());
        diaNSX.getContentPane().setLayout(diaNSXLayout);
        diaNSXLayout.setHorizontalGroup(
            diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(diaNSXLayout.createSequentialGroup()
                .addGroup(diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(diaNSXLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27)
                            .addComponent(jLabel28)))
                    .addGroup(diaNSXLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(diaNSXLayout.createSequentialGroup()
                        .addGroup(diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(diaNSXLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, diaNSXLayout.createSequentialGroup()
                                .addGap(130, 130, 130)
                                .addGroup(diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtMaNsx, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                                    .addComponent(txtTenNsx, javax.swing.GroupLayout.Alignment.LEADING))))
                        .addGroup(diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(diaNSXLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jButton22)
                                .addGap(18, 18, 18)
                                .addComponent(jButton23))
                            .addGroup(diaNSXLayout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(jButton24)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        diaNSXLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton22, jButton23, jButton24});

        diaNSXLayout.setVerticalGroup(
            diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, diaNSXLayout.createSequentialGroup()
                .addComponent(jLabel29)
                .addGap(2, 2, 2)
                .addGroup(diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(txtMaNsx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton23))
                .addGap(14, 14, 14)
                .addGroup(diaNSXLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(txtTenNsx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton24))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        diaNSXLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton22, jButton23, jButton24});

        setBackground(new java.awt.Color(222, 231, 227));
        setMaximumSize(new java.awt.Dimension(825, 520));
        setMinimumSize(new java.awt.Dimension(825, 520));
        setPreferredSize(new java.awt.Dimension(825, 520));

        jPanel1.setBackground(new java.awt.Color(222, 231, 227));
        jPanel1.setMaximumSize(new java.awt.Dimension(825, 520));
        jPanel1.setMinimumSize(new java.awt.Dimension(825, 520));

        jTabbedPane1.setBackground(new java.awt.Color(222, 231, 227));

        jPanel2.setBackground(new java.awt.Color(222, 231, 227));

        jPanel3.setBackground(new java.awt.Color(222, 231, 227));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Quản lý thông tin"));

        jLabel1.setText("Mã sản phẩm");

        jLabel2.setText("Tên sản phẩm");

        jLabel3.setText("Loại sản phẩm");

        jLabel4.setText("Số lượng");

        jLabel5.setText("Chất liệu");

        jLabel6.setText("Kích cỡ");

        jLabel7.setText("Màu sắc");

        jLabel8.setText("NSX");

        jLabel9.setText("Giá nhập");

        txtSoLuong.setText("0");

        txtGiaBan.setText("0");
        txtGiaBan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGiaBanActionPerformed(evt);
            }
        });

        txtGiaNhap.setText("0");

        jLabel10.setText("Giá bán");

        cboChatLieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cboKichCo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cboMauSac.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cboLoaiSanPham.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cboNSX.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/gift.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/tshirt.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/measurement.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/wheel.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMa)
                            .addComponent(txtTen))
                        .addGap(72, 72, 72)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel6))
                        .addGap(23, 23, 23))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(cboChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                            .addComponent(txtSoLuong)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(cboLoaiSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(18, 18, 18)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtGiaBan, javax.swing.GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(cboNSX, javax.swing.GroupLayout.Alignment.LEADING, 0, 174, Short.MAX_VALUE)
                            .addComponent(cboMauSac, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cboKichCo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE)
                            .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(txtGiaNhap))
                .addContainerGap(58, Short.MAX_VALUE))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtGiaBan, txtGiaNhap, txtMa});

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cboChatLieu, cboLoaiSanPham, cboNSX});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel6)
                    .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboKichCo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel7)
                    .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jLabel8)
                        .addComponent(cboLoaiSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cboNSX, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton9))
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtGiaNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel10)
                    .addComponent(cboChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtGiaBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(222, 231, 227));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin sản phẩm"));

        tblSanPham.setBackground(new java.awt.Color(222, 231, 227));
        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã SP", "Tên SP", "Loại SP", "Số lượng", "Chất liệu", "Kích cỡ", "Màu sắc", "NSX", "Giá nhập", "Giá bán"
            }
        ));
        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblSanPham);
        if (tblSanPham.getColumnModel().getColumnCount() > 0) {
            tblSanPham.getColumnModel().getColumn(0).setPreferredWidth(30);
            tblSanPham.getColumnModel().getColumn(2).setPreferredWidth(30);
            tblSanPham.getColumnModel().getColumn(3).setPreferredWidth(30);
            tblSanPham.getColumnModel().getColumn(4).setPreferredWidth(30);
            tblSanPham.getColumnModel().getColumn(5).setPreferredWidth(30);
            tblSanPham.getColumnModel().getColumn(6).setPreferredWidth(30);
        }

        jLabel11.setText("Tìm kiếm sản phẩm");

        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        jLabel13.setText("Loại sản phẩm");

        cboLoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboLoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboLocActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboLoc, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
            .addComponent(jScrollPane1)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(cboLoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("Sửa");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnAn.setText("Ẩn");
        btnAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnActionPerformed(evt);
            }
        });

        btnMoi.setText("Mới");
        btnMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiActionPerformed(evt);
            }
        });

        jButton5.setText("Danh sách thông tin ẩn");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(btnThem)
                .addGap(45, 45, 45)
                .addComponent(btnSua)
                .addGap(48, 48, 48)
                .addComponent(btnAn)
                .addGap(46, 46, 46)
                .addComponent(btnMoi, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(96, 96, 96)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnAn, btnMoi, btnSua, btnThem});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnAn)
                    .addComponent(btnMoi)
                    .addComponent(jButton5))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Thông tin sản phẩm", jPanel2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 825, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 32, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 31, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleName("pnlSanPham");
    }// </editor-fold>//GEN-END:initComponents

    private void txtGiaBanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGiaBanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGiaBanActionPerformed

    private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseClicked
        int index = tblSanPham.getSelectedRow();
        fillFormSanPham(index);
    }//GEN-LAST:event_tblSanPhamMouseClicked

    private void btnMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiActionPerformed
        resetFormSP();
    }//GEN-LAST:event_btnMoiActionPerformed
    public boolean checkTrung() {
        StringBuilder err = new StringBuilder();
        for (QLChiTietSanPham q : ctsps.selectAll()) {
            if (txtMa.getText().equalsIgnoreCase(q.getMa())) {
                err.append("Không được trùng mã");
            }
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }

    }
    ImageIcon img;
    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        int i = 0;
        for (QLSanPham x : sps.selectAll()) {
            if (txtTen.getText().equalsIgnoreCase(x.getTen())) {
                i += 1;
            }
        }
        if (i == 0) {
            if (checkTrung()) {
                sps.insert(getSP());
                if ((ctsps.insert(getForm())) == 1) {
                    JOptionPane.showMessageDialog(this, "Thành công");
                    viewSanPham(ctsps.selectByWhere(""));
                    try {
                        String str = txtMa.getText().trim();
                        String path = System.getProperty("user.dir") + "/QR/";
                        String charset = "UTF-8";
                        Map<EncodeHintType, ErrorCorrectionLevel> hashMap = new HashMap<>();
                        hashMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
                        generateQRcode(str, path + str + ".png", charset, hashMap, 200, 200);
                        img = new ImageIcon(str + ".png");
                    } catch (Exception e) {
                    }
                }
            }
        } else {
            if (checkTrung()) {
                if ((ctsps.insert(getForm())) == 1) {
                    JOptionPane.showMessageDialog(this, "Thành công");
                    viewSanPham(ctsps.selectByWhere(""));
                    try {
                        String str = txtMa.getText().trim();
                        String path = System.getProperty("user.dir") + "/QR/";
                        String charset = "UTF-8";
                        Map<EncodeHintType, ErrorCorrectionLevel> hashMap = new HashMap<>();
                        hashMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
                        generateQRcode(str, path + str + ".png", charset, hashMap, 200, 200);
                        img = new ImageIcon(str + ".png");
                    } catch (Exception e) {
                    }
                }
            }

        }

    }//GEN-LAST:event_btnThemActionPerformed

    private void btnAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnActionPerformed
        // TODO add your handling code here:
        int index = tblSanPham.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng muốn ấn", "Ẩn không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String ma = tblSanPham.getValueAt(index, 0).toString();
        if (JOptionPane.showConfirmDialog(this, "Xác nhận ẩn sản phẩm", "Ẩn sản phẩm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, ctsps.setAn(0, ma) == 0 ? "Ẩn không thành công" : "Ẩn thành công");
            resetFormSP();
            viewSanPham(ctsps.selectByWhere(""));
            viewAn();
        }

    }//GEN-LAST:event_btnAnActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        // TODO add your handling code here:
        int row = tblSanPham.getSelectedRow();
        String ma = tblSanPham.getValueAt(row, 1).toString();
        int result = sps.update(getSP(), ma);
        if ((ctsps.update(getForm())) > 0) {
            JOptionPane.showMessageDialog(this, "Thành công");
        } else {
            JOptionPane.showMessageDialog(this, "Thất bại");
        }
        viewSanPham(ctsps.selectByWhere(""));
    }//GEN-LAST:event_btnSuaActionPerformed

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        viewSanPham(ctsps.selectByWhere(txtTimKiem.getText()));
    }//GEN-LAST:event_txtTimKiemKeyReleased

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        viewAn();
        diaTableAn.setLocationRelativeTo(null);
        diaTableAn.setVisible(true);

    }//GEN-LAST:event_jButton5ActionPerformed

    private void btnHienThiLaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHienThiLaiActionPerformed
        // TODO add your handling code here:
        int index = tblSanPhamAn.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng muốn ấn", "Ẩn không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String ma = tblSanPhamAn.getValueAt(index, 0).toString();
        if (JOptionPane.showConfirmDialog(this, "Xác nhận hiển thị sản phẩm", "Hiển thị sản phẩm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, ctsps.setAn(1, ma) == 0 ? "Hiển thị không thành công" : "Hiển thị thành công");
            resetFormSP();
            viewSanPham(ctsps.selectByWhere(""));
            viewAn();
        }
    }//GEN-LAST:event_btnHienThiLaiActionPerformed

    private void cboLocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboLocActionPerformed
        // TODO add your handling code here:
        if (cboLoc.getSelectedItem() == null) {
            viewSanPham(ctsps.selectByWhere(""));
        } else if (cboLoc.getSelectedIndex() == 0) {
            viewSanPham(ctsps.selectByWhere(""));
        } else {
            QLDongSP idDong = (QLDongSP) cboLoc.getSelectedItem();
            viewSanPham(ctsps.loc(idDong.getId()));
        }
    }//GEN-LAST:event_cboLocActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        diaChatLieu.setVisible(true);
        diaChatLieu.setLocationRelativeTo(this);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        diaKichCo.setVisible(true);
        diaKichCo.setLocationRelativeTo(this);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        diaMauSac.setVisible(true);
        diaMauSac.setLocationRelativeTo(this);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        diaNSX.setVisible(true);
        diaNSX.setLocationRelativeTo(this);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed
    public QLDongSP getInputDongSp() {
        QLDongSP q = new QLDongSP();
        q.setMa(txtMaLsp.getText());
        q.setTen(txtTenLsp.getText());
        return q;
    }

    public void fillDongSp(int i) {
        QLDongSP q = dsps.selectAll().get(i);
        txtMaLsp.setText(q.getMa());
        txtTenLsp.setText(q.getTen());
    }

    public boolean checkTrungLsp() {
        StringBuilder err = new StringBuilder();
        for (QLDongSP q : dsps.selectAll()) {
            if (txtMaLsp.getText().equalsIgnoreCase(q.getMa())) {
                err.append("Không được trùng mã");
            }
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        QLDongSP q = getInputDongSp();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn thêm ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checklsp() && checkTrungLsp() && dsps.insert(q) != 0) {
                JOptionPane.showMessageDialog(null, "Thêm thành công");
                viewLoaiSP();
                viewCombobox();
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed
    public QLKichCo getInputKichCo() {
        QLKichCo q = new QLKichCo();
        q.setMa(txtmaKc.getText());
        q.setTen(txtTenKc.getText());
        return q;
    }

    public void fillKichCo(int i) {
        QLKichCo q = kcs.selectAll().get(i);
        txtmaKc.setText(q.getMa());
        txtTenKc.setText(q.getTen());
    }

    public boolean checkTrungKc() {
        StringBuilder err = new StringBuilder();
        for (QLKichCo q : kcs.selectAll()) {
            if (txtmaKc.getText().equalsIgnoreCase(q.getMa())) {
                err.append("Không được trùng mã");
            }
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }
    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        QLKichCo q = getInputKichCo();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn thêm ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkKc() && checkTrungKc() && kcs.insert(q) != 0) {
                JOptionPane.showMessageDialog(null, "Thêm thành công");
                viewKichCo();
                viewCombobox();
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        QLKichCo q = getInputKichCo();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn thêm ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkKc() && kcs.update(q) != 0) {
                JOptionPane.showMessageDialog(null, "Sửa thành công");
                viewKichCo();
                viewCombobox();
            } else {
                JOptionPane.showMessageDialog(null, "Bạn không thể sửa mã ");
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        txtmaKc.setText("");
        txtTenKc.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        QLDongSP q = getInputDongSp();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn Sửa ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checklsp() && dsps.update(q) != 0) {
                JOptionPane.showMessageDialog(null, "Sửa thành công");
                viewLoaiSP();
                viewCombobox();
            } else {
                JOptionPane.showMessageDialog(null, "Bạn không thể sửa mã ");
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        txtMaLsp.setText("");
        txtTenLsp.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12ActionPerformed

    private void tbLoaiSpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbLoaiSpMouseClicked
        int i = tbLoaiSp.getSelectedRow();
        fillDongSp(i);
        // TODO add your handling code here:
    }//GEN-LAST:event_tbLoaiSpMouseClicked
    public QLChatLieu getInputChatLieu() {
        QLChatLieu q = new QLChatLieu();
        q.setMa(txtMaCl.getText());
        q.setTen(txtTenCl.getText());
        return q;
    }

    public void fillChatLieu(int i) {
        QLChatLieu q = cls.selectAll().get(i);
        txtMaCl.setText(q.getMa());
        txtTenCl.setText(q.getTen());
    }

    public boolean checkTrungCl() {
        StringBuilder err = new StringBuilder();
        for (QLChatLieu q : cls.selectAll()) {
            if (txtMaCl.getText().equalsIgnoreCase(q.getMa())) {
                err.append("Không được trùng mã");
            }
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }
    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        QLChatLieu q = getInputChatLieu();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn thêm ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkCl() && checkTrungCl() && cls.insert(q) != 0) {
                JOptionPane.showMessageDialog(null, "Thêm thành công");
                viewChatLieu();
                viewCombobox();
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        QLChatLieu q = getInputChatLieu();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn sửa ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkCl() && cls.update(q) != 0) {
                JOptionPane.showMessageDialog(null, "Sửa thành công");
                viewChatLieu();
                viewCombobox();
            } else {
                JOptionPane.showMessageDialog(null, "Bạn không thể sửa mã");
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        txtMaCl.setText("");
        txtTenCl.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18ActionPerformed
    public QLMauSac getInputMauSac() {
        QLMauSac q = new QLMauSac();
        q.setMa(txtMaMs.getText());
        q.setTen(txtTenMs.getText());
        return q;
    }

    public void fillMauSac(int i) {
        QLMauSac q = mss.selectAll().get(i);
        txtMaMs.setText(q.getMa());
        txtTenMs.setText(q.getTen());
    }

    public boolean checkTrungMs() {
        StringBuilder err = new StringBuilder();
        for (QLMauSac q : mss.selectAll()) {
            if (txtMaMs.getText().equalsIgnoreCase(q.getMa())) {
                err.append("Không được trùng mã");
            }
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }
    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        QLMauSac q = getInputMauSac();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn thêm ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkMs() && checkTrungMs() && mss.insert(q) != 0) {
                JOptionPane.showMessageDialog(null, "Thêm thành công");
                viewMauSac();
                viewCombobox();
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        QLMauSac q = getInputMauSac();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn sửa ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkMs() && mss.update(q) != 0) {
                JOptionPane.showMessageDialog(null, "Sửa thành công");
                viewMauSac();
                viewCombobox();
            } else {
                JOptionPane.showMessageDialog(null, "Bạn không thể sửa mã");
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        txtMaMs.setText("");
        txtTenMs.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21ActionPerformed
    public QLNSX getInputNhaSanXuat() {
        QLNSX q = new QLNSX();
        q.setMa(txtMaNsx.getText());
        q.setTen(txtTenNsx.getText());
        return q;
    }

    public void fillNhaSanXuat(int i) {
        QLNSX q = nsxs.selectAll().get(i);
        txtMaNsx.setText(q.getMa());
        txtTenNsx.setText(q.getTen());
    }

    public boolean checkTrungNsx() {
        StringBuilder err = new StringBuilder();
        for (QLNSX q : nsxs.selectAll()) {
            if (txtMaNsx.getText().equalsIgnoreCase(q.getMa())) {
                err.append("Không được trùng mã");
            }
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }
    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        QLNSX q = getInputNhaSanXuat();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn thêm ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkNsx() && checkTrungNsx() && nsxs.insert(q) != 0) {
                JOptionPane.showMessageDialog(null, "Thêm thành công");
                viewNhaSanXuat();
                viewCombobox();
            }
        }
// TODO add your handling code here:
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        QLNSX q = getInputNhaSanXuat();
        if (JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn sửa ?",
                "Bạn có chắc ?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (checkNsx() && nsxs.update(q) != 0) {
                JOptionPane.showMessageDialog(null, "Sửa thành công");
                viewNhaSanXuat();
                viewCombobox();
            } else {
                JOptionPane.showMessageDialog(null, "Bạn không thể sửa mã");
            }
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        txtMaNsx.setText("");
        txtTenNsx.setText("");
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton24ActionPerformed

    private void diaKichCoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_diaKichCoMouseClicked

        // TODO add your handling code here:
    }//GEN-LAST:event_diaKichCoMouseClicked

    private void diaChatLieuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_diaChatLieuMouseClicked

        // TODO add your handling code here:
    }//GEN-LAST:event_diaChatLieuMouseClicked

    private void diaMauSacMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_diaMauSacMouseClicked

        // TODO add your handling code here:
    }//GEN-LAST:event_diaMauSacMouseClicked

    private void diaNSXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_diaNSXMouseClicked

        // TODO add your handling code here:
    }//GEN-LAST:event_diaNSXMouseClicked

    private void tbKichCoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbKichCoMouseClicked
        int i = tbKichCo.getSelectedRow();
        fillKichCo(i);
        // TODO add your handling code here:
    }//GEN-LAST:event_tbKichCoMouseClicked

    private void tbChatLieuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbChatLieuMouseClicked
        int i = tbChatLieu.getSelectedRow();
        fillChatLieu(i);
        // TODO add your handling code here:
    }//GEN-LAST:event_tbChatLieuMouseClicked

    private void tbMauSacMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbMauSacMouseClicked
        int i = tbMauSac.getSelectedRow();
        fillMauSac(i);
        // TODO add your handling code here:
    }//GEN-LAST:event_tbMauSacMouseClicked

    private void tbNsxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbNsxMouseClicked
        int i = tbNsx.getSelectedRow();
        fillNhaSanXuat(i);
        // TODO add your handling code here:
    }//GEN-LAST:event_tbNsxMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        diaLoaiSanPham.setVisible(true);
        diaLoaiSanPham.setLocationRelativeTo(this);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    public void viewAn() {
        dtmAn = (DefaultTableModel) tblSanPhamAn.getModel();
        dtmAn.setRowCount(0);
        for (QLChiTietSanPham x : ctsps.selectAllAn()) {
            dtmAn.addRow(x.getObject());
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAn;
    private javax.swing.JButton btnHienThiLai;
    private javax.swing.JButton btnMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboChatLieu;
    private javax.swing.JComboBox<String> cboKichCo;
    private javax.swing.JComboBox<String> cboLoaiSanPham;
    private javax.swing.JComboBox<String> cboLoc;
    private javax.swing.JComboBox<String> cboMauSac;
    private javax.swing.JComboBox<String> cboNSX;
    private javax.swing.JDialog diaChatLieu;
    private javax.swing.JDialog diaKichCo;
    private javax.swing.JDialog diaLoaiSanPham;
    private javax.swing.JDialog diaMauSac;
    private javax.swing.JDialog diaNSX;
    private javax.swing.JDialog diaTableAn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tbChatLieu;
    private javax.swing.JTable tbKichCo;
    private javax.swing.JTable tbLoaiSp;
    private javax.swing.JTable tbMauSac;
    private javax.swing.JTable tbNsx;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTable tblSanPhamAn;
    private javax.swing.JTextField txtGiaBan;
    private javax.swing.JTextField txtGiaNhap;
    private javax.swing.JTextField txtMa;
    private javax.swing.JTextField txtMaCl;
    private javax.swing.JTextField txtMaLsp;
    private javax.swing.JTextField txtMaMs;
    private javax.swing.JTextField txtMaNsx;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTen;
    private javax.swing.JTextField txtTenCl;
    private javax.swing.JTextField txtTenKc;
    private javax.swing.JTextField txtTenLsp;
    private javax.swing.JTextField txtTenMs;
    private javax.swing.JTextField txtTenNsx;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JTextField txtmaKc;
    // End of variables declaration//GEN-END:variables
}
