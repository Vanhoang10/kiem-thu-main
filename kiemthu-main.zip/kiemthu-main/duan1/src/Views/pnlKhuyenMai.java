/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Views;

import Services.Iplm.ChiTietKhuyenMaiService;
import Services.Iplm.ChiTietSanPhamService;
import Services.Iplm.DongSPService;
import Services.Iplm.KhuyenMaiService;
import ViewModel.QLChiTietKhuyenMai;
import ViewModel.QLChiTietSanPham;
import ViewModel.QLDongSP;
import ViewModel.QLKhuyenMai;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author duy09
 */
public final class pnlKhuyenMai extends javax.swing.JPanel {

    private KhuyenMaiService kms = new KhuyenMaiService();
    private ChiTietSanPhamService cts = new ChiTietSanPhamService();
    private DongSPService dsps = new DongSPService();
    private ChiTietKhuyenMaiService ctkms = new ChiTietKhuyenMaiService();

    private DefaultTableModel dtmSP, dtmKm;
    private DefaultComboBoxModel dcbLocDSP, dcbLocTT;

    public pnlKhuyenMai() {
        initComponents();
        viewSP(cts.selectByWhere(""));
        viewKM(kms.selectByWhere(""));
        setComBoboxs();
        txtThoiGianBatDau.setDate(new Date());
        txtThoiGianKetThuc.setDate(new Date());
//        lamMoi();
    }

    public void setComBoboxs() {
        dcbLocDSP = (DefaultComboBoxModel) cboLocDongSP.getModel();
        dcbLocDSP.removeAllElements();
        dcbLocDSP.addElement("-Dòng sản phẩm-");
        for (QLDongSP x : dsps.selectAll()) {
            dcbLocDSP.addElement(x);
        }

    }

    public QLKhuyenMai getForm() {
        int trangThai = rdoNgungHoatDong.isSelected() ? 0 : (txtThoiGianKetThuc.getDate().before(new Date()) ? 0 : 1);
        return new QLKhuyenMai(txtTenChuongTrinh.getText(),
                Double.parseDouble(txtMucGiaGiam.getText()),
                txtThoiGianBatDau.getDate(), txtThoiGianKetThuc.getDate(), trangThai);
    }

    public void fillData(int index) {
        QLKhuyenMai km = kms.selectByWhere("").get(index);
        txtTenChuongTrinh.setText(km.getTen());
        txtMucGiaGiam.setText(km.getMucGiaGiam() + "");
        txtThoiGianKetThuc.setDate(km.getThoiGianKetThuc());
        txtThoiGianBatDau.setDate(km.getThoiGianBatDau());
        String tenCT = tblKhuyenMai.getValueAt(index, 0).toString();
        String id = kms.selectIDOne(tenCT);
        int length = tblSanPham.getRowCount();
        List<QLChiTietKhuyenMai> listCT = ctkms.selectByKM(id);
        for (int i = 0; i < length; i++) {
            String masp = tblSanPham.getValueAt(i, 0).toString();
            for (QLChiTietKhuyenMai x : listCT) {
                if (masp.equalsIgnoreCase(x.getChiTietSanPham().getMa())
                        && x.isTrangThai()) {
                    tblSanPham.setValueAt(true, i, 7);
                }
            }
        }

    }

    public void viewKM(List<QLKhuyenMai> list) {
        dtmKm = (DefaultTableModel) tblKhuyenMai.getModel();
        dtmKm.setRowCount(0);
        for (QLKhuyenMai x : list) {
            dtmKm.addRow(x.getObject());
        }
    }

    public void viewCTKM(List<QLChiTietKhuyenMai> list) {
        dtmSP = (DefaultTableModel) tblSanPham.getModel();
        dtmSP.setRowCount(0);
        for (QLChiTietKhuyenMai x : list) {
            dtmSP.addRow(x.getObject());
        }
    }

    public void viewSP(List<QLChiTietSanPham> list) {
        dtmSP = (DefaultTableModel) tblSanPham.getModel();
        dtmSP.setRowCount(0);
        for (QLChiTietSanPham x : list) {
            dtmSP.addRow(x.getOBKM());
        }
    }

    public void lamMoi() {
        for (int i = 0; i < tblKhuyenMai.getRowCount(); i++) {
            String tenCT = tblKhuyenMai.getValueAt(i, 0).toString();
            QLKhuyenMai km = kms.selectByTen(tenCT);
            BigDecimal giaDaGiam = new BigDecimal(Double.parseDouble(tblKhuyenMai.getValueAt(i, 1).toString()) / 100);
            for (int j = 0; j < tblKhuyenMai.getRowCount(); j++) {
                String masp = tblSanPham.getValueAt(j, 0).toString();
                QLChiTietSanPham ct = cts.selectByMa(masp);
                if (km.getTrangthai() == 2) {
                    cts.updateKM(new QLChiTietSanPham(masp, ct.getGiaBan().multiply(giaDaGiam)));
                } else {
                    cts.updateKM(new QLChiTietSanPham(masp, ct.getGiaBan()));
                }
            }
        }
    }

    public void duyetKhuyenMai() {
        String tenCT = txtTenChuongTrinh.getText();
        kms.insert(getForm());
        QLKhuyenMai km = kms.selectByTen(tenCT);
        BigDecimal giaDaGiam = new BigDecimal(Double.parseDouble(txtMucGiaGiam.getText()) / 100);
        for (int i = 0; i < tblSanPham.getRowCount(); i++) {
            Boolean x = (Boolean) tblSanPham.getValueAt(i, 7);
            String masp = tblSanPham.getValueAt(i, 0).toString();
            QLChiTietSanPham ct = cts.selectByMa(masp);
            if (x) {
                ctkms.insert(new QLChiTietKhuyenMai(km, cts.selectByMa(masp),
                        cts.selectByMa(masp).getGiaBan().subtract(cts.selectByMa(masp).getGiaBan().multiply(giaDaGiam)), x));

                if (km.getTrangthai() != 0) {
                    cts.updateKM(new QLChiTietSanPham(masp, cts.selectByMa(masp).getGiaBan().subtract(ct.getGiaBan().multiply(giaDaGiam))));
                } else {
                    ctkms.updateSP(new QLChiTietKhuyenMai(km, cts.selectByMa(masp), x));
                    cts.updateKM(new QLChiTietSanPham(masp, ct.getGiaBan()));
                }
            } else {
                ctkms.insert(new QLChiTietKhuyenMai(km, cts.selectByMa(masp), new BigDecimal(0), x));
                cts.updateKM(new QLChiTietSanPham(masp, ct.getGiaBan()));
            }
        }
    }

    public void updateKhuyenMai() {
        int row = tblKhuyenMai.getSelectedRow();
        String tenCT = tblKhuyenMai.getValueAt(row, 0).toString();
        kms.update(getForm(), tenCT);
        QLKhuyenMai km = kms.selectByTen(tenCT);
        BigDecimal giaDaGiam = new BigDecimal(Double.parseDouble(txtMucGiaGiam.getText()) / 100);
        for (int i = 0; i < tblSanPham.getRowCount(); i++) {
            Boolean x = (Boolean) tblSanPham.getValueAt(i, 7);
            String masp = tblSanPham.getValueAt(i, 0).toString();
            QLChiTietSanPham ct = cts.selectByMa(masp);
            if (x) {
                ctkms.updateSP(new QLChiTietKhuyenMai(km, cts.selectByMa(masp), x));
                if (km.getTrangthai() != 0) {
                    cts.updateKM(new QLChiTietSanPham(masp, ct.getGiaBan().subtract(ct.getGiaBan().multiply(giaDaGiam))));
                } else {
                    ctkms.updateSP(new QLChiTietKhuyenMai(km, cts.selectByMa(masp), x));
                    cts.updateKM(new QLChiTietSanPham(masp, ct.getGiaBan()));
                }
            } else {
                ctkms.updateSP(new QLChiTietKhuyenMai(km, cts.selectByMa(masp), x));
                cts.updateKM(new QLChiTietSanPham(masp, ct.getGiaBan()));
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        cboLocDongSP = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtTenChuongTrinh = new javax.swing.JTextField();
        txtMucGiaGiam = new javax.swing.JTextField();
        txtThoiGianBatDau = new com.toedter.calendar.JDateChooser();
        txtThoiGianKetThuc = new com.toedter.calendar.JDateChooser();
        btnThem = new javax.swing.JButton();
        btnCapNhat = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        rdoDangHoatDong = new javax.swing.JRadioButton();
        rdoNgungHoatDong = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblKhuyenMai = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jTextField3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(222, 231, 227));
        setMaximumSize(new java.awt.Dimension(825, 520));
        setMinimumSize(new java.awt.Dimension(825, 520));

        jPanel1.setBackground(new java.awt.Color(222, 231, 227));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Danh sách sản phẩm", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        tblSanPham.setBackground(new java.awt.Color(222, 231, 227));
        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã SP", "Tên SP", "Kích thước", "Màu sắc", "Chất liệu", "NSX", "Đơn giá", "KM"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblSanPham);

        jLabel1.setText("Lọc");

        cboLocDongSP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboLocDongSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboLocDongSPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 530, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(37, 37, 37)
                        .addComponent(cboLocDongSP, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cboLocDongSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 189, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(222, 231, 227));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hình thức khuyến mại", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jLabel5.setText("Tên chương trình :");

        jLabel6.setText("Mức giảm giá (%) :");

        jLabel7.setText("Thời gian bắt đầu");

        jLabel8.setText("Ngày kết thúc :");

        btnThem.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnThem.setText("Lưu");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnCapNhat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCapNhat.setText("Cập nhật ");
        btnCapNhat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCapNhatActionPerformed(evt);
            }
        });

        btnLamMoi.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnLamMoi.setText("Làm mới");
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        buttonGroup2.add(rdoDangHoatDong);
        rdoDangHoatDong.setSelected(true);
        rdoDangHoatDong.setText("Đang hoạt động");

        buttonGroup2.add(rdoNgungHoatDong);
        rdoNgungHoatDong.setText("Ngưng hoạt động");
        rdoNgungHoatDong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoNgungHoatDongActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(rdoDangHoatDong))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtThoiGianBatDau, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                                .addComponent(txtThoiGianKetThuc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtMucGiaGiam)
                                .addComponent(txtTenChuongTrinh))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(rdoNgungHoatDong)
                                .addContainerGap())))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnThem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnCapNhat, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLamMoi, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnCapNhat, btnLamMoi});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(txtTenChuongTrinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(txtMucGiaGiam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(25, 25, 25)
                                .addComponent(jLabel7))
                            .addComponent(txtThoiGianBatDau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addComponent(jLabel8))
                    .addComponent(txtThoiGianKetThuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdoDangHoatDong)
                    .addComponent(rdoNgungHoatDong))
                .addGap(31, 31, 31)
                .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnLamMoi, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                    .addComponent(btnCapNhat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnCapNhat, btnLamMoi, btnThem});

        jPanel3.setBackground(new java.awt.Color(222, 231, 227));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Danh sách khuyến mại", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        tblKhuyenMai.setBackground(new java.awt.Color(222, 231, 227));
        tblKhuyenMai.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Tên chương trình", "Mức giảm giá", "Ngày bắt đầu", "Ngày kết thúc", "Trạng thái"
            }
        ));
        tblKhuyenMai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblKhuyenMaiMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblKhuyenMai);

        jPanel4.setBackground(new java.awt.Color(222, 231, 227));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tìm kiếm khuyến mại", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jButton1.setText("Tìm kiếm");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(0, 8, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 38, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleName("pnlKhuyenMai");
    }// </editor-fold>//GEN-END:initComponents

    private void cboLocDongSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboLocDongSPActionPerformed
        if (cboLocDongSP.getSelectedItem() == null) {
            viewSP(cts.selectByWhere(""));
        } else if (cboLocDongSP.getSelectedIndex() == 0) {
            viewSP(cts.selectByWhere(""));
        } else {
            QLDongSP idDong = (QLDongSP) cboLocDongSP.getSelectedItem();
            viewSP(cts.loc(idDong.getId()));
        }
    }//GEN-LAST:event_cboLocDongSPActionPerformed

    private void tblKhuyenMaiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblKhuyenMaiMouseClicked
        // TODO add your handling code here:

        int index = tblKhuyenMai.getSelectedRow();
        fillData(index);

    }//GEN-LAST:event_tblKhuyenMaiMouseClicked

    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiActionPerformed
        // TODO add your handling code here:
        reset();
    }//GEN-LAST:event_btnLamMoiActionPerformed
    public void reset() {
        viewKM(kms.selectByWhere(""));
        viewSP(cts.selectByWhere(""));
        txtMucGiaGiam.setText("");
        txtTenChuongTrinh.setText("");
        txtThoiGianBatDau.setDate(new Date());
        txtThoiGianKetThuc.setDate(new Date());
    }
    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        if (check()) {
            duyetKhuyenMai();
            viewSP(cts.selectWithKM(""));
            viewKM(kms.selectByWhere(""));
            reset();
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnCapNhatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCapNhatActionPerformed
        // TODO add your handling code here:
        if (check()) {
            updateKhuyenMai();
            reset();
        }
    }//GEN-LAST:event_btnCapNhatActionPerformed

    private void rdoNgungHoatDongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoNgungHoatDongActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdoNgungHoatDongActionPerformed
    public boolean check() {
        StringBuilder err = new StringBuilder();
        int j = 0;
        for (int i = 0; i < tblSanPham.getRowCount(); i++) {
            Boolean x = (Boolean) tblSanPham.getValueAt(i, 7);
            if (x) {
                j++;
            }
        }
        if (j == 0) {
            err.append("Vui lòng chọn sản phẩm");
        } else if (txtTenChuongTrinh.getText().trim().isEmpty()) {
            err.append("Tên chương trình không được để trống");
        } else if (txtMucGiaGiam.getText().trim().isEmpty()) {
            err.append("Mức giảm không được để trống!");
        } else if (txtThoiGianBatDau.getDate().after(txtThoiGianKetThuc.getDate()) || txtThoiGianBatDau.getDate().equals(txtThoiGianKetThuc.getDate())) {
            err.append("Thời gian bắt đầu không được lớn hơn hoặc thời gian kết thúc");
        }

        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công!", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCapNhat;
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnThem;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cboLocDongSP;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JRadioButton rdoDangHoatDong;
    private javax.swing.JRadioButton rdoNgungHoatDong;
    private javax.swing.JTable tblKhuyenMai;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTextField txtMucGiaGiam;
    private javax.swing.JTextField txtTenChuongTrinh;
    private com.toedter.calendar.JDateChooser txtThoiGianBatDau;
    private com.toedter.calendar.JDateChooser txtThoiGianKetThuc;
    // End of variables declaration//GEN-END:variables
}
