package Views;

import DomainModels.ChiTietSanPham;
import DomainModels.DongSP;
import DomainModels.HoaDon;
import DomainModels.LoaiKhachHang;
import Services.Iplm.ChatLieuService;
import Services.Iplm.ChiTietKhuyenMaiService;
import Services.Iplm.ChiTietSanPhamService;
import Services.Iplm.DongSPService;
import Services.Iplm.HinhThucThanhToanService;
import Services.Iplm.HoaDonCTService;
import Services.Iplm.HoaDonService;
import Services.Iplm.KhachHangService;
import Services.Iplm.KichCoService;
import Services.Iplm.LoaiKhachHangService;
import Services.Iplm.MauSacService;
import Services.Iplm.NSXService;
import Services.Iplm.NhanVienService;
import Services.Iplm.SanPhamService;
import ViewModel.QLChiTietKhuyenMai;
import ViewModel.QLChiTietSanPham;
import ViewModel.QLDongSP;
import ViewModel.QLHinhThucThanhToan;
import ViewModel.QLHoaDon;
import ViewModel.QLHoaDonCT;
import ViewModel.QLKhachHang;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import java.awt.CardLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author duy09 //
 */
public class Index extends javax.swing.JFrame implements Runnable, ThreadFactory {

    //qr
    CardLayout card;
    private static final long serialVersionUID = 6441489157408381878L;
    private Executor executor = Executors.newSingleThreadExecutor(this);
    private WebcamPanel panel = null;
    private Webcam webcam = null;
    String qr = "";

    // default
    private DefaultTableModel dtm, dtmHD, dtmGH, dtmKH;
    private DefaultComboBoxModel dcbLoc, dcbTTTQ, dcbTTDH;

    // service    
    private ChiTietKhuyenMaiService kms = new ChiTietKhuyenMaiService();

    private HoaDonService hds = new HoaDonService();
    private LoaiKhachHangService lkhs = new LoaiKhachHangService();
    private KhachHangService khs = new KhachHangService();
    private NhanVienService nvs = new NhanVienService();
    private HoaDonCTService hdcts = new HoaDonCTService();
    private DongSPService dsps = new DongSPService();
    private ChatLieuService cls = new ChatLieuService();
    private NSXService nsxs = new NSXService();
    private SanPhamService sps = new SanPhamService();
    private KichCoService kcs = new KichCoService();
    private MauSacService mss = new MauSacService();
    private final ChiTietSanPhamService ctsps = new ChiTietSanPhamService();
    private HinhThucThanhToanService httts = new HinhThucThanhToanService();

    public Index(String maNV) {
        initComponents();
        setLocationRelativeTo(null);
        card = (CardLayout) pnlCards.getLayout();
        card.show(pnlCards, "pnlBanHang");
        try {
            initWebcam();
        } catch (Exception e) {
        }
        txtNguoiDung.setText(maNV);
        view(ctsps.selectByWhere(""));
        viewHD(hds.selectAll());
        viewCombobox();
    }

    public void reset() {
        view(ctsps.selectByWhere(""));
        viewHD(hds.selectAll());
        txtTenKHTaiQuay.setText("");
        txtSDTTQ.setText("");
        txtTenKHDH.setText("");
        txtSDTDH.setText("");
        txtTongTien.setText("0");
        txtTongTienDH.setText("0");
        txtDacQuyenTQ.setText("0");
        txtDiaChiDH.setText("");
        txtDacQuyenDH.setText("0");
        txtCTTDH.setText("0");
        txtCanThanhToanTQ.setText("0");
        txtTienThua.setText("0");
        txtTienThuaDH.setText("0");
        txtTKDDH.setText("0");
        txtTienKhachDuaTQ.setText("0");
        cboTTDatHang.setSelectedIndex(0);
        cboTTTaiQuay.setSelectedIndex(0);
        dtmGH = (DefaultTableModel) tblGioHang.getModel();
        dtmGH.setRowCount(0);
    }

    public void viewCombobox() {
        dcbLoc = (DefaultComboBoxModel) cboLoc.getModel();
        dcbTTTQ = (DefaultComboBoxModel) cboTTTaiQuay.getModel();
        dcbTTDH = (DefaultComboBoxModel) cboTTDatHang.getModel();

        dcbTTDH.removeAllElements();
        dcbTTTQ.removeAllElements();
        dcbLoc.removeAllElements();
        dcbLoc.addElement("-Dòng sản phẩm-");
        for (QLDongSP x : dsps.selectAll()) {
            dcbLoc.addElement(x);
        }
        for (QLHinhThucThanhToan x : httts.selectAll()) {
            dcbTTDH.addElement(x);
            dcbTTTQ.addElement(x);
        }

    }

    public void viewGH(List<QLHoaDonCT> list) {
        dtmGH = (DefaultTableModel) tblGioHang.getModel();
        dtmGH.setRowCount(0);
        for (QLHoaDonCT x : list) {
            dtmGH.addRow(x.getObject());
        }
    }

    public void viewHD(List<QLHoaDon> list) {
        dtmHD = (DefaultTableModel) tblHoaDon.getModel();
        dtmHD.setRowCount(0);
        for (QLHoaDon x : list) {
            dtmHD.addRow(x.getObjectNew());
        }
    }

    public void view(List<QLChiTietSanPham> list) {
        dtm = (DefaultTableModel) tblDanhSachSP.getModel();
        dtm.setRowCount(0);
        for (QLChiTietSanPham x : list) {
            dtm.addRow(x.getBanHang());
        }
    }

    public void viewSP(List<QLChiTietKhuyenMai> list) {
        dtm = (DefaultTableModel) tblDanhSachSP.getModel();
        dtm.setRowCount(0);
        for (QLChiTietKhuyenMai x : list) {
            dtm.addRow(x.getSP());
        }
    }

    private void initWebcam() {
        Dimension size = WebcamResolution.QVGA.getSize();
        webcam = Webcam.getWebcams().get(0); //0 is default webcam
        webcam.setViewSize(size);

        panel = new WebcamPanel(webcam);
        panel.setPreferredSize(size);
        panel.setFPSDisplayed(true);
        pnlWebCam.add(panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 140));
        executor.execute(this);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        diaKH = new javax.swing.JDialog();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblKhachHang = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        txtTimKH = new javax.swing.JTextField();
        btnChonKh = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        pnlCards = new javax.swing.JPanel();
        pnlBanHang = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblGioHang = new javax.swing.JTable();
        btnLamMoiGH = new javax.swing.JButton();
        btnXoaSanPham = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblHoaDon = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblDanhSachSP = new javax.swing.JTable();
        jLabel26 = new javax.swing.JLabel();
        cboLoc = new javax.swing.JComboBox<>();
        jLabel27 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        pnlWebCam = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtTenKHTaiQuay = new javax.swing.JTextField();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel14 = new javax.swing.JLabel();
        txtSDTTQ = new javax.swing.JTextField();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jLabel15 = new javax.swing.JLabel();
        txtTongTien = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtDacQuyenTQ = new javax.swing.JLabel();
        txtCanThanhToanTQ = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        cboTTTaiQuay = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        jSeparator9 = new javax.swing.JSeparator();
        txtTienKhachDuaTQ = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        txtTienThua = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        btnThanhToan = new javax.swing.JButton();
        btnTaoHoaDon = new javax.swing.JButton();
        btnHuy = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtTenKHDH = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        txtSDTDH = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        txtTongTienDH = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtDacQuyenDH = new javax.swing.JLabel();
        txtCTTDH = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cboTTDatHang = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        txtTKDDH = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtTienThuaDH = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        jButton4 = new javax.swing.JButton();
        btnGiaoHang = new javax.swing.JButton();
        btnDaGiao = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        txtDiaChiDH = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jSeparator12 = new javax.swing.JSeparator();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnBanHang = new javax.swing.JButton();
        btnLichSu = new javax.swing.JButton();
        btnSanPham = new javax.swing.JButton();
        btnKhachHang = new javax.swing.JButton();
        btnKhuyenMai = new javax.swing.JButton();
        btnNhanVien = new javax.swing.JButton();
        btnThongKe = new javax.swing.JButton();
        btnDoiMatKhau = new javax.swing.JButton();
        btnDangXuat = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        txtNguoiDung = new javax.swing.JLabel();

        diaKH.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        diaKH.setMinimumSize(new java.awt.Dimension(600, 400));

        tblKhachHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Mã", "Họ và tên", "SDT"
            }
        ));
        jScrollPane4.setViewportView(tblKhachHang);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Tìm kiếm"));

        txtTimKH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKHActionPerformed(evt);
            }
        });
        txtTimKH.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKHKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addComponent(txtTimKH, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(txtTimKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 9, Short.MAX_VALUE))
        );

        btnChonKh.setText("Chọn");
        btnChonKh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChonKhActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout diaKHLayout = new javax.swing.GroupLayout(diaKH.getContentPane());
        diaKH.getContentPane().setLayout(diaKHLayout);
        diaKHLayout.setHorizontalGroup(
            diaKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4)
            .addGroup(diaKHLayout.createSequentialGroup()
                .addGap(170, 170, 170)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, diaKHLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnChonKh)
                .addGap(37, 37, 37))
        );
        diaKHLayout.setVerticalGroup(
            diaKHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, diaKHLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnChonKh)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(76, 193, 243));
        setMinimumSize(new java.awt.Dimension(1000, 600));
        setSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        jPanel1.setBackground(new java.awt.Color(153, 194, 211));
        jPanel1.setMaximumSize(new java.awt.Dimension(1000, 600));
        jPanel1.setMinimumSize(new java.awt.Dimension(1000, 600));
        jPanel1.setPreferredSize(new java.awt.Dimension(1000, 600));

        pnlCards.setBackground(new java.awt.Color(222, 231, 227));
        pnlCards.setMaximumSize(new java.awt.Dimension(825, 520));
        pnlCards.setMinimumSize(new java.awt.Dimension(825, 520));
        pnlCards.setPreferredSize(new java.awt.Dimension(825, 520));
        pnlCards.setLayout(new java.awt.CardLayout());

        pnlBanHang.setBackground(new java.awt.Color(222, 231, 227));
        pnlBanHang.setMaximumSize(new java.awt.Dimension(825, 520));
        pnlBanHang.setMinimumSize(new java.awt.Dimension(825, 520));

        jPanel3.setBackground(new java.awt.Color(222, 231, 227));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Giỏ hàng"));

        tblGioHang.setBackground(new java.awt.Color(222, 231, 227));
        tblGioHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã SP", "Tên sản phẩm", "Số lượng", "Đơn giá", "Đơn giá giảm", "Thành tiền"
            }
        ));
        tblGioHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblGioHangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblGioHang);

        btnLamMoiGH.setText("Làm mới giỏ hàng");
        btnLamMoiGH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiGHActionPerformed(evt);
            }
        });

        btnXoaSanPham.setText("Xoá sản phẩm");
        btnXoaSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaSanPhamActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnXoaSanPham)
                .addGap(51, 51, 51)
                .addComponent(btnLamMoiGH)
                .addGap(127, 127, 127))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiGH, btnXoaSanPham});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLamMoiGH)
                    .addComponent(btnXoaSanPham)))
        );

        jPanel4.setBackground(new java.awt.Color(222, 231, 227));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Hoá đơn"));

        tblHoaDon.setBackground(new java.awt.Color(222, 231, 227));
        tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã HĐ", "Tên NV", "Tên KH", "Trạng thái"
            }
        ));
        tblHoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHoaDonMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblHoaDon);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(222, 231, 227));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách sản phẩm"));

        tblDanhSachSP.setBackground(new java.awt.Color(222, 231, 227));
        tblDanhSachSP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã SP", "Tên", "Thể loại", "Chất liệu", "Kích thước", "Màu sắc", "Số lượng", "Đơn giá"
            }
        ));
        tblDanhSachSP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDanhSachSPMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblDanhSachSP);

        jLabel26.setText("Loại sản phẩm");

        cboLoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboLoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboLocActionPerformed(evt);
            }
        });

        jLabel27.setText("Tìm theo mã");

        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(jLabel26)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboLoc, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtTimKiem)))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(cboLoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlWebCam.setBackground(new java.awt.Color(222, 231, 227));
        pnlWebCam.setBorder(javax.swing.BorderFactory.createTitledBorder("Quét mã QR"));
        pnlWebCam.setToolTipText("");
        pnlWebCam.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(222, 231, 227));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Tạo hoá đơn"));

        jTabbedPane1.setBackground(new java.awt.Color(222, 231, 227));

        jPanel7.setBackground(new java.awt.Color(222, 231, 227));

        jLabel13.setText("Tên KH");

        txtTenKHTaiQuay.setBackground(new java.awt.Color(222, 231, 227));
        txtTenKHTaiQuay.setBorder(null);
        txtTenKHTaiQuay.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTenKHTaiQuayKeyReleased(evt);
            }
        });

        jLabel14.setText("SĐT");

        txtSDTTQ.setBackground(new java.awt.Color(222, 231, 227));
        txtSDTTQ.setBorder(null);
        txtSDTTQ.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSDTTQKeyReleased(evt);
            }
        });

        jLabel15.setText("Tổng tiền: ");

        txtTongTien.setText("0");

        jLabel17.setText("Đặc quyền KH (%):");

        txtDacQuyenTQ.setText("0");

        txtCanThanhToanTQ.setText("0");

        jLabel20.setText("Cần thanh toán:");

        jLabel21.setText("Hình thức");

        cboTTTaiQuay.setBackground(new java.awt.Color(222, 231, 227));
        cboTTTaiQuay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboTTTaiQuay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTTTaiQuayActionPerformed(evt);
            }
        });

        jLabel22.setText("Tiền khách đưa");

        txtTienKhachDuaTQ.setBackground(new java.awt.Color(222, 231, 227));
        txtTienKhachDuaTQ.setBorder(null);
        txtTienKhachDuaTQ.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTienKhachDuaTQKeyReleased(evt);
            }
        });

        jLabel23.setText("Tiền thừa");

        txtTienThua.setText("0");

        btnThanhToan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/mua.png"))); // NOI18N
        btnThanhToan.setText("Thanh toán");
        btnThanhToan.setEnabled(false);
        btnThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThanhToanActionPerformed(evt);
            }
        });

        btnTaoHoaDon.setText("Tạo HD");
        btnTaoHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTaoHoaDonActionPerformed(evt);
            }
        });

        btnHuy.setText("Huỷ");
        btnHuy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuyActionPerformed(evt);
            }
        });

        jButton1.setText("Chọn KH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtSDTTQ)
                                    .addComponent(jSeparator7)))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator6)
                                    .addComponent(txtTenKHTaiQuay)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel22)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator9)
                                    .addComponent(txtTienKhachDuaTQ)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel23)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTienThua, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jSeparator10)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addComponent(jLabel17)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtDacQuyenTQ, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addComponent(jLabel21)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cboTTTaiQuay, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup()
                                            .addComponent(jLabel20)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(txtCanThanhToanTQ, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup()
                                            .addComponent(jLabel15)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jButton1)
                                                .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(btnThanhToan, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup()
                                            .addComponent(btnTaoHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(btnHuy, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtTenKHTaiQuay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(txtSDTTQ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txtTongTien))
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txtDacQuyenTQ))
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txtCanThanhToanTQ))
                .addGap(9, 9, 9)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(cboTTTaiQuay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(txtTienKhachDuaTQ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(4, 4, 4)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(txtTienThua))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTaoHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnHuy, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(77, Short.MAX_VALUE))
        );

        jPanel7Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnHuy, btnTaoHoaDon});

        jTabbedPane1.addTab("Tại quầy", jPanel7);

        jPanel8.setBackground(new java.awt.Color(222, 231, 227));

        jLabel3.setText("Tên KH");

        txtTenKHDH.setBackground(new java.awt.Color(222, 231, 227));
        txtTenKHDH.setBorder(null);
        txtTenKHDH.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTenKHDHKeyReleased(evt);
            }
        });

        jLabel4.setText("SĐT");

        txtSDTDH.setBackground(new java.awt.Color(222, 231, 227));
        txtSDTDH.setBorder(null);
        txtSDTDH.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSDTDHKeyReleased(evt);
            }
        });

        jLabel5.setText("Tổng tiền: ");

        txtTongTienDH.setText("0");

        jLabel7.setText("Đặc quyền KH (%):");

        txtDacQuyenDH.setText("0");

        txtCTTDH.setText("0");

        jLabel10.setText("Cần thanh toán:");

        jLabel11.setText("Hình thức");

        cboTTDatHang.setBackground(new java.awt.Color(222, 231, 227));
        cboTTDatHang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboTTDatHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTTDatHangActionPerformed(evt);
            }
        });

        jLabel12.setText("Tiền khách đưa");

        txtTKDDH.setBackground(new java.awt.Color(222, 231, 227));
        txtTKDDH.setBorder(null);
        txtTKDDH.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTKDDHKeyReleased(evt);
            }
        });

        jLabel28.setText("Tiền thừa");

        txtTienThuaDH.setText("0");

        jButton4.setText("Tạo hoá đơn");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        btnGiaoHang.setText("Giao hàng");
        btnGiaoHang.setEnabled(false);
        btnGiaoHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGiaoHangActionPerformed(evt);
            }
        });

        btnDaGiao.setText("Đã giao");
        btnDaGiao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDaGiaoActionPerformed(evt);
            }
        });

        jButton7.setText("Huỷ");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        txtDiaChiDH.setBackground(new java.awt.Color(222, 231, 227));
        txtDiaChiDH.setBorder(null);

        jLabel31.setText("Địa chỉ");

        jButton2.setText("Chọn KH");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtSDTDH)
                                    .addComponent(jSeparator2)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator1)
                                    .addComponent(txtTenKHDH)))))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator5, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCTTDH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator4)
                                    .addComponent(txtTKDDH)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtDacQuyenDH, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cboTTDatHang, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addComponent(jLabel28)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtTienThuaDH, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jButton7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                            .addComponent(btnGiaoHang)
                                            .addGap(9, 9, 9)
                                            .addComponent(btnDaGiao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addComponent(jButton4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addComponent(jButton2)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(txtTongTienDH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel31)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtDiaChiDH)
                                    .addComponent(jSeparator12))))))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTenKHDH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtSDTDH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(txtDiaChiDH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(0, 2, Short.MAX_VALUE)
                        .addComponent(jSeparator12, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtTongTienDH))
                .addGap(12, 12, 12)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtDacQuyenDH))
                .addGap(12, 12, 12)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtCTTDH))
                .addGap(9, 9, 9)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cboTTDatHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(txtTKDDH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(4, 4, 4)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(txtTienThuaDH))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGiaoHang, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDaGiao, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
        );

        jTabbedPane1.addTab("Đặt hàng", jPanel8);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        javax.swing.GroupLayout pnlBanHangLayout = new javax.swing.GroupLayout(pnlBanHang);
        pnlBanHang.setLayout(pnlBanHangLayout);
        pnlBanHangLayout.setHorizontalGroup(
            pnlBanHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBanHangLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlBanHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlBanHangLayout.createSequentialGroup()
                        .addComponent(pnlWebCam, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        pnlBanHangLayout.setVerticalGroup(
            pnlBanHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBanHangLayout.createSequentialGroup()
                .addGroup(pnlBanHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlBanHangLayout.createSequentialGroup()
                        .addGroup(pnlBanHangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlBanHangLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(pnlWebCam, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pnlCards.add(pnlBanHang, "pnlBanHang");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/shop.png"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Tên shop");

        btnBanHang.setBackground(new java.awt.Color(153, 194, 211));
        btnBanHang.setText("Bán hàng");
        btnBanHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBanHangActionPerformed(evt);
            }
        });

        btnLichSu.setBackground(new java.awt.Color(153, 194, 211));
        btnLichSu.setText("Lịch sử");
        btnLichSu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLichSuActionPerformed(evt);
            }
        });

        btnSanPham.setBackground(new java.awt.Color(153, 194, 211));
        btnSanPham.setText("Sản phẩm");
        btnSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSanPhamActionPerformed(evt);
            }
        });

        btnKhachHang.setBackground(new java.awt.Color(153, 194, 211));
        btnKhachHang.setText("Khách hàng");
        btnKhachHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKhachHangActionPerformed(evt);
            }
        });

        btnKhuyenMai.setBackground(new java.awt.Color(153, 194, 211));
        btnKhuyenMai.setText("Khuyến mại");
        btnKhuyenMai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKhuyenMaiActionPerformed(evt);
            }
        });

        btnNhanVien.setBackground(new java.awt.Color(153, 194, 211));
        btnNhanVien.setText("Nhân viên");
        btnNhanVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNhanVienActionPerformed(evt);
            }
        });

        btnThongKe.setBackground(new java.awt.Color(153, 194, 211));
        btnThongKe.setText("Thống kê");
        btnThongKe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThongKeActionPerformed(evt);
            }
        });

        btnDoiMatKhau.setBackground(new java.awt.Color(153, 194, 211));
        btnDoiMatKhau.setText("Đổi mật khẩu");
        btnDoiMatKhau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDoiMatKhauActionPerformed(evt);
            }
        });

        btnDangXuat.setBackground(new java.awt.Color(153, 194, 211));
        btnDangXuat.setText("Đăng xuất");
        btnDangXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDangXuatActionPerformed(evt);
            }
        });

        jLabel30.setText("Người dùng:");

        txtNguoiDung.setText("nv03");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel2))
                        .addComponent(btnBanHang, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLichSu, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(btnKhachHang, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnKhuyenMai, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnNhanVien, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnThongKe, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnDoiMatKhau, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnDangXuat, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 4, Short.MAX_VALUE)
                        .addComponent(pnlCards, javax.swing.GroupLayout.PREFERRED_SIZE, 854, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNguoiDung, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 13, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel30)
                            .addComponent(txtNguoiDung))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlCards, javax.swing.GroupLayout.PREFERRED_SIZE, 556, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBanHang, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnLichSu, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnKhuyenMai, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnThongKe, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(btnDoiMatKhau, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(btnDangXuat, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48))))
        );

        getContentPane().add(jPanel1);
        jPanel1.getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnKhuyenMaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKhuyenMaiActionPerformed
        try {
            pnlCards.removeAll();
            pnlCards.add(new pnlKhuyenMai());
            pnlCards.repaint();
            pnlCards.revalidate();
            webcam.close();
        } catch (Exception e) {
        }

    }//GEN-LAST:event_btnKhuyenMaiActionPerformed

    private void btnBanHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBanHangActionPerformed
        try {
            pnlCards.removeAll();
            pnlCards.add(pnlBanHang);
            pnlCards.repaint();
            pnlCards.revalidate();
            view(ctsps.selectByWhere(""));
            initWebcam();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnBanHangActionPerformed

    private void btnLichSuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLichSuActionPerformed
        // TODO add your handling code here:
        try {
            pnlCards.removeAll();
            pnlCards.add(new pnlLichSu(hds, hdcts));
            pnlCards.repaint();
            pnlCards.revalidate();
            webcam.close();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnLichSuActionPerformed

    private void btnSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSanPhamActionPerformed
        try {
            pnlCards.removeAll();
            pnlCards.add(new pnlSanPham(sps, ctsps, cls, mss, dsps, kcs, nsxs));
            pnlCards.repaint();
            pnlCards.revalidate();
            webcam.close();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnSanPhamActionPerformed

    private void btnKhachHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKhachHangActionPerformed
        // TODO add your handling code here:
        try {
            pnlCards.removeAll();
            pnlCards.add(new pnlKhachHang());
            pnlCards.repaint();
            pnlCards.revalidate();
            webcam.close();
        } catch (Exception e) {
        }

    }//GEN-LAST:event_btnKhachHangActionPerformed

    private void btnNhanVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNhanVienActionPerformed
        try {
            pnlCards.removeAll();
            pnlCards.add(new pnlNhanVien());
            pnlCards.repaint();
            pnlCards.revalidate();
            webcam.close();
        } catch (Exception e) {
        }

    }//GEN-LAST:event_btnNhanVienActionPerformed

    private void btnThongKeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThongKeActionPerformed
        try {
            pnlCards.removeAll();
            pnlCards.add(new pnlThongKe());
            pnlCards.repaint();
            pnlCards.revalidate();
            webcam.close();
        } catch (Exception e) {
        }

    }//GEN-LAST:event_btnThongKeActionPerformed

    private void btnDoiMatKhauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDoiMatKhauActionPerformed
        try {
            pnlCards.removeAll();
            pnlCards.add(new pnlDoiMatKhau(txtNguoiDung.getText()));
            pnlCards.repaint();
            pnlCards.revalidate();
            webcam.close();
        } catch (Exception e) {
        }

    }//GEN-LAST:event_btnDoiMatKhauActionPerformed

    private void btnDangXuatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDangXuatActionPerformed
        // TODO add your handling code here:
        try {
            this.dispose();
            new SignIn().setVisible(true);
            webcam.close();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnDangXuatActionPerformed

    private void btnTaoHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTaoHoaDonActionPerformed
        // TODO add your handling code here:
        QLHoaDon hd = new QLHoaDon(nvs.selectByIDorMa(txtNguoiDung.getText().trim()), randomCaptcha(), 1);
        hds.insertNew(hd);
        List<QLHoaDon> list = hds.selectAll();
        viewHD(list);
        int row = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getMa().equalsIgnoreCase(hd.getMa())) {
                row = i;
            }
        }
        tblHoaDon.setRowSelectionInterval(row, row);
        dtmGH = (DefaultTableModel) tblGioHang.getModel();
        dtmGH.setRowCount(0);
    }//GEN-LAST:event_btnTaoHoaDonActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        QLHoaDon hd = new QLHoaDon(nvs.selectByIDorMa(txtNguoiDung.getText().trim()), randomCaptcha(), 1);
        hds.insertNew(hd);
        List<QLHoaDon> list = hds.selectAll();
        viewHD(list);
        int row = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getMa().equalsIgnoreCase(hd.getMa())) {
                row = i;
            }
        }
        tblHoaDon.setRowSelectionInterval(row, row);
        dtmGH = (DefaultTableModel) tblGioHang.getModel();
        dtmGH.setRowCount(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn huỷ hoá đơn không?", "Huỷ hoá đơn", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

            int row = tblHoaDon.getSelectedRow();
            if (row == (-1)) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                return;
            }
            QLHoaDon hd = hds.selectCT(tblHoaDon.getValueAt(row, 0).toString().trim());
            if (JOptionPane.showConfirmDialog(this, "Bạn có muốn huỷ đơn hàng không?", "Thông báo", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hds.updateHuy(hd.getMa());
                for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                    QLChiTietSanPham sp = ctsps.selectByMa(tblGioHang.getValueAt(i, 0).toString());
                    ctsps.updateBanHang(new QLChiTietSanPham(sp.getId(), sp.getMa(), sp.getSoLuongTon() + Integer.parseInt(tblGioHang.getValueAt(i, 2).toString())));
                }
                dtmGH = (DefaultTableModel) tblGioHang.getModel();
                dtmGH.setRowCount(0);
                view(ctsps.selectByWhere(""));
                viewHD(hds.selectAll());
                tongTien();
            }
        }
//huy

    }//GEN-LAST:event_jButton7ActionPerformed


    private void tblHoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHoaDonMouseClicked
        int row = tblHoaDon.getSelectedRow();
        String id = hds.selectIDOne(tblHoaDon.getValueAt(row, 0).toString());
        QLHoaDon hd = hds.selectByID(id);
        if (hd.getTrangThai() == 1) {
            viewGH(hdcts.selectAllGH(id));
            tongTien();
        } else {
            viewGH(hdcts.selectAllGH(id));
            tongTien();
            fillData(row);
        }
    }//GEN-LAST:event_tblHoaDonMouseClicked

    public void fillData(int index) {
        String id = hds.selectIDOne(tblHoaDon.getValueAt(index, 0).toString());
        QLHoaDon x = hds.selectID(id);
        System.out.println(x.getId());
        System.out.println(x.getMa());
        System.out.println(x.getDiaChi());
        System.out.println(x.getTenNguoiNhan());

        txtDiaChiDH.setText(x.getDiaChi());
        txtTenKHDH.setText(x.getTenNguoiNhan());
        txtTenKHTaiQuay.setText(x.getKhachHang().getHoVaTen());
        txtSDTDH.setText(x.getSdt());
        txtSDTTQ.setText(x.getSdt());
        cboTTDatHang.setSelectedItem(x.getThanhToan());
        cboTTTaiQuay.setSelectedItem(x.getThanhToan());

    }
    private void btnHuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuyActionPerformed
//        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn huỷ hoá đơn không?", "Huỷ hoá đơn", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            int row = tblHoaDon.getSelectedRow();
            if (row == (-1)) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                return;
            }
            QLHoaDon hd = hds.selectCT(tblHoaDon.getValueAt(row, 0).toString());
            if (JOptionPane.showConfirmDialog(this, "Bạn có muốn huỷ đơn hàng không?", "Thông báo", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                hds.updateHuy(hd.getMa());
                for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                    QLChiTietSanPham sp = ctsps.selectByMa(tblGioHang.getValueAt(i, 0).toString());
                    ctsps.updateBanHang(new QLChiTietSanPham(sp.getId(), sp.getMa(), sp.getSoLuongTon() + Integer.parseInt(tblGioHang.getValueAt(i, 2).toString())));
                }
                dtmGH = (DefaultTableModel) tblGioHang.getModel();
                dtmGH.setRowCount(0);
                view(ctsps.selectByWhere(""));
                viewHD(hds.selectAll());
                tongTien();
                JOptionPane.showMessageDialog(null, "Hủy thành công ");
            }
//        }

    }//GEN-LAST:event_btnHuyActionPerformed

    private void btnThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThanhToanActionPerformed
        // TODO add your handling code here:

        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn thanh toán không?", "Thanh toán", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (!checkTQ()) {
                return;
            }
            int row = tblHoaDon.getSelectedRow();
            if (row == (-1)) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                return;
            }
            QLHinhThucThanhToan ht = (QLHinhThucThanhToan) cboTTTaiQuay.getSelectedItem();
            if (!khs.selectBySDT(txtSDTTQ.getText().trim()).isEmpty()) {
                QLKhachHang kh = khs.selectBySDT(txtSDTTQ.getText().trim()).get(0);
                QLHoaDon hd = new QLHoaDon(kh, tblHoaDon.getValueAt(row, 0).toString().trim(),
                        txtTenKHTaiQuay.getText().trim(), txtSDTTQ.getText().trim(), ht, new BigDecimal(txtCanThanhToanTQ.getText().trim()));
                hds.updateTToan(hd);
                reset();
                k = kh;
                JOptionPane.showMessageDialog(null, "Thanh toán thành công ");
            } else {
                double tt = Double.parseDouble(txtTongTien.getText());
                QLKhachHang kha = new QLKhachHang(randomMaKH(), txtTenKHTaiQuay.getText().trim(), txtSDTTQ.getText().trim());
                khs.insertTaiQuay(kha);
                QLKhachHang kh = khs.selectBySDT(txtSDTTQ.getText().trim()).get(0);
                QLHoaDon hd = new QLHoaDon(kh, tblHoaDon.getValueAt(row, 0).toString().trim(),
                        txtTenKHTaiQuay.getText().trim(), txtSDTTQ.getText().trim(),
                        ht, new BigDecimal(txtCanThanhToanTQ.getText().trim()));
                hds.updateTToan(hd);
                reset();
                k = kh;   
                JOptionPane.showMessageDialog(null, "Thanh toán thành công ");
            }
            String id = khs.getIdByMa(k.getMa());
            if (hds.selectTongTien(id).compareTo(new BigDecimal(10000000)) >= 0) {
                String idLKH = lkhs.getIdByMa("LKH01");
                khs.updateLoaiKhachHang(idLKH, k.getMa());
            } else {
                String idLKH = lkhs.getIdByMa("LKH02");
                khs.updateLoaiKhachHang(idLKH, k.getMa());
            }

        }
    }//GEN-LAST:event_btnThanhToanActionPerformed

    public String randomMaKH() {
        String chuoi = "1234567890";
        Random random = new Random();
        StringBuilder capcha = new StringBuilder("KH");
        int length = 3;
        for (int i = 0; i < length; i++) {
            capcha.append(chuoi.charAt(random.nextInt(chuoi.length())));
        }
        for (QLKhachHang x : khs.selectAll()) {
            if (x.getMa().equalsIgnoreCase(capcha.toString())) {
                randomMaKH();
            }
        }
        return capcha.toString();
    }
    private void tblDanhSachSPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDanhSachSPMouseClicked
        // TODO add your handling code here:

        int row = tblHoaDon.getSelectedRow();
        if (row == (-1)) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        QLHoaDon hd = hds.selectCT(tblHoaDon.getValueAt(row, 0).toString());
        if (hd.getTrangThai() == 2) {
            JOptionPane.showMessageDialog(this, "Đơn hàng đang trong quá trình giao hàng!", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int rowSP = tblDanhSachSP.getSelectedRow();
        QLChiTietSanPham sp = ctsps.selectByMa(tblDanhSachSP.getValueAt(rowSP, 0).toString());
        String temp = null;
        try {
            temp = JOptionPane.showInputDialog("Vui lòng nhập số lượng");
        } catch (Exception e) {
        }
        if (temp == null) {
            return;
        }
        if (!temp.trim().matches("^\\d+")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số!", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int soLuongMua = Integer.parseInt(temp);
        if (soLuongMua > sp.getSoLuongTon()) {
            JOptionPane.showMessageDialog(this, "Số lượng sản phẩm trong kho không đủ", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (soLuongMua == 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập lại số lượng", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!hdcts.selectByHDandSP(hd.getId(), sp.getId()).isEmpty()) {
            QLHoaDonCT hdCheck = hdcts.selectByHDandSP(hd.getId(), sp.getId()).get(0);
            hdcts.update(new QLHoaDonCT(hd, sp, hdCheck.getSoLuong() + soLuongMua, sp.getGiaBan(), sp.getGiaKhiKM()));
            ctsps.updateBanHang(new QLChiTietSanPham(sp.getId(), sp.getMa(), sp.getSoLuongTon() - soLuongMua));
            viewGH(hdcts.selectAllGH(hd.getId()));
            view(ctsps.selectByWhere(""));
        } else {
            hdcts.insert(new QLHoaDonCT(hd, sp, soLuongMua, sp.getGiaBan(), sp.getGiaKhiKM()));
            ctsps.updateBanHang(new QLChiTietSanPham(sp.getId(), sp.getMa(), sp.getSoLuongTon() - soLuongMua));
            viewGH(hdcts.selectAllGH(hd.getId()));
            view(ctsps.selectByWhere(""));
        }
        tongTien();

    }//GEN-LAST:event_tblDanhSachSPMouseClicked
    public void tongTien() {
        BigDecimal result = new BigDecimal(0);
        for (int i = 0; i < tblGioHang.getRowCount(); i++) {
            BigDecimal a = new BigDecimal(tblGioHang.getValueAt(i, 5).toString().trim());
            result = result.add(a);
        }
        txtTongTienDH.setText(result.toString().trim());
        txtTongTien.setText(result.toString().trim());
        BigDecimal giaGiam = result.subtract(result.multiply(new BigDecimal(txtDacQuyenTQ.getText().trim()).divide(new BigDecimal(100))));
        txtCTTDH.setText(giaGiam.toString().trim());
        txtCanThanhToanTQ.setText(giaGiam.toString().trim());
    }
    private void btnXoaSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaSanPhamActionPerformed
        // TODO add your handling code here:
        int row = tblHoaDon.getSelectedRow();
        if (row == (-1)) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        QLHoaDon hd = hds.selectCT(tblHoaDon.getValueAt(row, 0).toString());
        int rowSP = tblGioHang.getSelectedRow();
        if (rowSP == (-1)) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn xoá sản phẩm ra khỏi giỏ hàng không?", "Thông báo", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            QLChiTietSanPham sp = ctsps.selectByMaa(tblGioHang.getValueAt(rowSP, 0).toString());
            ctsps.updateBanHang(new QLChiTietSanPham(sp.getId(), sp.getMa(),
                    sp.getSoLuongTon() + Integer.parseInt(tblGioHang.getValueAt(rowSP, 2).toString())));
            hdcts.delete(hd.getId(), sp.getId());
            viewGH(hdcts.selectAllGH(hd.getId()));
            view(ctsps.selectByWhere(""));
        }
        tongTien();
    }//GEN-LAST:event_btnXoaSanPhamActionPerformed

    private void btnLamMoiGHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiGHActionPerformed
        // TODO add your handling code here:
        int row = tblHoaDon.getSelectedRow();
        if (row == (-1)) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }

        QLHoaDon hd = hds.selectCT(tblHoaDon.getValueAt(row, 0).toString());
        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn làm mới giỏ hàng không?", "Thông báo", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            for (int i = 0; i < tblGioHang.getRowCount(); i++) {
                QLChiTietSanPham sp = ctsps.selectByMaa(tblGioHang.getValueAt(i, 0).toString());
                ctsps.updateBanHang(new QLChiTietSanPham(
                        sp.getId(),
                        sp.getMa(),
                        sp.getSoLuongTon() + Integer.parseInt(tblGioHang.getValueAt(i, 2).toString()))
                );
            }
            view(ctsps.selectByWhere(""));
            hdcts.delete(hd.getId());
            viewGH(hdcts.selectAllGH(hd.getId()));
        }
        tongTien();
    }//GEN-LAST:event_btnLamMoiGHActionPerformed

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        view(ctsps.selectByWhere(txtTimKiem.getText()));
    }//GEN-LAST:event_txtTimKiemKeyReleased

    private void cboLocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboLocActionPerformed
        // TODO add your handling code here:
        if (cboLoc.getSelectedItem() == null) {
            view(ctsps.selectByWhere(""));
        } else if (cboLoc.getSelectedIndex() == 0) {
            view(ctsps.selectByWhere(""));
        } else {
            QLDongSP idDong = (QLDongSP) cboLoc.getSelectedItem();
            view(ctsps.loc(idDong.getId()));
        }
    }//GEN-LAST:event_cboLocActionPerformed

    private void cboTTTaiQuayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTTTaiQuayActionPerformed
        // TODO add your handling code here:
        if (cboTTTaiQuay.getSelectedIndex() == 1) {
            txtTienKhachDuaTQ.setText(txtCanThanhToanTQ.getText().trim());
            btnThanhToan.setEnabled(true);
            txtTienThua.setText("0");
        } else {
            txtTienKhachDuaTQ.setText("");
            btnThanhToan.setEnabled(false);
        }
    }//GEN-LAST:event_cboTTTaiQuayActionPerformed

    private void cboTTDatHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTTDatHangActionPerformed
        // TODO add your handling code here:
        if (cboTTDatHang.getSelectedIndex() == 1) {
            txtTKDDH.setText(txtCTTDH.getText().trim());
            txtTienThuaDH.setText("0");
            btnGiaoHang.setEnabled(true);
        } else {
            txtTKDDH.setText("");
            btnGiaoHang.setEnabled(false);
        }
    }//GEN-LAST:event_cboTTDatHangActionPerformed

    private void txtTKDDHKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTKDDHKeyReleased
        // TODO add your handling code here:
        String t = txtTKDDH.getText().isEmpty() ? "0" : txtTKDDH.getText();
        if (!t.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Tiền không được chứa chữ hoặc kí tự đặc biệt", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            txtTKDDH.setText("");
            txtTKDDH.requestFocus();
            txtTienThuaDH.setText("");
            btnGiaoHang.setEnabled(false);
            return;
        }
        BigDecimal tienKD = new BigDecimal(t);
        BigDecimal tienCTT = new BigDecimal(txtCTTDH.getText().trim());
        txtTienThuaDH.setText((tienKD.subtract(tienCTT)) + "");
        BigDecimal tienThua = tienKD.subtract(tienCTT);
        if (tienThua.compareTo(new BigDecimal(0)) >= 0) {
            btnGiaoHang.setEnabled(true);
        } else {
            btnGiaoHang.setEnabled(false);
        }
    }//GEN-LAST:event_txtTKDDHKeyReleased

    private void txtTienKhachDuaTQKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTienKhachDuaTQKeyReleased
        String t = txtTienKhachDuaTQ.getText().trim().isEmpty() ? "0" : txtTienKhachDuaTQ.getText().trim();
        if (!t.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Tiền không được chứa chữ hoặc kí tự đặc biệt", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            txtTienKhachDuaTQ.setText("");
            txtTienKhachDuaTQ.requestFocus();
            btnThanhToan.setEnabled(false);
            txtTienThua.setText("");
            return;
        }
        BigDecimal tienKD = new BigDecimal(t);
        BigDecimal tienCTT = new BigDecimal(txtCanThanhToanTQ.getText().trim());
        txtTienThua.setText((tienKD.subtract(tienCTT)) + "");
        BigDecimal tienThua = tienKD.subtract(tienCTT);
        if (tienThua.compareTo(new BigDecimal(0)) >= 0) {
            btnThanhToan.setEnabled(true);
        } else {
            btnThanhToan.setEnabled(false);
        }
    }//GEN-LAST:event_txtTienKhachDuaTQKeyReleased
    public boolean checkTQ() {
        StringBuilder err = new StringBuilder();
        if (txtTenKHTaiQuay.getText().trim().isEmpty() || txtSDTTQ.getText().trim().isEmpty()) {
            return true;
        }
        if (txtTenKHTaiQuay.getText().trim().isEmpty()) {
            err.append("Tên khách hàng không được để trống");
        } else if (txtSDTTQ.getText().trim().isEmpty()) {
            err.append("Số điện thoại không được để trống");
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }

    public boolean checkDH() {
        StringBuilder err = new StringBuilder();
        if (txtTenKHTaiQuay.getText().trim().isEmpty()) {
            err.append("Tên khách hàng không được để trống");
        } else if (txtSDTTQ.getText().trim().isEmpty()) {
            err.append("Số điện thoại không được để trống");
        } else if (txtDiaChiDH.getText().trim().isEmpty()) {
            err.append("Địa chỉ đặt hàng không được để trống");
        }
        if (err.length() > 0) {
            JOptionPane.showMessageDialog(this, err, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }
    private void btnGiaoHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGiaoHangActionPerformed
        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn giao hàng không?", "Giao hàng", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

            int row = tblHoaDon.getSelectedRow();
            if (row == (-1)) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (txtTenKHDH.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập tên khách hàng", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                return;
            } else if (txtSDTDH.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập số điện thoại khách hàng", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                return;
            } else if (txtDiaChiDH.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập địa chỉ khách hàng", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                return;
            }
            QLHinhThucThanhToan ht = (QLHinhThucThanhToan) cboTTDatHang.getSelectedItem();
            if (!khs.selectBySDT(txtSDTDH.getText().trim()).isEmpty()) {
                QLKhachHang kh = khs.selectBySDT(txtSDTDH.getText().trim()).get(0);
                QLHoaDon hd = new QLHoaDon(kh, tblHoaDon.getValueAt(row, 0).toString().trim(), txtTenKHDH.getText().trim(),
                        txtSDTDH.getText().trim(), txtDiaChiDH.getText().trim(), ht, new BigDecimal(txtCTTDH.getText().trim()));
                BigDecimal tt = new BigDecimal(txtCTTDH.getText().trim());
                System.out.println(tt);
                hds.updateGHang(hd);
                reset();
            } else {
                double tt = Double.parseDouble(txtTongTienDH.getText().trim());
                QLKhachHang kha = new QLKhachHang(randomMaKH(), txtTenKHDH.getText().trim(), txtSDTDH.getText().trim(), txtDiaChiDH.getText().trim());
                khs.insertTaiQuay(kha);
                QLKhachHang kh = khs.selectBySDT(txtSDTDH.getText().trim()).get(0);
                QLHoaDon hd = new QLHoaDon(kh, tblHoaDon.getValueAt(row, 0).toString().trim(), txtTenKHDH.getText().trim(),
                        txtSDTDH.getText().trim(), txtDiaChiDH.getText().trim(), ht, new BigDecimal(txtCTTDH.getText().trim()));
                BigDecimal tong = new BigDecimal(txtTongTienDH.getText().trim());
                System.out.println(tong);
                hds.updateGHang(hd);
                reset();
            }

        }
    }//GEN-LAST:event_btnGiaoHangActionPerformed

    private void btnDaGiaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDaGiaoActionPerformed
        //btn đã giao
        if (JOptionPane.showConfirmDialog(this, "Xác nhận đã giao đơn hàng?", "Hoàn tất giao hàng", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            int row = tblHoaDon.getSelectedRow();
            if (row == (-1)) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                return;
            }
            QLKhachHang kh = khs.selectBySDT(txtSDTDH.getText().trim()).get(0);
            hds.updateNhanHang(tblHoaDon.getValueAt(row, 0).toString().trim());
            reset();
            k = kh;
            String id = khs.getIdByMa(k.getMa().trim());
            JOptionPane.showMessageDialog(null, "Đã giao thành công ");
                    
            if (hds.selectTongTien(id).compareTo(new BigDecimal(10000000)) >= 0) {
                String idLKH = lkhs.getIdByMa("LKH01");
                khs.updateLoaiKhachHang(idLKH, k.getMa());
            } else {
                String idLKH = lkhs.getIdByMa("LKH02");
                khs.updateLoaiKhachHang(idLKH, k.getMa());
            }
        }
    }//GEN-LAST:event_btnDaGiaoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        diaKH.setVisible(true);
        diaKH.setLocationRelativeTo(null);
        viewKH(khs.getBanHang());
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtTimKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKHActionPerformed
    public void resetDQ() {
        txtDacQuyenDH.setText("0");
        txtDacQuyenTQ.setText("0");
    }
    private void txtTimKHKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKHKeyReleased
        // TODO add your handling code here:
        String ma = txtTimKH.getText().trim();
        viewKH(khs.getBanHangMa(ma));
    }//GEN-LAST:event_txtTimKHKeyReleased
    QLKhachHang k = null;
    private void btnChonKhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChonKhActionPerformed
        // TODO add your handling code here:
        int rowHD = tblHoaDon.getSelectedRow();
        if (rowHD < 0) {
            dtmGH = (DefaultTableModel) tblGioHang.getModel();
            dtmGH.setRowCount(0);
        }
        int row = tblKhachHang.getSelectedRow();
        k = khs.getBanHangKH(tblKhachHang.getValueAt(row, 0).toString().trim());
        diaKH.dispose();
        txtTenKHTaiQuay.setText(k.getHoVaTen());
        txtSDTTQ.setText(k.getSdt());
        txtTenKHDH.setText(k.getHoVaTen());
        txtSDTDH.setText(k.getSdt());
        String id = khs.getIdByMa(k.getMa());
        if (hds.selectTongTien(id).compareTo(new BigDecimal(10000000)) >= 0) {
            txtDacQuyenDH.setText("10");
            txtDacQuyenTQ.setText("10");
            tongTien();
        } else {
            txtDacQuyenDH.setText("0");
            txtDacQuyenTQ.setText("0");
            tongTien();
        }
    }//GEN-LAST:event_btnChonKhActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        diaKH.setVisible(true);
        diaKH.setLocationRelativeTo(null);
        viewKH(khs.getBanHang());
    }//GEN-LAST:event_jButton2ActionPerformed

    private void tblGioHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblGioHangMouseClicked
        // TODO add your handling code here:
        int rowHD = tblHoaDon.getSelectedRow();
        if (rowHD == (-1)) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String maHD = tblHoaDon.getValueAt(tblHoaDon.getSelectedRow(), 0).toString();
        QLHoaDon hd = hds.selectCT(maHD);
        String maSP = tblGioHang.getValueAt(tblGioHang.getSelectedRow(), 0).toString();
        String soluong = JOptionPane.showInputDialog("Vui lòng nhập số lượng");
        if (soluong == null) {
            return;
        }
        if (!soluong.matches("^\\d+")) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số!", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int soluongGH = Integer.parseInt(tblGioHang.getValueAt(tblGioHang.getSelectedRow(), 2).toString());
        int slt = ctsps.getSL(maSP) + soluongGH;

        int sl = Integer.parseInt(soluong);
        if (sl > slt) {
            JOptionPane.showMessageDialog(this, "Số lượng tồn khô chỉ còn " + slt, "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        } else if (sl < 0) {
            JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
            return;
        } else if (sl == 0) {
            int rowSP = tblGioHang.getSelectedRow();
            QLChiTietSanPham sp = ctsps.selectByMaa(maSP);
            ctsps.updateBanHang(new QLChiTietSanPham(sp.getId(), sp.getMa(),
                    sp.getSoLuongTon() + Integer.parseInt(tblGioHang.getValueAt(rowSP, 2).toString())));
            hdcts.delete(hd.getId(), sp.getId());
            viewGH(hdcts.selectAllGH(hd.getId()));
            view(ctsps.selectByWhere(""));
            tongTien();
            return;
        }
        int slDu = sl - soluongGH;
        String idHD = hds.getIdByMa(maHD);
        String idSP = ctsps.getIdByMa(maSP);
        QLChiTietSanPham c = ctsps.selectByIDorMa(idSP);
        hdcts.update(idHD, idSP, sl);
        ctsps.updateBanHang(c.getSoLuongTon() - slDu, maSP);
        viewGH(hdcts.selectAllGH(idHD));
        view(ctsps.selectByWhere(""));
        tongTien();
    }//GEN-LAST:event_tblGioHangMouseClicked

    private void txtTenKHTaiQuayKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTenKHTaiQuayKeyReleased
        // TODO add your handling code here:
        resetDQ();
    }//GEN-LAST:event_txtTenKHTaiQuayKeyReleased

    private void txtSDTTQKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSDTTQKeyReleased
        resetDQ();
    }//GEN-LAST:event_txtSDTTQKeyReleased

    private void txtTenKHDHKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTenKHDHKeyReleased
        resetDQ();
    }//GEN-LAST:event_txtTenKHDHKeyReleased

    private void txtSDTDHKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSDTDHKeyReleased
        resetDQ();
    }//GEN-LAST:event_txtSDTDHKeyReleased
    public void viewKH(List<QLKhachHang> list) {
        dtmKH = (DefaultTableModel) tblKhachHang.getModel();
        dtmKH.setRowCount(0);
        for (QLKhachHang x : list) {
            dtmKH.addRow(x.getBH());
        }
    }

    public String randomCaptcha() {
        String chuoi = "1234567890";
        Random random = new Random();
        StringBuilder capcha = new StringBuilder();
        int length = 6;
        for (int i = 0; i < length; i++) {
            capcha.append(chuoi.charAt(random.nextInt(chuoi.length())));
        }
        for (QLHoaDon x : hds.selectAll()) {
            if (x.getMa().equalsIgnoreCase(capcha.toString())) {
                randomCaptcha();
            }
        }
        return capcha.toString();
    }

    @Override
    public void run() {
        try {
            do {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Result result = null;
                BufferedImage image = null;
                if (webcam.isOpen()) {
                    if ((image = webcam.getImage()) == null) {
                        continue;
                    }
                }
                LuminanceSource source = new BufferedImageLuminanceSource(image);
                BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

                try {
                    result = new MultiFormatReader().decode(bitmap);
                } catch (NotFoundException e) {
                }
                if (result != null) {
                    int row = tblHoaDon.getSelectedRow();
                    if (row == (-1)) {
                        JOptionPane.showMessageDialog(this, "Vui lòng chọn hoặc tạo hoá đơn", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                        continue;
                    }
                    QLHoaDon hd = hds.selectCT(tblHoaDon.getValueAt(row, 0).toString());
                    qr = result.getText();
                    QLChiTietSanPham sp = ctsps.selectByMa(qr);
                    String temp = null;
                    try {
                        temp = JOptionPane.showInputDialog("Vui lòng nhập số lượng");
                    } catch (Exception e) {
                    }
                    if (temp == null) {
                        return;
                    }
                    if (!temp.matches("^\\d+")) {
                        JOptionPane.showMessageDialog(this, "Vui lòng nhập số!", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                        continue;
                    }
                    int soLuongMua = Integer.parseInt(temp);
                    if (soLuongMua > sp.getSoLuongTon()) {
                        JOptionPane.showMessageDialog(this, "Số lượng sản phẩm trong kho không đủ", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                        continue;
                    }
                    if (soLuongMua == 0) {
                        JOptionPane.showMessageDialog(this, "Vui lòng nhập lại số lượng", "Thao tác không thành công", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (!hdcts.selectByHDandSP(hd.getId(), sp.getId()).isEmpty()) {
                        QLHoaDonCT hdCheck = hdcts.selectByHDandSP(hd.getId(), sp.getId()).get(0);
                        hdcts.update(new QLHoaDonCT(hd, sp, hdCheck.getSoLuong() + soLuongMua, sp.getGiaBan(), sp.getGiaKhiKM()));
                        ctsps.updateBanHang(new QLChiTietSanPham(sp.getId(), sp.getMa(), sp.getSoLuongTon() - soLuongMua));
                        viewGH(hdcts.selectAllGH(hd.getId()));
                        view(ctsps.selectByWhere(""));
                    } else {
                        hdcts.insert(new QLHoaDonCT(hd, sp, soLuongMua, sp.getGiaBan(), sp.getGiaKhiKM()));
                        ctsps.updateBanHang(new QLChiTietSanPham(sp.getId(), sp.getMa(), sp.getSoLuongTon() - soLuongMua));
                        viewGH(hdcts.selectAllGH(hd.getId()));
                        view(ctsps.selectByWhere(""));
                    }
                    tongTien();

                }
            } while (true);
        } catch (Exception e) {
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBanHang;
    private javax.swing.JButton btnChonKh;
    private javax.swing.JButton btnDaGiao;
    private javax.swing.JButton btnDangXuat;
    private javax.swing.JButton btnDoiMatKhau;
    private javax.swing.JButton btnGiaoHang;
    private javax.swing.JButton btnHuy;
    private javax.swing.JButton btnKhachHang;
    private javax.swing.JButton btnKhuyenMai;
    private javax.swing.JButton btnLamMoiGH;
    private javax.swing.JButton btnLichSu;
    private javax.swing.JButton btnNhanVien;
    private javax.swing.JButton btnSanPham;
    private javax.swing.JButton btnTaoHoaDon;
    private javax.swing.JButton btnThanhToan;
    private javax.swing.JButton btnThongKe;
    private javax.swing.JButton btnXoaSanPham;
    private javax.swing.JComboBox<String> cboLoc;
    private javax.swing.JComboBox<String> cboTTDatHang;
    private javax.swing.JComboBox<String> cboTTTaiQuay;
    private javax.swing.JDialog diaKH;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel pnlBanHang;
    private javax.swing.JPanel pnlCards;
    private javax.swing.JPanel pnlWebCam;
    private javax.swing.JTable tblDanhSachSP;
    private javax.swing.JTable tblGioHang;
    private javax.swing.JTable tblHoaDon;
    private javax.swing.JTable tblKhachHang;
    private javax.swing.JLabel txtCTTDH;
    private javax.swing.JLabel txtCanThanhToanTQ;
    private javax.swing.JLabel txtDacQuyenDH;
    private javax.swing.JLabel txtDacQuyenTQ;
    private javax.swing.JTextField txtDiaChiDH;
    private javax.swing.JLabel txtNguoiDung;
    private javax.swing.JTextField txtSDTDH;
    private javax.swing.JTextField txtSDTTQ;
    private javax.swing.JTextField txtTKDDH;
    private javax.swing.JTextField txtTenKHDH;
    private javax.swing.JTextField txtTenKHTaiQuay;
    private javax.swing.JTextField txtTienKhachDuaTQ;
    private javax.swing.JLabel txtTienThua;
    private javax.swing.JLabel txtTienThuaDH;
    private javax.swing.JTextField txtTimKH;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JLabel txtTongTien;
    private javax.swing.JLabel txtTongTienDH;
    // End of variables declaration//GEN-END:variables

    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r, "My Thread");
        t.setDaemon(true);
        return t;
    }
}
