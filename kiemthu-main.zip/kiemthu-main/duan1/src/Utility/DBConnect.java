/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utility;

import java.sql.*;

/**
 *
 * @author duy09
 */
public class DBConnect {

    public static String connectionURL = "jdbc:sqlserver://localhost:1433;databaseName=duan1_nhom4;"
            + "user=sa;password=123456";


    public static Connection getDBconnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (Exception e) {
        }
        try {
            return DriverManager.getConnection(connectionURL);
        } catch (Exception e) {
        }
        return null;
    }
    
    public static ResultSet executeQuery(String url, Object... args) {
        try {
            PreparedStatement ppsm = getDBconnection().prepareStatement(url);
            for (int i = 0; i < args.length; i++) {
                ppsm.setObject(i + 1, args[i]);
            }
            return ppsm.executeQuery();
        } catch (SQLException ex) {
        }
        return null;
    }

    public static int executeUpdate(String url, Object... args) {
        try {
            PreparedStatement ppsm = getDBconnection().prepareStatement(url);
            for (int i = 0; i < args.length; i++) {
                ppsm.setObject(i + 1, args[i]);
            }
            return ppsm.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return 0;
    }
}
