/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModel;

import Services.Iplm.KhuyenMaiService;
import java.math.BigDecimal;

/**
 *
 * @author duy09
 */
public class QLChiTietSanPham {

    private String id, ma;
    private int soLuongTon;
    private BigDecimal giaNhap, giaBan;
    private String moTa;
    private int trangThai;
    private QLSanPham sanPham;
    private QLMauSac mauSac;
    private QLChatLieu chatLieu;
    private QLDongSP dongSP;
    private QLNSX nsx;
    private QLKichCo kichCo;
    private BigDecimal giaKhiKM;

    public QLChiTietSanPham(String ma, BigDecimal giaKhiKM) {
        this.ma = ma;
        this.giaKhiKM = giaKhiKM;
    }

    public QLChiTietSanPham(String id, String ma, int soLuongTon) {
        this.id = id;
        this.ma = ma;
        this.soLuongTon = soLuongTon;
    }

    public QLChiTietSanPham(String id, String ma, int soLuongTon, BigDecimal giaNhap, BigDecimal giaBan, String moTa, int trangThai, QLSanPham sanPham, QLMauSac mauSac, QLChatLieu chatLieu, QLDongSP dongSP, QLNSX nsx, QLKichCo kichCo, BigDecimal giaKhiKM) {
        this.id = id;
        this.ma = ma;
        this.soLuongTon = soLuongTon;
        this.giaNhap = giaNhap;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
        this.giaKhiKM = giaKhiKM;
    }

    public QLChiTietSanPham(String ma, int soLuongTon, BigDecimal giaNhap, BigDecimal giaBan, String moTa, int trangThai, QLSanPham sanPham, QLMauSac mauSac, QLChatLieu chatLieu, QLDongSP dongSP, QLNSX nsx, QLKichCo kichCo, BigDecimal giaKhiKM) {
        this.ma = ma;
        this.soLuongTon = soLuongTon;
        this.giaNhap = giaNhap;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
        this.giaKhiKM = giaKhiKM;
    }

    public QLChiTietSanPham() {
    }

    public QLChiTietSanPham(String id, String ma, BigDecimal giaBan, QLSanPham sanPham, QLMauSac mauSac, QLChatLieu chatLieu, QLDongSP dongSP, QLNSX nsx, QLKichCo kichCo) {
        this.id = id;
        this.ma = ma;
        this.giaBan = giaBan;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
    }

    public QLChiTietSanPham(String id, String ma, int soLuongTon, BigDecimal giaNhap, BigDecimal giaBan, String moTa, int trangThai, QLSanPham sanPham, QLMauSac mauSac, QLChatLieu chatLieu, QLDongSP dongSP, QLNSX nsx, QLKichCo kichCo) {
        this.id = id;
        this.ma = ma;
        this.soLuongTon = soLuongTon;
        this.giaNhap = giaNhap;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
    }

    public QLChiTietSanPham(String ma, int soLuongTon, BigDecimal giaNhap, BigDecimal giaBan, String moTa, int trangThai, QLSanPham sanPham, QLMauSac mauSac, QLChatLieu chatLieu, QLDongSP dongSP, QLNSX nsx, QLKichCo kichCo) {
        this.ma = ma;
        this.soLuongTon = soLuongTon;
        this.giaNhap = giaNhap;
        this.giaBan = giaBan;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.sanPham = sanPham;
        this.mauSac = mauSac;
        this.chatLieu = chatLieu;
        this.dongSP = dongSP;
        this.nsx = nsx;
        this.kichCo = kichCo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public int getSoLuongTon() {
        return soLuongTon;
    }

    public BigDecimal getGiaKhiKM() {
        return giaKhiKM;
    }

    public void setGiaKhiKM(BigDecimal giaKhiKM) {
        this.giaKhiKM = giaKhiKM;
    }

    public void setSoLuongTon(int soLuongTon) {
        this.soLuongTon = soLuongTon;
    }

    public BigDecimal getGiaNhap() {
        return giaNhap;
    }

    public void setGiaNhap(BigDecimal giaNhap) {
        this.giaNhap = giaNhap;
    }

    public BigDecimal getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(BigDecimal giaBan) {
        this.giaBan = giaBan;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public QLSanPham getSanPham() {
        return sanPham;
    }

    public void setSanPham(QLSanPham sanPham) {
        this.sanPham = sanPham;
    }

    public QLMauSac getMauSac() {
        return mauSac;
    }

    public void setMauSac(QLMauSac mauSac) {
        this.mauSac = mauSac;
    }

    public QLChatLieu getChatLieu() {
        return chatLieu;
    }

    public void setChatLieu(QLChatLieu chatLieu) {
        this.chatLieu = chatLieu;
    }

    public QLDongSP getDongSP() {
        return dongSP;
    }

    public void setDongSP(QLDongSP dongSP) {
        this.dongSP = dongSP;
    }

    public QLNSX getNsx() {
        return nsx;
    }

    public void setNsx(QLNSX nsx) {
        this.nsx = nsx;
    }

    public QLKichCo getKichCo() {
        return kichCo;
    }

    public void setKichCo(QLKichCo kichCo) {
        this.kichCo = kichCo;
    }
//     private String id, ma;
//    private int soLuongTon;
//    private BigDecimal giaNhap, giaBan;
//    private String moTa;
//    private int trangThai;
//    private QLSanPham sanPham;
//    private QLMauSac mauSac;
//    private QLChatLieu chatLieu;
//    private QLDongSP dongSP;
//    private QLNSX nsx;
//    private QLKichCo kichCo;

    public Object[] getObject() {
        return new Object[]{ma, sanPham.getTen(), dongSP.getTen(), soLuongTon, chatLieu.getTen(), kichCo.getTen(),
            mauSac.getTen(), nsx.getTen(), giaNhap, giaBan};
    }

    public Object[] getOBKM() {
        return new Object[]{ma, sanPham.getTen(), kichCo.getTen(), mauSac.getTen(), chatLieu.getTen(), nsx.getTen(), giaBan, false};
    }

    public Object[] getBanHang() {
        return new Object[]{ma, sanPham.getTen(), dongSP.getTen(), chatLieu.getTen(), kichCo.getTen(), mauSac.getTen(), soLuongTon, giaKhiKM};
    }
    // Thống kê 

    public QLChiTietSanPham(String ma) {
        this.ma = ma;
    }

    public Object[] getThongKe() {
        return new Object[]{ma, SanPham()};
    }

    public String SanPham() {
        String shh = "";
        if (soLuongTon == 0) {
            shh = " hết hàng";
        } else if (soLuongTon < 10) {
            shh = "Sắp hết hàng";
        } else {
            shh = "Còn hàng";
        }
        return shh;
    }

    public Object[] getThongKeSanPham() {
        return new Object[]{ma, sanPham.getTen(), soLuongTon,
            chatLieu.getTen(), mauSac.getTen(), kichCo.getTen(), SanPham()};
    }
}
