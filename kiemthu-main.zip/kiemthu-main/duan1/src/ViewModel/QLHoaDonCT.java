/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModel;

import java.math.BigDecimal;

/**
 *
 * @author duy09
 */
public class QLHoaDonCT {

    private String id;
    private QLHoaDon hoaDon;
    private QLChiTietSanPham chiTietSanPham;
    private String MaHDCT;
    private int soLuong;
    private BigDecimal donGia, donGiaSauKhiGiam;

    public QLHoaDonCT() {
    }

    public QLHoaDonCT(QLHoaDon hoaDon, QLChiTietSanPham chiTietSanPham, int soLuong, BigDecimal donGia, BigDecimal donGiaSauKhiGiam) {
        this.hoaDon = hoaDon;
        this.chiTietSanPham = chiTietSanPham;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.donGiaSauKhiGiam = donGiaSauKhiGiam;
    }

    public QLHoaDonCT(String id, QLHoaDon hoaDon, QLChiTietSanPham chiTietSanPham, String MaHDCT, int soLuong, BigDecimal donGia, BigDecimal donGiaSauKhiGiam) {
        this.id = id;
        this.hoaDon = hoaDon;
        this.chiTietSanPham = chiTietSanPham;
        this.MaHDCT = MaHDCT;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.donGiaSauKhiGiam = donGiaSauKhiGiam;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public QLHoaDon getHoaDon() {
        return hoaDon;
    }

    public void setHoaDon(QLHoaDon hoaDon) {
        this.hoaDon = hoaDon;
    }

    public QLChiTietSanPham getChiTietSanPham() {
        return chiTietSanPham;
    }

    public void setChiTietSanPham(QLChiTietSanPham chiTietSanPham) {
        this.chiTietSanPham = chiTietSanPham;
    }

    public String getMaHDCT() {
        return MaHDCT;
    }

    public void setMaHDCT(String MaHDCT) {
        this.MaHDCT = MaHDCT;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public BigDecimal getDonGia() {
        return donGia;
    }

    public void setDonGia(BigDecimal donGia) {
        this.donGia = donGia;
    }

    public BigDecimal getDonGiaSauKhiGiam() {
        return donGiaSauKhiGiam;
    }

    public void setDonGiaSauKhiGiam(BigDecimal donGiaSauKhiGiam) {
        this.donGiaSauKhiGiam = donGiaSauKhiGiam;
    }
    

    public Object[] getObject() {
        return new Object[]{chiTietSanPham.getMa(), chiTietSanPham.getSanPham().getTen(),
            soLuong,donGia, donGiaSauKhiGiam,
            donGiaSauKhiGiam.multiply(new BigDecimal(soLuong))};
    }
    // thong ke

    public QLHoaDonCT(QLChiTietSanPham chiTietSanPham, int soLuong) {
        this.chiTietSanPham = chiTietSanPham;
        this.soLuong = soLuong;
    }
    
    public Object[] getThongKeSp(){
        return new Object[]{chiTietSanPham.getMa(),
                            chiTietSanPham.getSanPham().getTen(),
                            soLuong,chiTietSanPham.getChatLieu().getTen(),
                            chiTietSanPham.getMauSac().getTen(),
                            chiTietSanPham.getKichCo().getTen(),
                            "Đã bán "};
    }

}
