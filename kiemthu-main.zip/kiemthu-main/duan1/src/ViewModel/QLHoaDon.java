/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModel;

import Utility.DBConnect;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author duy09
 */
public class QLHoaDon {

    private String id;
    private QLKhachHang khachHang;
    private QLNhanVien nhanVien;
    private String ma;
    private Date ngayTao, ngayThanhToan, ngayGiao, ngayNhan;
    private int trangThai;
    private String tenNguoiNhan, sdt, diaChi;
    private QLHinhThucThanhToan thanhToan;
    private BigDecimal tongTien;

    public QLHoaDon() {
    }

    public QLHoaDon(QLNhanVien nhanVien, String ma, int trangThai, String tenNguoiNhan) {
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
    }

    public QLHoaDon(QLKhachHang khachHang, String ma, int trangThai, QLHinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.trangThai = trangThai;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public QLHoaDon(String id, QLNhanVien nhanVien, String ma, Date ngayThanhToan, int trangThai, String tenNguoiNhan, String sdt, String diaChi, BigDecimal tongTien) {
        this.id = id;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayThanhToan = ngayThanhToan;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.tongTien = tongTien;
    }

    public QLHoaDon(QLKhachHang khachHang, String ma, String tenNguoiNhan, String sdt, QLHinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public QLHoaDon(String id, QLKhachHang khachHang, QLNhanVien nhanVien, String ma, Date ngayTao, Date ngayThanhToan, Date ngayGiao, Date ngayNhan, int trangThai, String tenNguoiNhan, String sdt, String diaChi, QLHinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.id = id;
        this.khachHang = khachHang;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.ngayThanhToan = ngayThanhToan;
        this.ngayGiao = ngayGiao;
        this.ngayNhan = ngayNhan;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public QLHoaDon(QLNhanVien nhanVien, String ma, int trangThai) {
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.trangThai = trangThai;
    }

    public QLHoaDon(QLKhachHang khachHang, String ma, int trangThai) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.trangThai = trangThai;
    }

    public QLHoaDon(String ma) {
        this.ma = ma;
    }

    public QLHoaDon(String id, String ma, Date ngayTao, BigDecimal tongTien) {
        this.id = id;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.tongTien = tongTien;
    }

    public QLHoaDon(QLKhachHang khachHang, QLNhanVien nhanVien, String ma, int trangThai, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.trangThai = trangThai;
        this.tongTien = tongTien;
    }

    public QLHoaDon(QLKhachHang khachHang, String ma, QLHinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public QLHoaDon(QLKhachHang khachHang, String ma, String tenNguoiNhan, String sdt, String diaChi, QLHinhThucThanhToan thanhToan, BigDecimal tongTien) {
        this.khachHang = khachHang;
        this.ma = ma;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.thanhToan = thanhToan;
        this.tongTien = tongTien;
    }

    public QLHoaDon(String id, QLNhanVien nhanVien, String ma, Date ngayTao, int trangThai) {
        this.id = id;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.trangThai = trangThai;
    }

    public QLHoaDon(QLNhanVien nhanVien, String ma, Date ngayTao, int trangThai) {
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.trangThai = trangThai;
    }

    public QLHoaDon(QLNhanVien nhanVien, String ma) {
        this.nhanVien = nhanVien;
        this.ma = ma;
    }

    public QLHoaDon(String id, QLKhachHang khachHang, QLNhanVien nhanVien, String ma, Date ngayTao, Date ngayThanhToan, Date ngayGiao, Date ngayNhan, int trangThai, String tenNguoiNhan, String sdt, String diaChi, QLHinhThucThanhToan thanhToan) {
        this.id = id;
        this.khachHang = khachHang;
        this.nhanVien = nhanVien;
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.ngayThanhToan = ngayThanhToan;
        this.ngayGiao = ngayGiao;
        this.ngayNhan = ngayNhan;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.thanhToan = thanhToan;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public BigDecimal getTongTien() {
        if (tongTien == null) {
            tongTien = BigDecimal.valueOf(0);
        }
        return tongTien;
    }

    public void setTongTien(BigDecimal tongTien) {
        this.tongTien = tongTien;
    }

    public QLKhachHang getKhachHang() {
        return khachHang;
    }

    public void setKhachHang(QLKhachHang khachHang) {
        this.khachHang = khachHang;
    }

    public QLNhanVien getNhanVien() {
        return nhanVien;
    }

    public void setNhanVien(QLNhanVien nhanVien) {
        this.nhanVien = nhanVien;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgayThanhToan() {
        return ngayThanhToan;
    }

    public void setNgayThanhToan(Date ngayThanhToan) {
        this.ngayThanhToan = ngayThanhToan;
    }

    public Date getNgayGiao() {
        return ngayGiao;
    }

    public void setNgayGiao(Date ngayGiao) {
        this.ngayGiao = ngayGiao;
    }

    public Date getNgayNhan() {
        return ngayNhan;
    }

    public void setNgayNhan(Date ngayNhan) {
        this.ngayNhan = ngayNhan;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public String getTenNguoiNhan() {
        return tenNguoiNhan;
    }

    public void setTenNguoiNhan(String tenNguoiNhan) {
        this.tenNguoiNhan = tenNguoiNhan;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public QLHinhThucThanhToan getThanhToan() {
        return thanhToan;
    }

    public void setThanhToan(QLHinhThucThanhToan thanhToan) {
        this.thanhToan = thanhToan;
    }

    public Object[] getObject() {
        String tt = trangThai == 0 ? "Đã huỷ" : (trangThai == 1 ? "Đang chờ" : (trangThai == 2 ? "Đang giao hàng" : "Đã hoàn thành"));
        return new Object[]{ma, nhanVien.getHoVaTen(), khachHang.getHoVaTen(), tt};
    }

    public Object[] getObjectNew() {
        String tt = trangThai == 0 ? "Đã huỷ" : (trangThai == 1 ? "Đang chờ" : (trangThai == 2 ? "Đang giao hàng" : "Đã hoàn thành"));
        return new Object[]{ma, nhanVien.getHoVaTen(), "", tt};
    }

    public Object[] getLichSu() {
        return new Object[]{ma, ngayTao, tongTien};
    }
    // Thống kê doanh thu 

    public QLHoaDon(BigDecimal tongTien) {
        this.tongTien = tongTien;
    }

    public QLHoaDon(String id, Date ngayTao, BigDecimal tongTien) {
        this.id = id;
        this.ngayTao = ngayTao;
        this.ngayTao = ngayTao;
        this.tongTien = tongTien;
    }

    public Object[] getThongKeDoanhThu() {
        return new Object[]{ngayTao, id, tien()};
    }

    @Override
    public String toString() {
        return new SimpleDateFormat("yyyy").format(ngayTao);
    }

    public String tien() {
        String tt = "";
        if (tongTien == null) {
            tt = "0";
        } else {
            tt = String.valueOf(tongTien);
        }
        return tt;
    }

    public QLHoaDon(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    // thống kê hóa đơn
    public QLHoaDon(int trangThai) {
        this.trangThai = trangThai;
    }

    public QLHoaDon(String ma, Date ngayTao, int trangThai, String tenNguoiNhan, String sdt, BigDecimal tongTien) {
        this.ma = ma;
        this.ngayTao = ngayTao;
        this.trangThai = trangThai;
        this.tenNguoiNhan = tenNguoiNhan;
        this.sdt = sdt;
        this.tongTien = tongTien;
    }

    

    public String tt() {
        String tt = "";
        if (trangThai == 0) {
            tt = "Đã Hủy";
        } else if (trangThai == 1) {
            tt = "Đang chờ";
        } else if (trangThai == 2) {
            tt = "Đang vận chuyển";
        } else if (trangThai == 3) {
            tt = "Đã nhận ";
        } else {
            tt = "";
        }
        return tt;
    }

    public Object[] getThongKeHoaDon() {
        return new Object[]{ma, tenNguoiNhan, sdt,ngayTao, tongTien == null ? "0" : tongTien, tt()};
    }

    public Object[] getObLS() {
        String tt = trangThai == 0 ? "Đã huỷ" : (trangThai == 1 ? "Đang chờ" : (trangThai == 2 ? "Đang giao hàng" : "Đã hoàn thành"));
        return new Object[]{ma, nhanVien.getHoVaTen(), tenNguoiNhan, tt};
    }
}
