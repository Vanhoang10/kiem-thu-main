/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModel;

import java.math.BigDecimal;

/**
 *
 * @author duy09
 */
public class QLChiTietKhuyenMai {

    private String id, ma;
    private QLKhuyenMai khuyenMai;
    private QLChiTietSanPham chiTietSanPham;
    private BigDecimal donGiaKhiGiam;
    private boolean trangThai;

    public QLChiTietKhuyenMai() {
    }

    public QLChiTietKhuyenMai(BigDecimal donGiaKhiGiam) {
        this.donGiaKhiGiam = donGiaKhiGiam;
    }

    public QLChiTietKhuyenMai(QLKhuyenMai khuyenMai, QLChiTietSanPham chiTietSanPham) {
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
    }

    public QLChiTietKhuyenMai(String id, String ma, QLKhuyenMai khuyenMai, QLChiTietSanPham chiTietSanPham, BigDecimal donGiaKhiGiam, boolean trangThai) {
        this.id = id;
        this.ma = ma;
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.donGiaKhiGiam = donGiaKhiGiam;
        this.trangThai = trangThai;
    }

    public QLChiTietKhuyenMai(QLKhuyenMai khuyenMai, QLChiTietSanPham chiTietSanPham, boolean trangThai) {
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.trangThai = trangThai;
    }

    public QLChiTietKhuyenMai(String id, String ma, QLKhuyenMai khuyenMai, QLChiTietSanPham chiTietSanPham, BigDecimal donGiaKhiGiam) {
        this.id = id;
        this.ma = ma;
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.donGiaKhiGiam = donGiaKhiGiam;
    }

    public QLChiTietKhuyenMai(QLKhuyenMai khuyenMai, QLChiTietSanPham chiTietSanPham, BigDecimal donGiaKhiGiam, boolean trangThai) {
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.donGiaKhiGiam = donGiaKhiGiam;
        this.trangThai = trangThai;
    }

    public QLChiTietKhuyenMai(QLKhuyenMai khuyenMai, QLChiTietSanPham chiTietSanPham, BigDecimal donGiaKhiGiam) {
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.donGiaKhiGiam = donGiaKhiGiam;
    }

    public QLChiTietKhuyenMai(String ma, QLKhuyenMai khuyenMai, QLChiTietSanPham chiTietSanPham, BigDecimal donGiaKhiGiam) {
        this.ma = ma;
        this.khuyenMai = khuyenMai;
        this.chiTietSanPham = chiTietSanPham;
        this.donGiaKhiGiam = donGiaKhiGiam;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public QLKhuyenMai getKhuyenMai() {
        return khuyenMai;
    }

    public void setKhuyenMai(QLKhuyenMai khuyenMai) {
        this.khuyenMai = khuyenMai;
    }

    public QLChiTietSanPham getChiTietSanPham() {
        return chiTietSanPham;
    }

    public void setChiTietSanPham(QLChiTietSanPham chiTietSanPham) {
        this.chiTietSanPham = chiTietSanPham;
    }

    public BigDecimal getDonGiaKhiGiam() {
        return donGiaKhiGiam;
    }

    public void setDonGiaKhiGiam(BigDecimal donGiaKhiGiam) {
        this.donGiaKhiGiam = donGiaKhiGiam;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    public Object[] getObject() {
        return new Object[]{chiTietSanPham.getMa(), chiTietSanPham.getSanPham().getTen(),
            chiTietSanPham.getKichCo().getTen(), chiTietSanPham.getMauSac().getTen(),
            chiTietSanPham.getChatLieu().getTen(), chiTietSanPham.getNsx().getTen(), chiTietSanPham.getGiaBan(), true};
    }

    public Object[] getSP() {
//        if (khuyenMai.getTrangthai() == 2) {
            return new Object[]{chiTietSanPham.getMa(), chiTietSanPham.getSanPham().getTen(),
                chiTietSanPham.getDongSP(), chiTietSanPham.getChatLieu(), chiTietSanPham.getKichCo(), chiTietSanPham.getMauSac(),
                chiTietSanPham.getSoLuongTon()};
//        } else {
//            return new Object[]{chiTietSanPham.getMa(), chiTietSanPham.getSanPham().getTen(),
//                chiTietSanPham.getDongSP(), chiTietSanPham.getChatLieu(), chiTietSanPham.getKichCo(), chiTietSanPham.getMauSac(),
//                chiTietSanPham.getSoLuongTon(), chiTietSanPham.getGiaBan().subtract(donGiaKhiGiam)};
//        }

    }

}
