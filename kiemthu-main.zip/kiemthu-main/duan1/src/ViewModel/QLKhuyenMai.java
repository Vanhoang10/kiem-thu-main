/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewModel;

import java.util.Date;

/**
 *
 * @author duy09
 */
public class QLKhuyenMai {

    private String id, ma, ten;
    private double mucGiaGiam;
    private Date thoiGianBatDau, thoiGianKetThuc;
    private int trangthai;

    public QLKhuyenMai() {
    }

    public QLKhuyenMai(String id, String ma, String ten, double mucGiaGiam, Date thoiGianBatDau, Date thoiGianKetThuc, int trangthai) {
        this.id = id;
        this.ma = ma;
        this.ten = ten;
        this.mucGiaGiam = mucGiaGiam;
        this.thoiGianBatDau = thoiGianBatDau;
        this.thoiGianKetThuc = thoiGianKetThuc;
        this.trangthai = trangthai;
    }

    public QLKhuyenMai(String ten, double mucGiaGiam, Date thoiGianBatDau, Date thoiGianKetThuc, int trangthai) {
        this.ten = ten;
        this.mucGiaGiam = mucGiaGiam;
        this.thoiGianBatDau = thoiGianBatDau;
        this.thoiGianKetThuc = thoiGianKetThuc;
        this.trangthai = trangthai;
    }

    public QLKhuyenMai(String ma, String ten, double mucGiaGiam, Date thoiGianBatDau, Date thoiGianKetThuc, int trangthai) {
        this.ma = ma;
        this.ten = ten;
        this.mucGiaGiam = mucGiaGiam;
        this.thoiGianBatDau = thoiGianBatDau;
        this.thoiGianKetThuc = thoiGianKetThuc;
        this.trangthai = trangthai;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public double getMucGiaGiam() {
        return mucGiaGiam;
    }

    public void setMucGiaGiam(double mucGiaGiam) {
        this.mucGiaGiam = mucGiaGiam;
    }

    public Date getThoiGianBatDau() {
        return thoiGianBatDau;
    }

    public void setThoiGianBatDau(Date thoiGianBatDau) {
        this.thoiGianBatDau = thoiGianBatDau;
    }

    public Date getThoiGianKetThuc() {
        return thoiGianKetThuc;
    }

    public void setThoiGianKetThuc(Date thoiGianKetThuc) {
        this.thoiGianKetThuc = thoiGianKetThuc;
    }

    public int getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(int trangthai) {
        this.trangthai = trangthai;
    }

    @Override
    public String toString() {
        return ten;
    }
    public Object[] getObject(){
        return new Object[]{ten,mucGiaGiam,thoiGianBatDau,thoiGianKetThuc,
            trangthai == 0 ? "Ngưng hoạt động": "Đang hoạt động"};
    }

}
